/*
 *
 * SelectOpenedLists reducer
 *
 */
import produce from 'immer';
import { GET_DATA, GET_DATA_SUCCESS, GET_DATA_FAIL } from './constants';

export const initialState = {
  data:[],
  load:0,
};

/* eslint-disable default-case, no-param-reassign */
const selectOpenedListsReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case GET_DATA:
        draft.load=1;
        break;
      case GET_DATA_SUCCESS:
        console.log(action);
        draft.data=action.data.data;
        draft.load=0;
        break;
        case GET_DATA_FAIL:
        draft.load=0;
        break;
    }
  });

export default selectOpenedListsReducer;
