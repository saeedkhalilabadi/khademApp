// import { take, call, put, select } from 'redux-saga/effects';

// Individual exports for testing


import { takeLatest, call, put, select } from 'redux-saga/effects';
import axios from '../axios/axios-user';
import { GET_DATA } from './constants';
import { getDataSuccess, getDataFail } from './actions';

function* getdatasaga(params) {
  let data;
  let e = null;
  console.log(params);
  yield axios
    .post('api/deliveres/branche/getdata', params.data,{
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      console.log(response.data, 'data');
      data = response.data;
      e = true;
    })
    .catch(error => {
      console.log(error.response);
      data = error;
      e = false;
    });
  if (e) yield put(getDataSuccess(data));
  else yield put(getDataFail(data));
}

export default function* selectOpenedListsSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(GET_DATA, getdatasaga);
}
