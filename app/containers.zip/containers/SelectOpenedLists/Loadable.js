/**
 *
 * Asynchronously loads the component for SelectOpenedLists
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
