import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the selectOpenedLists state domain
 */

const selectSelectOpenedListsDomain = state =>
  state.selectOpenedLists || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by SelectOpenedLists
 */

const makeSelectSelectOpenedLists = () =>
  createSelector(
    selectSelectOpenedListsDomain,
    substate => substate,
  );

export default makeSelectSelectOpenedLists;
export { selectSelectOpenedListsDomain };
