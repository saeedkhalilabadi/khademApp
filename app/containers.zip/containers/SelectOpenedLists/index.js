/**
 *
 * SelectOpenedLists
 *
 */

import React, { memo, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectSelectOpenedLists from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import { getData } from './actions';
import { Typography } from 'antd';
import { Link } from 'react-router-dom';
import { Row, Col, Form, Button } from 'react-bootstrap';
import './index.css';
import '../../src/allStyles.css';

export function SelectOpenedLists({
  selectOpenedLists,
  dispatch,
  props,
}) {
  useInjectReducer({ key: 'selectOpenedLists', reducer });
  useInjectSaga({ key: 'selectOpenedLists', saga });
  const [getdata, setgetdata] = useState(true);
  if (getdata)
    setTimeout(() => {
      setgetdata(false);
      dispatch(getData({
        'branche_id': 'self',
        'status': '1'
      }));
    }, 50);
  console.log(selectOpenedLists);

  const openedLists = (
    <Row>
      <Col xs={12} sm={12} md={12} xl={12} className="title">
        انتخاب لیست
      </Col>
      {selectOpenedLists.data.lenght == 0 ? (
        <Typography>لیستی یافت نشد</Typography>
      ) : (
            <>
            {selectOpenedLists.data.map(list=>(
                <Col xs={12} sm={12} md={12} xl={12} className="openList" key={list.id}>
                  <Link
                className="textIcons"
                to={{
                  pathname: '/SelectSubDectrbution',
                  state: { date: list.date_in_str },
                }}
              >
                <Row>
                <Col xs={6} sm={6} md={3} xl={3}>
                  {list.date_in_str.slice(0, 4) +
                    '/' +
                    list.date_in_str.slice(5, 7) +
                    '/' +
                    list.date_in_str.slice(8, 10)}{' '}
                </Col>

                <Col xs={6} sm={6} md={4} xl={4}>
                  موجودی: {(Number(list.bags_sum_weight) - Number(list.sale)-Number(list.folwerKg))/1000} کیلوگرم
                </Col>


                <Col xs={6} sm={6} md={4} xl={4}>
                  توزیع شده: {(Number(list.folwerKg))/1000} کیلوگرم
                </Col>


                <Col xs={6} sm={6} md={4} xl={4}>
              <Link
                to={{
                  pathname: '/ShowAndSubmitList',
                  state: { id:  list.id },
                }}
              >
                <Button variant="warning" size="sm">
                  بازبینی و تایید لیست
                </Button>
              </Link>
            </Col>

                </Row>
                </Link>
                </Col>
            ))}
            </>
          )}
    </Row>
  );
  return (
    <div>
      <Helmet>
        <title>انتخاب لیست</title>
        <meta name="description" content="Description of SelectOpenedLists" />
      </Helmet>
      {openedLists}
    </div>
  );
}

SelectOpenedLists.propTypes = {
  dispatch: PropTypes.func.isRequired,
  selectOpenedLists: PropTypes.func.isRequired
};

const mapStateToProps = createStructuredSelector({
  selectOpenedLists: makeSelectSelectOpenedLists(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(SelectOpenedLists);
