/*
 *
 * SelectOpenedLists actions
 *
 */

import { GET_DATA, GET_DATA_SUCCESS, GET_DATA_FAIL } from './constants';

export function getData(data) {
  return {
    type: GET_DATA,
    data
  };
}

export function getDataSuccess(data) {
  return {
    type: GET_DATA_SUCCESS,
    data
  };
}

export function getDataFail(err) {
  return {
    type: GET_DATA_FAIL,
    err
  };
}
