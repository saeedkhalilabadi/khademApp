// import { selectSelectOpenedListsDomain } from '../selectors';

describe('selectSelectOpenedListsDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
