/**
 *
 * Asynchronously loads the component for EmployeeBagRegister
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
