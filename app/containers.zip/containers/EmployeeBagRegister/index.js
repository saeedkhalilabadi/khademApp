/**
 *
 * EmployeeBagRegister
 *
 */

import React, { memo, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';

import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import 'react-modern-calendar-datepicker/lib/DatePicker.css';
import DatePicker from 'react-modern-calendar-datepicker';
import { Row, Col, Form, Button } from 'react-bootstrap';

import AddIcon from '@mui/icons-material/Add';
import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectEmployeeBagRegister from './selectors';
import Loading from '../../components/Loading/Loadable';
import reducer from './reducer';
import saga from './saga';
import './index.css';
import '../../src/allStyles.css';
import { getData, addData, editData, deleteData } from './actions';

export function EmployeeBagRegister({ employeeBagRegister, dispatch, props }) {
  useInjectReducer({ key: 'employeeBagRegister', reducer });
  useInjectSaga({ key: 'employeeBagRegister', saga });
  const [getdata, setgetdata] = useState(true);
  const [selectedBag, setselectedBag] = useState(true);
  const [value, setValue] = useState(0);
  const [date, setdate] = useState('today');
  const [addBage, setaddBage] = useState(false);
  const [weight, setweight] = useState('');
  if (getdata)
    setTimeout(() => {
      setgetdata(false);
      dispatch(
        getData({
          date,
        }),
      );
    }, 50);

  function handelBagSattus(status) {
    switch (status) {
      case '1':
        return '#ffff00';
        break;
      case '2':
        return '#ff9800';
        break;
      case '3':
        return '#76ff03';
        break;
      default:
        break;
    }
  }

  function selectedForm(bagIndex) {
    return (
      <Row className="form">
        <Col xs={12} sm={12} md={12} xl={12} className="fieldItem">
          <Form.Group className="mb-1" controlId="formBasicEmail">
            <Form.Text className="text-muted">وزن کیسه </Form.Text>

            <Form.Control
              size="sm"
              value={weight}
              style={{ maxWidth: '100px', display: 'inline' }}
              type="number"
              placeholder="وزن (کیلو)"
              onChange={e => {
                setweight(e.target.value);
              }}
            />
          </Form.Group>
        </Col>
        <Col xs={6} sm={6} md={4} xl={4} className="fieldItem">
          <Button
            variant="warning"
            style={{ width: '100%', marginTop: '50px' }}
            onClick={() => {
              setselectedBag(0);
              dispatch(
                editData({
                  id: selectedBag,
                  weight,
                  branche_id: 'self',
                }),
              );
            }}
          >
            ویرایش
          </Button>
        </Col>
        <Col xs={6} sm={6} md={4} xl={4} className="fieldItem">
          <Button
            variant="danger"
            style={{ width: '100%', marginTop: '50px' }}
            onClick={() => {
              setselectedBag(0);
              dispatch(
                deleteData({
                  id: selectedBag,
                }),
              );
            }}
          >
            حذف
          </Button>
        </Col>
      </Row>
    );
  }

  const selectDate = (
    <Row className="title2">
      <Col xs={4} sm={4} md={4} xl={4}>
        <Button
          variant="warning"
          size="sm"
          onClick={() =>
            dispatch(
              getData({
                date: 'tom',
                m: Number(employeeBagRegister.date.m),
                d: Number(employeeBagRegister.date.d),
                y: Number(employeeBagRegister.date.y),
              }),
            )
          }
        >
          روز بعد
        </Button>
      </Col>

      <Col xs={4} sm={4} md={4} xl={4}>
        <DatePicker
          style={{ margin: 'auto', with: '100%' }}
          value={
            employeeBagRegister.date == null
              ? null
              : {
                  day: Number(employeeBagRegister.date.d),
                  month: Number(employeeBagRegister.date.m),
                  year: Number(employeeBagRegister.date.y),
                }
          }
          onChange={e => {
            dispatch(
              getData({
                date: 'date',
                m: e.month,
                d: e.day,
                y: e.year,
              }),
            );
            setdate(e);
          }}
          shouldHighlightWeekends
          locale="fa" // add this
        />
      </Col>
      <Col xs={4} sm={4} md={4} xl={4}>
        <Button
          variant="warning"
          size="sm"
          onClick={() =>
            dispatch(
              getData({
                date: 'yes',
                m: Number(employeeBagRegister.date.m),
                d: Number(employeeBagRegister.date.d),
                y: Number(employeeBagRegister.date.y),
              }),
            )
          }
        >
          روز قبل
        </Button>
      </Col>
    </Row>
  );

  const addNew = (
    <Row className="form">
      <Col xs={9} sm={9} md={9} xl={9} className="fieldItem">
        <Form.Group className="mb-1" controlId="formBasicEmail">
          <Form.Text className="text-muted">وزن کیسه </Form.Text>

          <Form.Control
            size="sm"
            value={weight}
            style={{ maxWidth: '100px', display: 'inline' }}
            type="number"
            placeholder="وزن (کیلو)"
            onChange={e => {
              setweight(e.target.value);
            }}
          />
        </Form.Group>
      </Col>
      <Col xs={3} sm={3} md={3} xl={3} className="fieldItem">
        <Button
          variant="warning"
          style={{ width: '100%' }}
          size="sm"
          onClick={() => {
            dispatch(
              addData(
                date == 'today'
                  ? { date, weight }
                  : {
                      date: 'date',
                      y: date.year,
                      m: date.month,
                      d: date.day,
                      weight,
                    },
              ),
            );
            setweight('');
            setaddBage(false);
          }}
        >
          ثبت
        </Button>
      </Col>
    </Row>
  );
  const alltotal = employeeBagRegister.data.reduce(
    (a, v) => (a = a + Number(v.weight)),
    0,
  );
  const Allnumbers = employeeBagRegister.data.length;

  const infoALL = (
    <Row className="form">
      <Col>{'تعداد: ' + Allnumbers + 'کیسه'}</Col>
      <Col>{'جمع کل: ' + Math.round(alltotal * 100) / 100 + 'کیلو'}</Col>
    </Row>
  );
  const bagListBranche = employeeBagRegister.data.map((bag, index) => (
    <Col
      className="bag"
      xs={selectedBag == bag.id ? 12 : 3}
      sm={selectedBag == bag.id ? 12 : 3}
      md={selectedBag == bag.id ? 12 : 3}
      xl={selectedBag == bag.id ? 12 : 3}
      key={bag.id}
      onClick={() => {
        if (selectedBag == 0 || selectedBag != bag.id) {
          setweight(bag.weight);
          setselectedBag(bag.id);
        }
      }}
      style={{ backgroundColor: handelBagSattus(bag.status) }}
    >
      {'' + bag.weight + 'کیلو'}
      {selectedBag == bag.id ? selectedForm(index) : null}
    </Col>
  ));

  return (
    <div>
      <Helmet>
        <title>ثبت کیسه</title>
        <meta name="description" content="Description of EmployeeBagRegister" />
      </Helmet>
      {employeeBagRegister.load == 1 ? <Loading /> : null}
      {selectDate}
      {addNew}
      {infoALL}
      <Row>{bagListBranche}</Row>
    </div>
  );
}

EmployeeBagRegister.propTypes = {
  dispatch: PropTypes.func.isRequired,
  employeeBagRegister: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  employeeBagRegister: makeSelectEmployeeBagRegister(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(EmployeeBagRegister);
