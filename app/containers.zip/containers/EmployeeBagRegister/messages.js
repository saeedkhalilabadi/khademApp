/*
 * EmployeeBagRegister Messages
 *
 * This contains all the text for the EmployeeBagRegister container.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.containers.EmployeeBagRegister';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the EmployeeBagRegister container!',
  },
});
