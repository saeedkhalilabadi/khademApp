/*
 *
 * EmployeeBagRegister actions
 *
 */

import {
  GET_DATA,
  GET_DATA_ERROR,
  GET_DATA_SUCCESS,
  ADD_DATA,
  ADD_DATA_ERROR,
  ADD_DATA_SUCCESS,
  EDIT_DATA,
  EDIT_DATA_ERROR,
  EDIT_DATA_SUCCESS,
  DELETE_DATA,
  DELETE_DATA_ERROR,
  DELETE_DATA_SUCCESS,
} from './constants';

export function getData(data) {
  return {
    type: GET_DATA,
    data,
  };
}
export function getDataSuccess(data) {
  return {
    type: GET_DATA_SUCCESS,
    data,
  };
}
export function getDataError(data) {
  return {
    type: GET_DATA_ERROR,
    data,
  };
}
export function addData(data) {
  return {
    type: ADD_DATA,
    data,
  };
}
export function addDataSuccess(data) {
  return {
    type: ADD_DATA_SUCCESS,
    data,
  };
}
export function addDataError(data) {
  return {
    type: ADD_DATA_ERROR,
    data,
  };
}
export function editData(data) {
  return {
    type: EDIT_DATA,
    data,
  };
}
export function editDataSuccess(data) {
  return {
    type: EDIT_DATA_SUCCESS,
    data,
  };
}
export function editDataError(data) {
  return {
    type: EDIT_DATA_ERROR,
    data,
  };
}
export function deleteData(data) {
  return {
    type: DELETE_DATA,
    data,
  };
}
export function deleteDataSuccess(data) {
  return {
    type: DELETE_DATA_SUCCESS,
    data,
  };
}
export function deleteDataError(data) {
  return {
    type: DELETE_DATA_ERROR,
    data,
  };
}
