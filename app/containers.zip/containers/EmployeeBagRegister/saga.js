import { takeLatest, call, put, select } from 'redux-saga/effects';
import axios from '../axios/axios-user';
import { GET_DATA, ADD_DATA, EDIT_DATA, DELETE_DATA } from './constants';
import {
  editDataError,
  editDataSuccess,
  deleteDataError,
  deleteDataSuccess,
  getDataSuccess,
  getDataError,
  addDataError,
  addDataSuccess,
} from './actions';

// Individual exports for testing

function* getdata(params) {
  let data;
  let e = null;
  console.log(params.data);
  yield axios
    .post('api/bags/branche/getdata', params.data, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      console.log(response.data, 'data');
      data = response.data;
      e = true;
    })
    .catch(error => {
      console.log(error.response);
      data = error;
      e = false;
    });
  if (e) yield put(getDataSuccess(data));
  else yield put(getDataError(data));
}
function* adddata(params) {
  let data;
  let e = null;
  console.log(params.data, 'PARA');
  yield axios
    .post('api/bags/branche', params.data, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      console.log(response.data, 'data1');
      data = response.data;
      e = true;
    })
    .catch(error => {
      console.log(error.response);
      data = error;
      e = false;
    });
  if (e) yield put(addDataSuccess(data));
  else yield put(addDataError(data));
}
function* editdata(params) {
  let data;
  let e = null;
  console.log(params.data, 'PARA');
  yield axios

    .put('api/bags/branche/' + params.data.id, params.data, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      console.log(response.data, 'data1');
      data = response.data;
      e = true;
    })
    .catch(error => {
      console.log(error.response);
      data = error;
      e = false;
    });
  if (e) yield put(editDataSuccess(data));
  else yield put(editDataError(data));
}
function* deletedata(params) {
  let data;
  let e = null;
  console.log(params.data, 'PARA');
  yield axios

    .delete('api/bags/branche/' + params.data.id, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      console.log(response.data, 'data1');
      data = response.data;
      e = true;
    })
    .catch(error => {
      console.log(error.response);
      data = error;
      e = false;
    });
  if (e) yield put(deleteDataSuccess(data));
  else yield put(deleteDataError(data));
}

// Individual exports for testing
export default function* employeeBagRegisterSaga() {
  yield takeLatest(GET_DATA, getdata);
  yield takeLatest(ADD_DATA, adddata);
  yield takeLatest(EDIT_DATA, editdata);
  yield takeLatest(DELETE_DATA, deletedata);

  // See example in containers/HomePage/saga.js
}
