/*
 *
 * EmployeeBagRegister constants
 *
 */

export const GET_DATA = 'app/EmployeeBagRegister/GET_DATA';
export const GET_DATA_SUCCESS = 'app/EmployeeBagRegister/GET_DATA_SUCCESS';
export const GET_DATA_ERROR = 'app/EmployeeBagRegister/GET_DATA_ERROR';

export const ADD_DATA = 'app/EmployeeBagRegister/ADD_DATA';
export const ADD_DATA_SUCCESS = 'app/EmployeeBagRegister/ADD_DATA_SUCCESS';
export const ADD_DATA_ERROR = 'app/EmployeeBagRegister/ADD_DATA_ERROR';

export const EDIT_DATA = 'app/EmployeeBagRegister/EDIT_DATA';
export const EDIT_DATA_SUCCESS = 'app/EmployeeBagRegister/EDIT_DATA_SUCCESS';
export const EDIT_DATA_ERROR = 'app/EmployeeBagRegister/EDIT_DATA_ERROR';

export const DELETE_DATA = 'app/EmployeeBagRegister/DELETE_DATA';
export const DELETE_DATA_SUCCESS = 'app/EmployeeBagRegister/DELETE_DATA_SUCCESS';
export const DELETE_DATA_ERROR = 'app/EmployeeBagRegister/DELETE_DATA_ERROR';
