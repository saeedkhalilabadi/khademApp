import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the employeeBagRegister state domain
 */

const selectEmployeeBagRegisterDomain = state =>
  state.employeeBagRegister || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by EmployeeBagRegister
 */

const makeSelectEmployeeBagRegister = () =>
  createSelector(
    selectEmployeeBagRegisterDomain,
    substate => substate,
  );

export default makeSelectEmployeeBagRegister;
export { selectEmployeeBagRegisterDomain };
