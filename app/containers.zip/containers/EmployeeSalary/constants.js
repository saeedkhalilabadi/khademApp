/*
 *
 * EmployeeSalary constants
 *
 */

export const GET_DATA = 'app/EmployeeSalary/GET_DATA';
export const GET_DATA_SUCCESS = 'app/EmployeeSalary/GET_DATA_SUCCESS';
export const GET_DATA_FAIL = 'app/EmployeeSalary/GET_DATA_FAIL';
