import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the employeeSalary state domain
 */

const selectEmployeeSalaryDomain = state =>
  state.employeeSalary || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by EmployeeSalary
 */

const makeSelectEmployeeSalary = () =>
  createSelector(
    selectEmployeeSalaryDomain,
    substate => substate,
  );

export default makeSelectEmployeeSalary;
export { selectEmployeeSalaryDomain };
