import { take, call, put, select, takeLatest } from 'redux-saga/effects';
import axios from '../axios/axios-user';
import {
  GET_DATA
} from './constants';
import {
  getDataSuccess,
  getDataFail,
} from './actions';
export function* getdata(params) {
  let e = 0;
  let data = 0;
 
  yield axios
    .post('/api/deliveres/manager/getdata', params.data, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      console.log(response.data, 'response333');
      data = response.data;
      // console.log(response.data.data.userData, 'res');
      e = 1;
    })
    .catch(error => {
      data = error;
      console.log(error.response);
    });
  if (e == 1) yield put(getDataSuccess(data));
  else yield put(getDataFail(data));
}


export default function* employeeSalarySaga() {
  yield takeLatest(GET_DATA, getdata);
}
