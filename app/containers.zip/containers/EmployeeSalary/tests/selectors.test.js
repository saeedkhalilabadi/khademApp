// import { selectEmployeeSalaryDomain } from '../selectors';

describe('selectEmployeeSalaryDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
