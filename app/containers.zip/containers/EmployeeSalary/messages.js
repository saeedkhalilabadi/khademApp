/*
 * EmployeeSalary Messages
 *
 * This contains all the text for the EmployeeSalary container.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.containers.EmployeeSalary';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the EmployeeSalary container!',
  },

  sale: {
    id: `${scope}.sale`,
    defaultMessage: 'فروش',
  },
});
