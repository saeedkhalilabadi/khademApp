/*
 *
 * EmployeeSalary reducer
 *
 */
import produce from 'immer';
import {
  GET_DATA,
  GET_DATA_SUCCESS,
  GET_DATA_FAIL,
} from './constants';

export const initialState = {
  data:[],
  wage:0
};

/* eslint-disable default-case, no-param-reassign */
const employeeSalaryReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case GET_DATA:
        break;
      case GET_DATA_SUCCESS:
        draft.data=action.data.data
        draft.wage=action.data.wage;
        break;
      case GET_DATA_FAIL:
        break;
    }
  });

export default employeeSalaryReducer;
