/**
 *
 * EmployeeSalary
 *
 */

import React, { memo, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { Col, Row, Button, Form } from 'react-bootstrap';
import NumberFormat from 'react-number-format';

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectEmployeeSalary from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import { getData } from './actions';
import './index.css';

export function EmployeeSalary({ employeeSalary, dispatch, props }) {
  useInjectReducer({ key: 'employeeSalary', reducer });
  useInjectSaga({ key: 'employeeSalary', saga });

  const [getdata, setgetdata] = useState(true);

  if (getdata)
    setTimeout(() => {
      setgetdata(false);
      dispatch(getData({
        branche_id: props.id,
        status: 3
      }));
    }, 200);
  console.log(employeeSalary.data, 'index444');
  const wages = (
    <Row>
      {employeeSalary.data.length == 0 ?
        (<p>اطلاعاتی پیدا نشد</p>) : (
          <>

            {employeeSalary.data && employeeSalary.data.map(payment => (
              <Col xs={12} sm={12} md={12} xl={12} className="payItems" key={payment.id}>
                <Row>
                  <Col xs={6} sm={6} md={3} xl={3}>
                    تاریخ: {payment.date_in_str.slice(0, 4) + '/' + payment.date_in_str.slice(5, 7) + '/' + payment.date_in_str.slice(8, 10)}
                  </Col>
                   <Col xs={6} sm={6} md={2} xl={2}>
                وزن گل تحویل شده: {payment.bags_sum_weight} کیلوگرم
               </Col>
               <Col xs={6} sm={6} md={2} xl={2}>
                وزن گل توزیع شده: {payment.folwerKg} کیلوگرم
               </Col>
               <Col xs={6} sm={6} md={2} xl={2}>
                وزن سرگل دریافتی: {payment.headG} گرم
               </Col>
               <Col xs={6} sm={6} md={3} xl={3}>
                حق الزحمه: <NumberFormat
            value={Number(payment.folwerKg) * Number(employeeSalary.wage)}
            displayType={'text'}
            thousandSeparator={true}
          
            renderText={(value, props) => <span {...props}>{value} تومان</span>}
          />
               </Col> 
                </Row>
              </Col>
            ))}
          </>
        )}
    </Row>
  );
  return (
    <div>
      <Helmet>
        <title>EmployeeSalary</title>
        <meta name="description" content="Description of EmployeeSalary" />
      </Helmet>
      {wages}
    </div>
  );
}

EmployeeSalary.propTypes = {
  dispatch: PropTypes.func.isRequired,
  employeeSalary: PropTypes.object.isRequired
};

const mapStateToProps = createStructuredSelector({
  employeeSalary: makeSelectEmployeeSalary(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(EmployeeSalary);
