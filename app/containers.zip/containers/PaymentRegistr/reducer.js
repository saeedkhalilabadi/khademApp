/*
 *
 * PaymentRegistr reducer
 *
 */
import produce from 'immer';
import {
  SEARCH,
  SEARCH_ERROR,
  SEARCH_SUCCESS,
  GET_DATA,
  GET_DATA_ERROR,
  GET_DATA_SUCCESS,
} from './constants';

export const initialState = {
  data: [],
  subs: [],
  branches: [],
};

/* eslint-disable default-case, no-param-reassign */
const paymentRegistrReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case GET_DATA:
        break;
      case GET_DATA_SUCCESS:
        draft.data = action.data.data;
        break;
      case GET_DATA_ERROR:
        break;
      case SEARCH:
        break;
      case SEARCH_SUCCESS:
        draft.subs = action.data.subs;
        draft.branches = action.data.branches;

        break;
      case SEARCH_ERROR:
        break;
    }
  });

export default paymentRegistrReducer;
