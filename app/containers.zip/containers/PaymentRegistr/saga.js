import { takeLatest, call, put, select } from 'redux-saga/effects';
import axios from '../axios/axios-user';
import { GET_DATA, SEARCH } from './constants';
import {
  getDataSuccess,
  getDataError,
  searchError,
  searchSuccess,
} from './actions';

function* getdata(params) {
  let data;
  let e = null;

  yield axios
    .get('api/subscriptions', params.data, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      console.log(response.data, 'data');
      data = response.data;
      e = true;
    })
    .catch(error => {
      console.log(error.response);
      data = error;
      e = false;
    });
  if (e) yield put(getDataSuccess(data));
  else yield put(getDataError(data));
}
function* search(params) {
  let data;
  let e = null;
  console.log(params.data);

  yield axios
    .post('api/getdata', params.data, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      console.log(response.data, 'data');
      data = response.data;
      e = true;
    })
    .catch(error => {
      console.log(error.response);
      data = error;
      e = false;
    });
  if (e) yield put(searchSuccess(data));
  else yield put(searchError(data));
}

// Individual exports for testing
export default function* paymentRegistrSaga() {
  yield takeLatest(GET_DATA, getdata);
  yield takeLatest(SEARCH, search);

  // See example in containers/HomePage/saga.js
}
