import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the paymentRegistr state domain
 */

const selectPaymentRegistrDomain = state =>
  state.paymentRegistr || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by PaymentRegistr
 */

const makeSelectPaymentRegistr = () =>
  createSelector(
    selectPaymentRegistrDomain,
    substate => substate,
  );

export default makeSelectPaymentRegistr;
export { selectPaymentRegistrDomain };
