/**
 *
 * PaymentRegistr
 *
 */

import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { Link } from 'react-router-dom';
import { compose } from 'redux';
import { Row, Col, Form, Button } from 'react-bootstrap';
import IconButton from '@mui/material/IconButton';
import Paper from '@mui/material/Paper';
import InputBase from '@mui/material/InputBase';
import SearchIcon from '@mui/icons-material/Search';

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectPaymentRegistr from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import { getData, search } from './actions';
import './index.css';
import '../../src/allStyles.css';

export function PaymentRegistr({ paymentRegistr, dispatch, props }) {
  useInjectReducer({ key: 'paymentRegistr', reducer });
  useInjectSaga({ key: 'paymentRegistr', saga });
  console.log('paymentRegistr', paymentRegistr);
  const searchform = (
    <Row>
      <Col xs={12} sm={12} md={12} xl={12} className="title">
        ثبت پرداخت
      </Col>
      <Col xs={6} sm={6} md={6} xl={6}>
        <Paper
          component="form"
          sx={{
            direction: 'rtl',
            margin: 'auto',
            marginTop: '10px',
            marginBottom: '10px',
            p: '2px 4px',
            display: 'flex',
            alignItems: 'center',
            width: '100%',
          }}
        >
          <InputBase
            sx={{ ml: 1, flex: 1 }}
            type="text"
            placeholder="نام و نام خانوادگی "
            inputProps={{ 'aria-label': 'جستجو' }}
            onChange={e => dispatch(search({ word: e.target.value }))}
          />

          <SearchIcon />
        </Paper>
      </Col>
      <Col xs={6} sm={6} md={6} xl={6}>
        <Paper
          component="form"
          sx={{
            direction: 'rtl',
            margin: 'auto',
            marginTop: '10px',
            marginBottom: '10px',
            p: '2px 4px',
            display: 'flex',
            alignItems: 'center',
            width: '100%',
          }}
        >
          <InputBase
            sx={{ ml: 1, flex: 1 }}
            type="number"
            placeholder="کد اشتراک"
            inputProps={{ 'aria-label': 'جستجو' }}
            onChange={e => dispatch(search({ word: e.target.value }))}
          />

          <SearchIcon />
        </Paper>
      </Col>
      <Col className="form1">
        <Row>
          {paymentRegistr.branches.map(item => (
            <Col xs={12} sm={12} md={12} xl={12}>
              <Link
                className="textIcons"
                to={{
                  pathname: '/PaymentRegistr2',
                  state: {
                    id: item.id,
                    subject: 'branche',
                  },
                }}
              >
                <Row className="searchItem">
                  <Col xs={3} sm={3} md={3} xl={3}>
                    <Button
                      variant="warning"
                      size="sm"
                      className="searchItemLabel"
                    >
                      شعبه
                    </Button>{' '}
                  </Col>
                  <Col xs={6} sm={6} md={6} xl={6}>
                    {' '}
                    {item.gender + ' ' + item.name + ' ' + item.lname}
                  </Col>
                  <Col xs={3} sm={3} md={3} xl={3}>
                    {' '}
                    {' کد: ' + item.id}
                  </Col>
                </Row>
              </Link>
            </Col>
          ))}
        </Row>
        <Row>
          {paymentRegistr.subs.map(item => (
            <Col xs={12} sm={12} md={12} xl={12}>
              <Link
                className="textIcons"
                to={{
                  pathname: '/PaymentRegistr2',
                  state: {
                    id: item.id,
                    subject: 'sub',
                  },
                }}
              >
                <Row className="searchItem">
                  <Col xs={3} sm={3} md={3} xl={3}>
                    <Button
                      variant="info"
                      size="sm"
                      className="searchItemLabel"
                    >
                      مشترک
                    </Button>{' '}
                  </Col>
                  <Col xs={6} sm={6} md={6} xl={6}>
                    {' '}
                    {item.gender + ' ' + item.name + ' ' + item.lname}
                  </Col>
                  <Col xs={3} sm={3} md={3} xl={3}>
                    {' '}
                    {' کد: ' + item.code}
                  </Col>
                </Row>
              </Link>
            </Col>
          ))}
        </Row>
      </Col>
    </Row>
  );

  return (
    <div>
      <Helmet>
        <title>ثبت پرداختی</title>
        <meta name="description" content="Description of PaymentRegistr" />
      </Helmet>
      {searchform}
    </div>
  );
}

PaymentRegistr.propTypes = {
  dispatch: PropTypes.func.isRequired,
  paymentRegistr: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  paymentRegistr: makeSelectPaymentRegistr(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(PaymentRegistr);
