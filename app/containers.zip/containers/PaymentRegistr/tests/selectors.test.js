// import { selectPaymentRegistrDomain } from '../selectors';

describe('selectPaymentRegistrDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
