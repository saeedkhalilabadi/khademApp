/*
 *
 * PaymentRegistr constants
 *
 */

export const GET_DATA = 'app/PaymentRegistr/GET_DATA';
export const GET_DATA_SUCCESS = 'app/PaymentRegistr/GET_DATA_SUCCESS';
export const GET_DATA_ERROR = 'app/PaymentRegistr/GET_DATA_ERROR';

export const SEARCH = 'app/PaymentRegistr/SEARCH';
export const SEARCH_SUCCESS = 'app/PaymentRegistr/SEARCH_SUCCESS';
export const SEARCH_ERROR = 'app/PaymentRegistr/SEARCH_ERROR';
