import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the disEdit state domain
 */

const selectDisEditDomain = state => state.disEdit || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by DisEdit
 */

const makeSelectDisEdit = () =>
  createSelector(
    selectDisEditDomain,
    substate => substate,
  );

export default makeSelectDisEdit;
export { selectDisEditDomain };
