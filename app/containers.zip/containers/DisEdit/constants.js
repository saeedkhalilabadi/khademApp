/*
 *
 * DisEdit constants
 *
 */

export const DEFAULT_ACTION = 'app/DisEdit/DEFAULT_ACTION';
