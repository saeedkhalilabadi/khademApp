/*
 *
 * EmployeeLists reducer
 *
 */
import produce from 'immer';
import { GET_DATA, GET_DATA_ERROR, GET_DATA_SUCCESS } from './constants';

export const initialState = {
  data: [],
  item: null,
  load: 0,
};

/* eslint-disable default-case, no-param-reassign */
const employeeListsReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case GET_DATA:
        draft.load = 1;
        break;
      case GET_DATA_SUCCESS:
        draft.load = 0;
        draft.data = action.data.data;

        break;
      case GET_DATA_ERROR:
        draft.load = 0;
        break;
    }
  });

export default employeeListsReducer;
