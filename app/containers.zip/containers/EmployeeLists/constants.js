/*
 *
 * EmployeeLists constants
 *
 */

export const GET_DATA = 'app/EmployeeLists/GET_DATA';
export const GET_DATA_SUCCESS = 'app/EmployeeLists/GET_DATA_SUCCESS';
export const GET_DATA_ERROR = 'app/EmployeeLists/GET_DATA_ERROR';
