import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the employeeLists state domain
 */

const selectEmployeeListsDomain = state => state.employeeLists || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by EmployeeLists
 */

const makeSelectEmployeeLists = () =>
  createSelector(
    selectEmployeeListsDomain,
    substate => substate,
  );

export default makeSelectEmployeeLists;
export { selectEmployeeListsDomain };
