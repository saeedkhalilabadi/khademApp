/**
 *
 * EmployeeLists
 *
 */

import React, { memo, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { Col, Row, Form, Button } from 'react-bootstrap';
import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectEmployeeLists from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import { getData } from './actions';
import './index.css';
import '../../src/allStyles.css';

export function EmployeeLists({ employeeLists, dispatch, props }) {
  useInjectReducer({ key: 'employeeLists', reducer });
  useInjectSaga({ key: 'employeeLists', saga });
  const [getdata, setgetdata] = useState(true);

  if (getdata)
    setTimeout(() => {
      setgetdata(false);
      dispatch(
        getData({
          branche_id: props.id ? props.id : 'self',
          status: props.status ? props.status : '',
        }),
      );
    }, 100);

  console.log(employeeLists);
  const title = (
    <Row>
      <Col className="title">لیستها</Col>
    </Row>
  );

  const showList = (
    <Row className="form">
      {employeeLists.data.map(item => (
        <Col xs={12} sm={12} md={12} xl={12}>
          <Row className="employeeListsItems">
            <Col xs={12} sm={12} md={12} xl={12}>
              {item.date_in_str.slice(0, 4) +
                '/' +
                item.date_in_str.slice(5, 7) +
                '/' +
                item.date_in_str.slice(8, 10)}
            </Col>
            <Col xs={6} sm={6} md={6} xl={6}>
              {'مجموع: ' +
                (item.bags_sum_weight ? item.bags_sum_weight/1000 : 0) +
                'کیلو'}
            </Col>
            <Col xs={6} sm={6} md={6} xl={6}>
              {'توزیع: ' + (item.folwerKg ? item.folwerKg/1000 : 0) + 'کیلو'}
            </Col>
            <Col xs={6} sm={6} md={6} xl={6}>
              {'فروش: ' + (item.sale ? item.sale/1000 : 0) + 'کیلو'}
            </Col>

            <Col xs={6} sm={6} md={6} xl={6}>
              {'سرگل: ' + (item.headG ? item.headG : 0) + 'گرم'}
            </Col>
            <Col xs={6} sm={6} md={6} xl={6}>
              وضعیت:
              {item.status < 3 && 'باز'}
              {item.status >= 3 && 'بسته'}
            </Col>
            <Col xs={12} sm={12} md={12} xl={12}>
              <Link
                className="textIcons"
                to={{
                  pathname: '/EmployeeList',
                  state: { id: item.id },
                }}
              >
                <Button variant="warning" size="sm" style={{ width: '100%' }}>
                  جزئیات
                </Button>
              </Link>
            </Col>
          </Row>
        </Col>
      ))}
    </Row>
  );

  return (
    <div>
      <Helmet>
        <title> شعبه لیست</title>
      </Helmet>
      {title}
      {showList}
    </div>
  );
}

EmployeeLists.propTypes = {
  dispatch: PropTypes.func.isRequired,
  employeeLists: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  employeeLists: makeSelectEmployeeLists(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(EmployeeLists);
