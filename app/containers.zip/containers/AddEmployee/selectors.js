import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the addEmployee state domain
 */

const selectAddEmployeeDomain = state => state.addEmployee || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by AddEmployee
 */

const makeSelectAddEmployee = () =>
  createSelector(
    selectAddEmployeeDomain,
    substate => substate,
  );

export default makeSelectAddEmployee;
export { selectAddEmployeeDomain };
