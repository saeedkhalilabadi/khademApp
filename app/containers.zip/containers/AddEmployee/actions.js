/*
 *
 * AddEmployee actions
 *
 */

import {
  INSERT_ADDEMPLOYEE,
  INSERT_ADDEMPLOYEE_SUCCESS,
  INSERT_ADDEMPLOYEE_ERROR,
  NEW_FORM,
  ALERT,
  GET_ROLES,
  GET_ROLES_SUCCESS,
  GET_ROLES_ERROR,
} from './constants';

export function insertAddemployee(data) {
  return {
    type: INSERT_ADDEMPLOYEE,
    data,
  };
}

export function insertAddemployeeSuccess(data) {
  return {
    type: INSERT_ADDEMPLOYEE_SUCCESS,
    data,
    massage: 'عملیات ثبت با موفقیت انجام شد',
  };
}

export function insertAddemployeeError(data) {
  return {
    type: INSERT_ADDEMPLOYEE_ERROR,
    data,
  };
}
export function newForm(value) {
  return {
    type: NEW_FORM,
    value,
  };
}
export function AlertMessage(createerror) {
  return {
    type: ALERT,
    createerror,
  };
}
export function getRoles() {
  return {
    type: GET_ROLES,
  };
}
export function getRolesSuccess(data) {
  return {
    type: GET_ROLES_SUCCESS,
    data,
  };
}
export function getRolesError(data) {
  return {
    type: GET_ROLES_ERROR,
    data,
  };
}
