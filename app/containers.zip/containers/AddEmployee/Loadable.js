/**
 *
 * Asynchronously loads the component for AddEmployee
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
