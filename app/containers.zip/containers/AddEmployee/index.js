/**
 *
 * AddEmployee
 *
 */

import React, { memo, useState } from 'react';
import { makeStyles } from '@mui/styles';
import PropTypes from 'prop-types';
import NumberFormat from 'react-number-format';

import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import Loading from 'components/Loading/Loadable';
import Badge from '@mui/material/Badge';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { Row, Col, Button, Alert, Form } from 'react-bootstrap';
import { setShowItem, employees_Get_Data } from 'containers/Employees/actions';
import MyAlert from '../../components/MyAlert/Loadable';
import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectAddEmployee from './selectors';
import { insertAddemployee, newForm, AlertMessage, getRoles } from './actions';
import '../../src/allStyles.css';
import './index.css';
import reducer from './reducer';
import saga from './saga';

const useStyles = makeStyles({
  formControl: {
    margin: '0px',
    minWidth: 150,
  },
  formControladdress: {
    minWidth: 250,
  },
  selectEmpty: {
    marginTop: '0px',
  },
  formControL1: {
    margin: 0,
    minWidth: 120,
  },
});

export function AddEmployee({ addEmployee, dispatch, props }) {
  useInjectReducer({ key: 'addEmployee', reducer });
  useInjectSaga({ key: 'addEmployee', saga });

  const [name, setname] = useState('');
  const [lname, setlname] = useState('');
  const [gender, setgender] = useState('');
  const [phone, setphone] = useState('');
  const [address, setaddress] = useState('');
  const [shaba, setshaba] = useState('');
  const [bankNumber, setbankNumber] = useState('');
  const [wage, setwage] = useState('');
  const [password, setpassword] = useState(11111);
  const [meliCode, setmeliCode] = useState('');
  const [getroles, setgetroles] = useState(true);
  const [tel, settel] = useState('');
  const [branche_name, setbranche_name] = useState('');

  console.log(addEmployee);
  if (getroles)
    setTimeout(() => {
      setgetroles(false);
      dispatch(getRoles());
    }, 200);
  if (addEmployee.createerror.status === 1)
    setTimeout(() => {
      dispatch(
        AlertMessage({
          value: '',
          status: 0,
        }),
      );
    }, 6000);

  const classes = useStyles();

  const form = (
    <>
      <Row className="form">
        <Col sm="12" className="title">
          ثبت شعبه جدید
        </Col>

        <Col sx={12} sm={12} md={3} xl={3} className="filde">
          <Form.Group className="mb-1" controlId="formBasicEmail">
            <Form.Text className="text-muted">خانم /آقای</Form.Text>

            <Form.Control
              as="select"
              size="sm"
              defaultValue={gender}
              custom
              style={{ maxWidth: '100px' }}
              onChange={e => {
                setgender(e.target.value);
              }}
            >
              <option> انتخاب کنید</option>

              <option value="آقای">آقای</option>
              <option value="خانم">خانم</option>
            </Form.Control>
          </Form.Group>
        </Col>

        <Col sx={12} sm={12} md={3} xl={3} className="filde">
          <Form.Group className="mb-1" controlId="formBasicEmail">
            <Form.Text className="text-muted">نام شعبه</Form.Text>

            <Form.Control
              size="sm"
              type="text"
              defaultValue={branche_name}
              placeholder=" نام شعبه"
              onChange={e => {
                setbranche_name(e.target.value);
              }}
            />
          </Form.Group>
        </Col>
        <Col sx={12} sm={12} md={3} xl={3} className="filde">
          <Form.Group className="mb-1" controlId="formBasicEmail">
            <Form.Text className="text-muted">نام </Form.Text>

            <Form.Control
              size="sm"
              type="text"
              defaultValue={name}
              placeholder="  نام "
              onChange={e => {
                setname(e.target.value);
              }}
            />
          </Form.Group>
        </Col>
        <Col sx={12} sm={12} md={3} xl={3} className="filde">
          <Form.Group className="mb-1" controlId="formBasicEmail">
            <Form.Text className="text-muted">نام و نام خانوادگی</Form.Text>

            <Form.Control
              size="sm"
              type="text"
              defaultValue={lname}
              placeholder="  نام و نام خانوادگی"
              onChange={e => {
                setlname(e.target.value);
              }}
            />
          </Form.Group>
        </Col>
        <Col sx={12} sm={12} md={6} xl={6} className="filde">
          <Form.Group className="mb-1" controlId="formBasicEmail">
            <Form.Text className="text-muted">شماره تلفن همراه</Form.Text>

            <Form.Control
              size="sm"
              defaultValue={phone}
              type="number"
              placeholder="شماره تلفن همراه"
              onChange={e => {
                setphone(e.target.value);
              }}
            />
          </Form.Group>
        </Col>
        <Col sx={12} sm={12} md={3} xl={3} className="filde">
          <Form.Group className="mb-1" controlId="formBasicEmail">
            <Form.Text className="text-muted">تلفن ثابت: </Form.Text>

            <Form.Control
              size="sm"
              defaultValue={tel}
              type="text"
              placeholder="تلفن ثابت"
              onChange={e => {
                settel(e.target.value);
              }}
            />
          </Form.Group>
        </Col>

        <Col sx={12} sm={12} md={3} xl={3} className="filde">
          <Form.Group className="mb-1" controlId="formBasicEmail">
            <Form.Text className="text-muted">کد ملی </Form.Text>

            <Form.Control
              size="sm"
              defaultValue={meliCode}
              type="number"
              placeholder=" کد ملی"
              onChange={e => {
                setmeliCode(e.target.value);
                setpassword(e.target.value);
              }}
            />
          </Form.Group>
        </Col>
        <Col sx={12} sm={12} md={3} xl={3} className="filde">
          <Form.Group className="mb-1" controlId="formBasicEmail">
            <Form.Text className="text-muted">آدرس : </Form.Text>

            <Form.Control
              size="sm"
              defaultValue={address}
              type="text"
              placeholder="آدرس"
              onChange={e => {
                setaddress(e.target.value);
              }}
            />
          </Form.Group>
        </Col>

        <Col sx={12} sm={12} md={3} xl={3} className="filde">
          <Form.Group className="mb-1" controlId="formBasicEmail">
            <Form.Text className="text-muted">شماره شبا : </Form.Text>
            <NumberFormat
              defaultValue={shaba}
              placeholder="شماره شبا"
              format="IR## #### #### #### #### #### ##"
              style={{ direction: 'ltr', width: '100%' }}
              mask="_"
              onValueChange={e => {
                setshaba(e.value);
                console.log(e.value, 'test');
              }}
            />
          </Form.Group>
        </Col>
        <Col sx={12} sm={12} md={3} xl={3} className="filde">
          <Form.Group className="mb-1" controlId="formBasicEmail">
            <Form.Text className="text-muted">شماره کارت : </Form.Text>
            <NumberFormat
              defaultValue={bankNumber}
              placeholder="شماره کارت"
              format="#### #### #### ####"
              style={{ direction: 'ltr', width: '100%' }}
              mask="_"
              onValueChange={e => {
                setbankNumber(e.value);
                console.log(e.value, 'test');
              }}
            />
          </Form.Group>
        </Col>

        <Col sx={12} sm={12} md={6} xl={6} className="filde">
          <Button
            style={{ margin: 'auto', marginTop: '30px', minWidth: '100%' }}
            variant="warning"
            size="sm"
            onClick={handelinsert}
          >
            ثبت{' '}
          </Button>
        </Col>
        <Col sx={12} sm={12} md={6} xl={6} className="filde">
          <Link to="/employees">
            <Button
              style={{ margin: 'auto', marginTop: '30px', minWidth: '100%' }}
              variant="outline-warning"
              size="sm"
            >
              برگشت
            </Button>
          </Link>
        </Col>
      </Row>
    </>
  );
  function handelinsert() {
    if (gender.length < 3) {
      dispatch(
        AlertMessage({
          value: 'جنسیت را انتخاب کنید',
          status: 1,
        }),
      );
    } else if (branche_name.length < 3) {
      dispatch(
        AlertMessage({
          value: 'نام شعبه به درستی وارد نشده است',
          status: 1,
        }),
      );
    } else if (name.length < 3) {
      dispatch(
        AlertMessage({
          value: 'نام  به درستی وارد نشده است',
          status: 1,
        }),
      );
    } else if (lname.length < 3) {
      dispatch(
        AlertMessage({
          value: 'نام  خانوادگی  به درستی وارد نشده است',
          status: 1,
        }),
      );
    } else if (phone.length < 10) {
      dispatch(
        AlertMessage({
          value: 'شماره تلفن همراه به درستی وارد نشده است',
          status: 1,
        }),
      );
    } else
      dispatch(
        insertAddemployee({
          name,
          lname,
          gender,
          phone,
          address,
          meliCode,
          shaba,
          bankNumber,
          wage,
          tel,
          password,
          branche_name,
        }),
      );
  }
  const successform = (
    <div className="body-addemployee">
      <Row className="form" justify-content-center>
        <Col
          sm="12"
          className="filde"
          style={{ color: 'black', fontSize: '30px' }}
        >
          اطلاعات شعبه با موفقیت ثبت شد <br />
          <br />
          <br />
          <br />
          <Link to="/employees">
            <Button variant="warning" style={{ width: 200 }}>
              تایید
            </Button>
          </Link>
        </Col>
      </Row>
    </div>
  );

  return (
    <div
      onKeyDown={e => {
        if (e.key === 'Enter') {
          const fields =
            Array.from(e.currentTarget.querySelectorAll('input')) || [];
          const position = fields.indexOf(
            e.target, // as HTMLInputElement (for TypeScript)
          );
          fields[position + 1] && fields[position + 1].focus();
        }
      }}
    >
      <Helmet>
        <title>ثبت شعبه جدید</title>
        <meta name="description" content="Description of AddEmployee" />
      </Helmet>
      {addEmployee.load == 1 ? <Loading /> : null}
      {addEmployee.createerror.status === 1 ? (
        <MyAlert severity="error" message={addEmployee.createerror.value} />
      ) : (
        <div />
      )}
      {addEmployee.createsuccess === 0 ? form : successform}
    </div>
  );
}

AddEmployee.propTypes = {
  dispatch: PropTypes.func.isRequired,
  addEmployee: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  addEmployee: makeSelectAddEmployee(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(AddEmployee);
