/*
 *
 * AddEmployee constants
 *
 */

export const INSERT_ADDEMPLOYEE = 'app/AddEmployee/INSERT_ADDEMPLOYEE';
export const INSERT_ADDEMPLOYEE_SUCCESS =
  'app/AddEmployee/INSERT_ADDEMPLOYEE_SUCCESS';
export const INSERT_ADDEMPLOYEE_ERROR =
  'app/AddEmployee/INSERT_ADDEMPLOYEE_ERROR';
export const NEW_FORM = 'app/AddEmployee/NEW_FORM';
export const ALERT = 'app/AddEmployee/ALERT';

export const GET_ROLES = 'app/AddEmployee/GET_ROLES';
export const GET_ROLES_SUCCESS = 'app/AddEmployee/GET_ROLES_SUCCESS';
export const GET_ROLES_ERROR = 'app/AddEmployee/GET_ROLES_ERROR';
