// import { selectAddEmployeeDomain } from '../selectors';

describe('selectAddEmployeeDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
