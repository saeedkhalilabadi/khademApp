/*
 *
 * AddEmployee reducer
 *
 */
import produce from 'immer';
import {
  NEW_FORM,
  INSERT_ADDEMPLOYEE,
  INSERT_ADDEMPLOYEE_ERROR,
  INSERT_ADDEMPLOYEE_SUCCESS,
  ALERT,
  GET_ROLES,
  GET_ROLES_SUCCESS,
  GET_ROLES_ERROR,
} from './constants';

export const initialState = {
  load: 0,
  roles: [],
  createsuccess: 0,
  createerror: { value: ' ', status: 0 },
};

/* eslint-disable default-case, no-param-reassign */
const addEmployeeReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case INSERT_ADDEMPLOYEE:
        draft.load = 1;
        break;
      case INSERT_ADDEMPLOYEE_SUCCESS:
        draft.load = 0;
        draft.createerror.status = 0;
        draft.createsuccess = 1;
        break;
      case INSERT_ADDEMPLOYEE_ERROR:
        draft.load = 0;
        console.log(action.data.data.errors, 'kk');
        draft.error = action.data.data.errors;
        if (action.data.data.errors.meliCode)
          draft.createerror.value = action.data.data.errors.meliCode;
        else if (action.data.data.errors.phone)
          draft.createerror.value = action.data.data.errors.phone;
        else draft.createerror.value = 'ثبت اطلاعات موفقیت آمیز نبود';

        draft.createerror.status = 1;

        break;

      case ALERT:
        draft.createerror = action.createerror;
        break;
      case NEW_FORM:
        draft.createerror = { value: ' ', status: 0 };
        draft.createsuccess = 0;

        break;

      case GET_ROLES:
        break;
      case GET_ROLES_SUCCESS:
        console.log(action.data);
        draft.roles = action.data.data.data;
        break;
      case GET_ROLES_ERROR:
        break;
    }
  });

export default addEmployeeReducer;
