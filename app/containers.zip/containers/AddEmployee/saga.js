import { take, takeLatest, call, put, select } from 'redux-saga/effects';
import axios from '../axios/axios-user';
import { insertAddemployeeSuccess, insertAddemployeeError } from './actions';
import { INSERT_ADDEMPLOYEE } from './constants';

function* createemployee(data) {
  let Data = null;
  let e = null;
  console.log(data.data);
  yield axios
    .post('api/branches', data.data, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      Data = response;
      console.log(Data, 'ss');

      e = true;
    })
    .catch(error => {
      Data = error;
      console.log(error.response, 'ee');

      e = false;
    });

  if (e) yield put(insertAddemployeeSuccess(Data.data));
  else yield put(insertAddemployeeError(Data.response));
}

// Individual exports for testing
export default function* addEmployeeSaga() {
  yield takeLatest(INSERT_ADDEMPLOYEE, createemployee);

  // See example in containers/HomePage/saga.js
}
