/*
 *
 * RegistrationHead reducer
 *
 */
import produce from 'immer';
import {
  GET_DATA,
  GET_DATA_ERROR,
  GET_DATA_SUCCESS,
  SEARCH,
} from './constants';

export const initialState = {
  data: [],
  searchSubs: [],
};

/* eslint-disable default-case, no-param-reassign */
const registrationHeadReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case SEARCH:
        draft.searchSubs = draft.data.filter(
          item =>
            item.name
              .toLowerCase()
              .match(new RegExp(action.data.toLowerCase())) ||
            item.lname
              .toLowerCase()
              .match(new RegExp(action.data.toLowerCase())) ||
            item.code
              .toLowerCase()
              .match(new RegExp(action.data.toLowerCase())),
        );

        break;
      case GET_DATA:
        draft.load = 1;
        break;
      case GET_DATA_SUCCESS:
        draft.load = 0;
        draft.data = action.data.data;
        draft.searchSubs = action.data.data;

        break;
      case GET_DATA_ERROR:
        break;
    }
  });

export default registrationHeadReducer;
