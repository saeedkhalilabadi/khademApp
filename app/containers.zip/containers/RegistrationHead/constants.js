/*
 *
 * RegistrationHead constants
 *
 */



export const SEARCH = 'app/RegistrationHead/SEARCH';

export const GET_DATA = 'app/RegistrationHead/GET_DATA';
export const GET_DATA_SUCCESS = 'app/RegistrationHead/GET_DATA_SUCCESS';
export const GET_DATA_ERROR = 'app/RegistrationHead/GET_DATA_ERROR';