import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the registrationHead state domain
 */

const selectRegistrationHeadDomain = state =>
  state.registrationHead || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by RegistrationHead
 */

const makeSelectRegistrationHead = () =>
  createSelector(
    selectRegistrationHeadDomain,
    substate => substate,
  );

export default makeSelectRegistrationHead;
export { selectRegistrationHeadDomain };
