// import { selectRegistrationHeadDomain } from '../selectors';

describe('selectRegistrationHeadDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
