/**
 *
 * RegistrationHead
 *
 */

import React, { memo, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { Link } from 'react-router-dom';
import { Row, Col, Form, Button } from 'react-bootstrap';
import IconButton from '@mui/material/IconButton';
import Paper from '@mui/material/Paper';
import InputBase from '@mui/material/InputBase';
import SearchIcon from '@mui/icons-material/Search';

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectRegistrationHead from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import { getData, search } from './actions';
import './index.css';
import '../../src/allStyles.css';

export function RegistrationHead({ registrationHead, dispatch, props }) {
  useInjectReducer({ key: 'registrationHead', reducer });
  useInjectSaga({ key: 'registrationHead', saga });
  const [getdata, setgetdata] = useState(true);
  console.log(registrationHead);

  if (getdata)
    setTimeout(() => {
      setgetdata(false);
      dispatch(getData());
    }, 50);

  const showList = (
    <Row>
      <Col className="title" xs={12} sm={12} md={12} xl={12}>
        ثبت سرگل مشترک
      </Col>
      <Col xs={6} sm={6} md={6} xl={6}>
        <Paper
          component="form"
          sx={{
            direction: 'rtl',
            margin: 'auto',
            marginTop: '10px',
            marginBottom: '10px',
            p: '2px 4px',
            display: 'flex',
            alignItems: 'center',
            width: '100%',
          }}
        >
          <InputBase
            sx={{ ml: 1, flex: 1 }}
            placeholder="نام مشترک"
            type="text"
            inputProps={{ 'aria-label': 'جستجو' }}
            onChange={e => dispatch(search(e.target.value))}
          />

          <SearchIcon />
        </Paper>
      </Col>
      <Col xs={6} sm={6} md={6} xl={6}>
        <Paper
          component="form"
          sx={{
            direction: 'rtl',
            margin: 'auto',
            marginTop: '10px',
            marginBottom: '10px',
            p: '2px 4px',
            display: 'flex',
            alignItems: 'center',
            width: '100%',
          }}
        >
          <InputBase
            sx={{ ml: 1, flex: 1 }}
            placeholder="کداشتراک"
            type="number"
            inputProps={{ 'aria-label': 'جستجو' }}
            onChange={e => dispatch(search(e.target.value))}
          />

          <SearchIcon />
        </Paper>
      </Col>

      {registrationHead.searchSubs.length == 0 ? (
        <p style={{ textAlign: 'center' }}>مشترکی پیدا نشد</p>
      ) : (
        <>
          {registrationHead.searchSubs.map(sub => (
            <Col className="subItems" key={sub.id}>
              <Link
                className="textIcons"
                to={{
                  pathname: '/RegistrationHead2',
                  state: {
                    id: sub.id,
                    name: sub.gender + ' ' + sub.name + ' ' + sub.lname,
                  },
                }}
              >
                <Row>
                  <Col xs={12} sm={12} md={12} xl={12}>
                    {sub.code}
                  </Col>
                  <Col xs={12} sm={12} md={12} xl={12}>
                    {sub.gender + ' ' + sub.name + ' ' + sub.lname}
                  </Col>
                 
                </Row>
              </Link>
            </Col>
          ))}
        </>
      )}
    </Row>
  );
  return (
    <div>
      <Helmet>
        <title>انتخاب مشترک</title>
      </Helmet>
      {showList}
    </div>
  );
}

RegistrationHead.propTypes = {
  dispatch: PropTypes.func.isRequired,
  registrationHead: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  registrationHead: makeSelectRegistrationHead(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(RegistrationHead);
