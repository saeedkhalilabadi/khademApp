import React, { Component } from 'react';

export default class Shaba extends Component {
  constructor(...props) {
    super(...props);

    this.state = {
      copySuccess: false,
      text: this.props.text,
    };
  }

  copyCodeToClipboard = () => {
    const el = this.textArea;
    el.select();
    document.execCommand('copy');
    this.setState({ copySuccess: true });
  };

  render() {
    console.log(this.props.text);
    return (
      <div>
        <div>
          <textarea
            style={{ opacity: '0', position: 'fixed', top: '-1000px' }}
            ref={textarea => (this.textArea = textarea)}
            value={this.props.text}
          />
        </div>
        <div>
          <button onClick={() => this.copyCodeToClipboard()}>
            {this.state.copySuccess ? (
              <div style={{ color: 'green' }}>کپی شد</div>
            ) : (
              <div style={{ color: 'black' }}>کپی!</div>
            )}
          </button>
        </div>
      </div>
    );
  }
}
