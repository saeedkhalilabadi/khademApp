// import { selectEmployeeDomain } from '../selectors';

describe('selectEmployeeDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
