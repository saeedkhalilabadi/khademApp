/**
 *
 * Employee
 *
 */

import React, { memo, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { Row, Col, Form, Button } from 'react-bootstrap';
import 'react-modern-calendar-datepicker/lib/DatePicker.css';
import DatePicker from 'react-modern-calendar-datepicker';
import Switch from '@mui/material/Switch';
import { makeStyles } from '@mui/styles';
import AppBar from '@mui/material/AppBar';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import EditIcon from '@mui/icons-material/Edit';
import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import EmployeeArchive from '../EmployeeArchive/Loadable';
import EmployeePayments from '../EmployeePayments/Loadable';
import EmployeeLists from '../EmployeeLists/Loadable';
import EmployeeSalary from '../EmployeeSalary/Loadable';
import EmployeeStatus from '../EmployeeStatus/Loadable';
import NumberFormat from 'react-number-format';
import { Link } from 'react-router-dom';

import makeSelectEmployee from './selectors';
import '../../src/allStyles.css';
import './index.css';
import { getData, updateData } from './actions';
import reducer from './reducer';
import saga from './saga';
import Shaba from './test';

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`scrollable-auto-tabpanel-${index}`}
      aria-labelledby={`scrollable-auto-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box p={3}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired,
};

function a11yProps(index) {
  return {
    id: `scrollable-auto-tab-${index}`,
    'aria-controls': `scrollable-auto-tabpanel-${index}`,
  };
}

const useStyles = makeStyles({
  root: {
    direction: 'rtl',
    flexGrow: 1,
    width: '100%',
  },
});

export function Employee({ employee, dispatch, props }) {
  useInjectReducer({ key: 'employee', reducer });
  useInjectSaga({ key: 'employee', saga });
  console.log(props);
  const classes = useStyles();
  const [value, setValue] = React.useState(0);
  const [start, setstart] = useState(0);
  const [end, setend] = useState(0);
  const [date, setdate] = useState('today');
  const [clipboardContent, setclipboardContent] = useState(' ');

  // console.log(props, 'props');
  console.log(employee, 'employee');
  //console.log(props.substate.location.state.id, 'employee props');
  const [getdata, setgetdata] = useState(true);
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  if (getdata)
    setTimeout(() => {
      setgetdata(false);
      dispatch(getData(props.substate.location.state.id));
    }, 200);
  const words = {
    brancheDisable: 'غیر فعال',
    brancheEnable: 'فعال',
  };
  const form =
    employee.data == null ? null : (
      <Row className="form">
        <Col sx={12} sm={12} md={10} xl={10}>
          <Row>
            <Col sx={12} sm={12} md={4} xl={4} className="displayMainProfile">
              <img
                src={employee.data.profile}
                className={
                  props.screen.width > 768
                    ? 'EmployeeProfilePic'
                    : 'EmployeeProfilePicMobile'
                }
              />
            </Col>

            <Col xs={12} sm={12} md={12} xl={12} className="displayMainInfo">
              <Row>
                <Col xs={6} sm={6} md={6} xl={6} className="employeeItemInfo">
                  <p className="fieldName">کد شعبه :</p>
                  {employee.data.id}
                </Col>

                <Col
                  xs={6}
                  sm={6}
                  md={6}
                  xl={6}
                  className="employeeItemInfo brancheName"
                >
                  {employee.data.branche_name}
                </Col>

                <Col
                  sx={12}
                  sm={12}
                  md={12}
                  xl={12}
                  className="employeeItemInfo"
                >
                  <p className="fieldName">وضعیت شعبه :</p>

                  {employee.data.status == 0
                    ? words.brancheDisable
                    : words.brancheEnable}
                  <Switch
                    defaultChecked={employee.data.status == 0 ? false : true}
                    onChange={e => {
                      console.log(e.target.value);
                      dispatch(
                        updateData({
                          ...employee.data,

                          status: e.target.checked == true ? '1' : '0',
                        }),
                      );
                    }}
                  />
                </Col>
                <Col
                  sx={12}
                  sm={12}
                  md={12}
                  xl={12}
                  className="employeeItemInfo"
                >
                  <p className="fieldName">نام مسئول :</p>
                  {employee.data.gender +
                    ' ' +
                    employee.data.name +
                    ' ' +
                    employee.data.lname}
                </Col>
                <Col
                  sx={12}
                  sm={12}
                  md={12}
                  xl={12}
                  className="employeeItemInfo"
                >
                  <p className="fieldName">تعداد مشترک: </p>
                  {employee.data.subs_count}
                </Col>
                <Col
                  sx={12}
                  sm={12}
                  md={12}
                  xl={12}
                  className="employeeItemInfo"
                >
                  <p className="fieldName">تلفن :</p>
                  {employee.data.phone}
                </Col>
                <Col
                  sx={12}
                  sm={12}
                  md={12}
                  xl={12}
                  className="employeeItemInfo"
                >
                  <p className="fieldName">تلفن ثابت :</p>
                  {employee.data.tel}
                </Col>
                <Col
                  sx={12}
                  sm={12}
                  md={12}
                  xl={12}
                  className="employeeItemInfo"
                >
                  <p className="fieldName">آدرس :</p>
                  {employee.data.address}
                </Col>
                <Col
                  sx={12}
                  sm={12}
                  md={12}
                  xl={12}
                  className="employeeItemInfo"
                >
                  <p className="fieldName"> شماره شبا: </p>
                  {employee.data.shaba ? (
                    <>
                      {'IR' + employee.data.shaba}
                      <Shaba text={'IR' + employee.data.shaba} />
                    </>
                  ) : (
                    'ثبت نشده'
                  )}
                </Col>

                <Col
                  sx={12}
                  sm={12}
                  md={12}
                  xl={12}
                  className="employeeItemInfo"
                >
                  <p className="fieldName"> شماره کارت :</p>
                  {employee.data.bankNumber ? (
                    <>
                      {employee.data.bankNumber}
                      <Shaba text={employee.data.bankNumber} />
                    </>
                  ) : (
                    'ثبت نشده'
                  )}
                </Col>
                <Col
                  sx={12}
                  sm={12}
                  md={12}
                  xl={12}
                  className="employeeItemInfo"
                >
                  <p className="fieldName">کد ملی :</p>

                  {employee.data.meliCode}
                </Col>
                <Col
                  sx={12}
                  sm={12}
                  md={12}
                  xl={12}
                  className="employeeItemInfo"
                >
                  <p className="fieldName">وضعیت حساب :</p>
                  <NumberFormat
                    value={Number(employee.data.financialAccountStatus.price)}
                    displayType={'text'}
                    thousandSeparator={true}
                    renderText={(value, props) => (
                      <span {...props}>{value} تومان </span>
                    )}
                  />
                  {employee.data.financialAccountStatus.status}
                </Col>
              </Row>
            </Col>
          </Row>
        </Col>

        <Col sx={12} sm={12} md={12} xl={12} className="editEmployee">
          <Link
            to={{
              pathname: '/employeeEdit',
              state: { id: employee.data.id },
            }}
          >
            <Button variant="warning">
              <EditIcon />
              ویرایش
            </Button>
          </Link>
        </Col>
      </Row>
    );

  const infoTabs = (
    <div className={classes.root}>
      <AppBar position="static" color="default">
        <Tabs
          value={value}
          onChange={handleChange}
          indicatorColor="primary"
          textColor="primary"
          variant="scrollable"
          scrollButtons="auto"
          aria-label="scrollable auto tabs example"
        >
          <Tab label=" دریافت ها" {...a11yProps(0)} />
          <Tab label="حق الزحمه" {...a11yProps(1)} />
          <Tab label="لیست ها" {...a11yProps(2)} />
          <Tab label="بایگانی" {...a11yProps(3)} />
        </Tabs>
      </AppBar>
      <TabPanel value={value} index={0}>
        <EmployeePayments props={{ id: props.substate.location.state.id }} />
      </TabPanel>
      <TabPanel value={value} index={1}>
        <EmployeeSalary props={{ id: props.substate.location.state.id }} />
      </TabPanel>{' '}
      <TabPanel value={value} index={2}>
        <EmployeeLists props={{ id: props.substate.location.state.id }} />
      </TabPanel>
      <TabPanel value={value} index={3}>
        <EmployeeArchive props={{ id: props.substate.location.state.id }} />
      </TabPanel>
    </div>
  );

  return (
    <>
      {form}
      {infoTabs}
    </>
  );
}

Employee.propTypes = {
  dispatch: PropTypes.func.isRequired,
  employee: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  employee: makeSelectEmployee(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(Employee);
