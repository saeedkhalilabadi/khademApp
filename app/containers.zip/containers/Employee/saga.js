import { takeLatest, call, put, select } from 'redux-saga/effects';
import { GET_DATA,UPDATE_DATA } from './constants';
import { getDataSuccess, getDataError,updateDataSuccess,updateDataError } from './actions';
import axios from 'containers/axios/axios-user';

export function* getdata(params) {
  let data;
  let e = null;

  yield axios
    .get('api/branches/' + params.data, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      // console.log(response.data, 'employees1');
      data = response.data;
      e = true;
    })
    .catch(error => {
      //console.log(error, 'دریافت اطلاعات کارمندان با مشکل مواجه شد');
      data = error.response;
      e = false;
    });
  if (e) yield put(getDataSuccess(data));
  else yield put(getDataError(data));
}

export function* updatedata(params) {
  let data;
  let e = null;

  yield axios
    .put('api/branches/' + params.data.id,params.data ,{
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      // console.log(response.data, 'employees1');
      data = response.data;
      e = true;
    })
    .catch(error => {
      //console.log(error, 'دریافت اطلاعات کارمندان با مشکل مواجه شد');
      data = error.response;
      e = false;
    });
  if (e) yield put(getDataSuccess(data));
  else yield put(getDataError(data));
}

// Individual exports for testing

export default function* employeeSaga() {
  yield takeLatest(GET_DATA, getdata);
  yield takeLatest(UPDATE_DATA, updatedata);

  // See example in containers/HomePage/saga.js
}
