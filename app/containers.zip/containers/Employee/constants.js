/*
 *
 * Employee constants
 *
 */

export const GET_DATA = 'app/Employee/GET_DATA';
export const GET_DATA_SUCCESS = 'app/Employee/GET_DATA_SUCCESS';
export const GET_DATA_ERROR = 'app/Employee/GET_DATA_ERROR';

export const UPDATE_DATA = 'app/Employee/UPDATE_DATA';
export const UPDATE_DATA_SUCCESS = 'app/Employee/UPDATE_DATA_SUCCESS';
export const UPDATE_DATA_ERROR = 'app/Employee/UPDATE_DATA_ERROR';


export const SET_ACCESS = 'app/Employee/SET_ACCESS';
export const SET_ACCESS_SUCCESS = 'app/Employee/SET_ACCESS_SUCCESS';
export const SET_ACCESS_ERROR = 'app/Employee/SET_ACCESS_ERROR';

export const GET_PRESENCES = 'app/Employee/GET_PRESENCES';
export const GET_PRESENCES_SUCCESS = 'app/Employee/GET_PRESENCES_SUCCESS';
export const GET_PRESENCES_ERROR = 'app/Employee/GET_PRESENCES_ERROR';
