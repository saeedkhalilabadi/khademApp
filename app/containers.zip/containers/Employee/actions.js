/*
 *
 * Employee actions
 *
 */

import {
  GET_DATA,
  GET_DATA_ERROR,
  GET_DATA_SUCCESS,
  UPDATE_DATA,
  UPDATE_DATA_ERROR,
  UPDATE_DATA_SUCCESS,
  GET_PRESENCES,
  GET_PRESENCES_ERROR,
  GET_PRESENCES_SUCCESS,
  SET_ACCESS,
  SET_ACCESS_ERROR,
  SET_ACCESS_SUCCESS,
} from './constants';

export function getData(data) {
  return {
    type: GET_DATA,
    data,
  };
}

export function getDataSuccess(data) {
  return {
    type: GET_DATA_SUCCESS,
    data,
  };
}
export function getDataError(data) {
  return {
    type: GET_DATA_ERROR,
    data,
  };
}

export function updateData(data) {
  return {
    type: UPDATE_DATA,
    data,
  };
}

export function updateDataSuccess(data) {
  return {
    type: UPDATE_DATA_SUCCESS,
    data,
  };
}
export function updateDataError(data) {
  return {
    type: UPDATE_DATA_ERROR,
    data,
  };
}
export function getPresences(data) {
  return {
    type: GET_PRESENCES,
    data,
  };
}

export function getPresencesSuccess(data) {
  return {
    type: GET_PRESENCES_SUCCESS,
    data,
  };
}
export function getPresencesError(data) {
  return {
    type: GET_PRESENCES_ERROR,
    data,
  };
}
export function setAccess(data) {
  return {
    type: SET_ACCESS,
    data,
  };
}

export function setAccessSuccess(data) {
  return {
    type: SET_ACCESS_SUCCESS,
    data,
  };
}
export function setAccessError(data) {
  return {
    type: SET_ACCESS_ERROR,
    data,
  };
}
