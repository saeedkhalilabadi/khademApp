/*
 *
 * Employee reducer
 *
 */
import produce from 'immer';
import {
  GET_DATA,
  GET_DATA_ERROR,
  GET_DATA_SUCCESS,
  UPDATE_DATA,
  UPDATE_DATA_ERROR,
  UPDATE_DATA_SUCCESS,
  GET_PRESENCES,
  GET_PRESENCES_ERROR,
  GET_PRESENCES_SUCCESS,
  SET_ACCESS,
  SET_ACCESS_ERROR,
  SET_ACCESS_SUCCESS,
} from './constants';

export const initialState = {
  data: null,
  presences: null,
};

/* eslint-disable default-case, no-param-reassign */
const employeeReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case GET_DATA:
        break;
      case GET_DATA_SUCCESS:
        draft.data = action.data.data;
        break;
      case GET_DATA_ERROR:
        // console.log(action.data);
        break;
      case UPDATE_DATA:
        break;
      case UPDATE_DATA_SUCCESS:
        draft.data = action.data.data;
        break;
      case UPDATE_DATA_ERROR:
        // console.log(action.data);
        break;
      case GET_PRESENCES:
        break;
      case GET_PRESENCES_SUCCESS:
        action.data.status == 'true'
          ? (draft.presences = action.data.data)
          : null;

        console.log(action.data.data, 'redu');
        break;
      case GET_PRESENCES_ERROR:
        // console.log(action.data);
        break;
      case SET_ACCESS:
        break;
      case SET_ACCESS_SUCCESS:
        // draft.data = action.data.data;
        break;
      case SET_ACCESS_ERROR:
        // console.log(action.data);
        break;
    }
  });

export default employeeReducer;
