/**
 *
 * Asynchronously loads the component for AdminBagRegister
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
