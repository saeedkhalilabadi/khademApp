/*
 *
 * AdminBagRegister reducer
 *
 */
import React from 'react';
import produce from 'immer';
import {
  GET_DATA,
  GET_DATA_ERROR,
  GET_DATA_SUCCESS,
  ADD_DATA,
  ADD_DATA_ERROR,
  ADD_DATA_SUCCESS,
  EDIT_DATA,
  EDIT_DATA_ERROR,
  EDIT_DATA_SUCCESS,
  DELETE_DATA,
  DELETE_DATA_ERROR,
  DELETE_DATA_SUCCESS,
} from './constants';
import MyAlert from '../../components/MyAlert/Loadable';

export const initialState = {
  load: 0,
  data: [],

  date: null,
  branches: [],
  successDelete: -1,
};

/* eslint-disable default-case, no-param-reassign */
const adminBagRegisterReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case GET_DATA:
        draft.successDelete = -1;

        draft.load = 1;
        break;
      case GET_DATA_SUCCESS:
        draft.successDelete = -1;

        draft.load = 0;
        if (action.data.status == 'true') {
          draft.data = action.data.data;
          draft.branches = action.data.branches;
        }
        draft.date = action.data.date;
        break;
      case GET_DATA_ERROR:
        draft.successDelete = -1;

        draft.load = 0;

        break;
      case ADD_DATA:
        draft.successDelete = -1;

        draft.load = 1;
        break;
      case ADD_DATA_SUCCESS:
        draft.successDelete = -1;

        draft.load = 0;
        if (action.data.status == 'true') draft.data = action.data.data;

        break;
      case ADD_DATA_ERROR:
        draft.successDelete = -1;

        draft.load = 0;

        break;
      case EDIT_DATA:
        draft.successDelete = -1;

        draft.load = 1;
        break;
      case EDIT_DATA_SUCCESS:
        draft.load = 0;

        if (action.data.status == 'true') {
          draft.data = action.data.data;
          draft.successDelete = (
            <MyAlert severity="success" message="ویرایش با موفقیت انجام شد" />
          );
        } else
          draft.successDelete = (
            <MyAlert severity="error" message={action.data.message} />
          );

        break;
      case EDIT_DATA_ERROR:
        draft.successDelete = -1;

        draft.load = 0;

        break;
      case DELETE_DATA:
        draft.successDelete = -1;
        draft.load = 1;
        break;
      case DELETE_DATA_SUCCESS:
        draft.load = 0;

        if (action.data.status == 'true') {
          draft.data = action.data.data;
          draft.successDelete = (
            <MyAlert severity="success" message="حذف با موفقیت انجام شد" />
          );
        } else
          draft.successDelete = (
            <MyAlert severity="error" message={action.data.message} />
          );
        break;
      case DELETE_DATA_ERROR:
        draft.successDelete = -1;
        draft.load = 0;

        break;
    }
  });

export default adminBagRegisterReducer;
