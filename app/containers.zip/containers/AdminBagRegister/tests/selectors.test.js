// import { selectAdminBagRegisterDomain } from '../selectors';

describe('selectAdminBagRegisterDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
