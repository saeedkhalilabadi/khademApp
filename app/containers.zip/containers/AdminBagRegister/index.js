/**
 *
 * AdminBagRegister
 *
 */

import React, { memo, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import AppBar from '@mui/material/AppBar';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import { makeStyles } from '@mui/styles';

import 'react-modern-calendar-datepicker/lib/DatePicker.css';
import DatePicker from 'react-modern-calendar-datepicker';
import { Row, Col, Form, Button } from 'react-bootstrap';
import AddIcon from '@mui/icons-material/Add';
import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectAdminBagRegister from './selectors';
import Loading from '../../components/Loading/Loadable';
import reducer from './reducer';
import saga from './saga';
import './index.css';
import '../../src/allStyles.css';
import { getData, addData, editData, deleteData } from './actions';

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`scrollable-auto-tabpanel-${index}`}
      aria-labelledby={`scrollable-auto-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box p={3}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired,
};

function a11yProps(index) {
  return {
    id: `scrollable-auto-tab-${index}`,
    'aria-controls': `scrollable-auto-tabpanel-${index}`,
  };
}

const useStyles = makeStyles({
  root: {
    direction: 'rtl',
    flexGrow: 1,
    width: '100%',
  },
});

export function AdminBagRegister({ adminBagRegister, dispatch, props }) {
  useInjectReducer({ key: 'adminBagRegister', reducer });
  useInjectSaga({ key: 'adminBagRegister', saga });

  const classes = useStyles();
  const [value, setValue] = useState(0);
  const [getdata, setgetdata] = useState(true);
  const [date, setdate] = useState('today');
  const [addBage, setaddBage] = useState(false);
  const [weight, setweight] = useState('');

  const [selectedBag, setselectedBag] = useState(0);

  const [branche_id, setbranche_id] = useState(0);

  console.log('branch', branche_id);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  console.log(adminBagRegister);
  if (getdata)
    setTimeout(() => {
      setgetdata(false);
      dispatch(
        getData({
          date,
        }),
      );
    }, 50);
  const addNew = (
    <Row className="form">
      <Col xs={9} sm={9} md={9} xl={9} className="fieldItem">
        <Form.Group className="mb-1" controlId="formBasicEmail">
          <Form.Text className="text-muted">وزن کیسه </Form.Text>

          <Form.Control
            size="sm"
            value={weight}
            style={{ maxWidth: '100px', display: 'inline' }}
            type="number"
            placeholder="وزن (کیلو)"
            onChange={e => {
              setweight(e.target.value);
            }}
          />
        </Form.Group>
      </Col>
      <Col xs={3} sm={3} md={3} xl={3} className="fieldItem">
        <Button
          variant="warning"
          style={{ width: '100%' }}
          size="sm"
          onClick={() => {
            dispatch(
              addData(
                date == 'today'
                  ? {
                      date,
                      weight,
                      weight: weight,
                      branche_id:
                        value < 2
                          ? ''
                          : adminBagRegister.branches[value - 2].id,
                    }
                  : {
                      date: 'date',
                      y: date.year,
                      m: date.month,
                      d: date.day,
                      weight: weight,
                      branche_id:
                        value < 2
                          ? ''
                          : adminBagRegister.branches[value - 2].id,
                    },
              ),
            );
            setweight('');
            setaddBage(false);
          }}
        >
          ثبت
        </Button>
      </Col>
    </Row>
  );

  function handelBagSattus(status) {
    switch (status) {
      case '1':
        return '#ffff00';
        break;
      case '2':
        return '#ff9800';
        break;
      case '3':
        return '#76ff03';
        break;
      default:
        break;
    }
  }

  function selectedForm(bagIndex) {
    return (
      <Row className="form">
        <Col xs={6} sm={6} md={3} xl={3} className="fieldItem">
          <Form.Group className="mb-1" controlId="formBasicEmail">
            <Form.Text className="text-muted"> شعبه</Form.Text>

            <Form.Control
              as="select"
              size="sm"
              defaultValue={
                adminBagRegister.data[bagIndex].del
                  ? adminBagRegister.data[bagIndex].del.branche_id
                  : 0
              }
              onChange={e => setbranche_id(e.target.value)}
              custom
            >
              <option value={0}> انتخاب کنید</option>

              {adminBagRegister.branches.map(branche => (
                <option value={branche.id}>
                  {branche.branche_name +
                    ':' +
                    branche.name +
                    ' ' +
                    branche.lname}
                </option>
              ))}
            </Form.Control>
          </Form.Group>
        </Col>

        <Col xs={5} sm={5} md={5} xl={5} className="fieldItem">
          <Form.Group className="mb-1" controlId="formBasicEmail">
            <Form.Text className="text-muted">وزن کیسه </Form.Text>

            <Form.Control
              size="sm"
              value={weight}
              style={{ maxWidth: '100px', display: 'inline' }}
              type="number"
              placeholder="وزن (کیلو)"
              onChange={e => {
                setweight(e.target.value);
              }}
            />
          </Form.Group>
        </Col>
        <Col xs={6} sm={6} md={4} xl={4} className="fieldItem">
          <Button
            variant="warning"
            style={{ width: '100%', marginTop: '50px' }}
            onClick={() => {
              setselectedBag(0);
              dispatch(
                editData({
                  id: selectedBag,
                  weight,
                  branche_id,
                }),
              );
            }}
          >
            ویرایش
          </Button>
        </Col>
        <Col xs={6} sm={6} md={4} xl={4} className="fieldItem">
          <Button
            variant="danger"
            style={{ width: '100%', marginTop: '50px' }}
            onClick={() => {
              setselectedBag(0);
              dispatch(
                deleteData({
                  id: selectedBag,
                }),
              );
            }}
          >
            حذف
          </Button>
        </Col>
      </Row>
    );
  }
  const bagListUnBranche = adminBagRegister.data.map((bag, index) =>
    bag.del == null ? (
      <Col
        className="bag"
        xs={selectedBag == bag.id ? 12 : 3}
        sm={selectedBag == bag.id ? 12 : 3}
        md={selectedBag == bag.id ? 12 : 3}
        xl={selectedBag == bag.id ? 12 : 3}
        key={bag.id}
        onClick={() => {
          if (selectedBag == 0 || selectedBag != bag.id) {
            setweight(bag.weight);
            setselectedBag(bag.id);
            setbranche_id(bag.del ? bag.del.branche_id : 0);
          }
        }}
        style={{ backgroundColor: handelBagSattus(bag.status) }}
      >
        {bag.weight + 'کیلو'}
        {selectedBag == bag.id ? selectedForm(index) : null}
      </Col>
    ) : null,
  );
  const bagListBranche =
    value < 2
      ? null
      : adminBagRegister.data.map((bag, index) =>
          bag.del &&
          adminBagRegister.branches[value - 2].id == bag.del.branche_id ? (
            <Col
              className="bag"
              xs={selectedBag == bag.id ? 12 : 3}
              sm={selectedBag == bag.id ? 12 : 3}
              md={selectedBag == bag.id ? 12 : 3}
              xl={selectedBag == bag.id ? 12 : 3}
              key={bag.id}
              onClick={() => {
                if (selectedBag == 0 || selectedBag != bag.id) {
                  setweight(bag.weight);
                  setselectedBag(bag.id);
                  setbranche_id(bag.del ? bag.del.branche_id : 0);
                }
              }}
              style={{ backgroundColor: handelBagSattus(bag.status) }}
            >
              {bag.weight + 'کیلو'}
              {selectedBag == bag.id ? selectedForm(index) : null}
            </Col>
          ) : null,
        );
  const bagListAll = adminBagRegister.data.map((bag, index) => (
    <Col
      className="bag"
      xs={selectedBag == bag.id ? 12 : 3}
      sm={selectedBag == bag.id ? 12 : 3}
      md={selectedBag == bag.id ? 12 : 3}
      xl={selectedBag == bag.id ? 12 : 3}
      key={bag.id}
      onClick={() => {
        if (selectedBag == 0 || selectedBag != bag.id) {
          setweight(bag.weight);
          setselectedBag(bag.id);
          setbranche_id(bag.del ? bag.del.branche_id : 0);
        }
      }}
      style={{ backgroundColor: handelBagSattus(bag.status) }}
    >
      {bag.weight + 'کیلو'}

      {selectedBag == bag.id ? selectedForm(index) : null}
    </Col>
  ));

  const alltotal = adminBagRegister.data.reduce(
    (a, v) => (a = a + Number(v.weight)),
    0,
  );

  const unBranchetotal = adminBagRegister.data
    .filter(item => item.del == null)
    .reduce((a, v) => (a = a + Number(v.weight)), 0);

  const branchetotal =
    value < 2
      ? 0
      : adminBagRegister.data
          .filter(
            item =>
              item.del &&
              adminBagRegister.branches[value - 2].id == item.del.branche_id,
          )
          .reduce((a, v) => (a = a + Number(v.weight)), 0);

  const Allnumbers = adminBagRegister.data.length;

  const numbersUnBranche = adminBagRegister.data.filter(
    item => item.del == null,
  ).length;
  const numbersBranche =
    value < 2
      ? 0
      : adminBagRegister.data.filter(
          item =>
            item.del &&
            adminBagRegister.branches[value - 2].id == item.del.branche_id,
        ).length;

  const infoALL = (
    <Row className="form">
      <Col>{'تعداد: ' + Allnumbers + 'کیسه'}</Col>
      <Col>{'جمع کل: ' + Math.round(alltotal * 100) / 100 + 'کیلو'}</Col>
    </Row>
  );
  const infoUnBranche = (
    <Row className="form">
      <Col>{'تعداد: ' + numbersUnBranche + 'کیسه'}</Col>
      <Col>{'جمع کل: ' + Math.round(unBranchetotal * 100) / 100 + 'کیلو'}</Col>
    </Row>
  );
  const infoBranche = (
    <Row className="form">
      <Col>{'تعداد: ' + numbersBranche + 'کیسه'}</Col>
      <Col>{'جمع کل: ' + Math.round(branchetotal * 100) / 100 + 'کیلو'}</Col>
    </Row>
  );

  const infoTabs = (
    <div className={classes.root}>
      <AppBar position="static" color="default">
        <Tabs
          value={value}
          onChange={handleChange}
          indicatorColor="primary"
          textColor="primary"
          variant="scrollable"
          scrollButtons="auto"
          aria-label="scrollable auto tabs example"
        >
          <Tab label="کل" {...a11yProps(0)} />
          <Tab label="تحویل نشده" {...a11yProps(1)} />
          {adminBagRegister.branches.map((branche, index) => (
            <Tab
              label={branche.name + ' ' + branche.lname}
              {...a11yProps(index + 2)}
            />
          ))}
        </Tabs>
      </AppBar>
      <Row>
        {addNew}
        {value == 0 ? (
          <>
            {infoALL} {bagListAll}
          </>
        ) : null}

        {value == 1 ? (
          <>
            {infoUnBranche} {bagListUnBranche}
          </>
        ) : null}
        {value > 1 ? (
          <>
            {infoBranche}
            {bagListBranche}
          </>
        ) : null}
      </Row>
    </div>
  );

  const selectDate = (
    <Row className="title title2">
      <Col xs={4} sm={4} md={4} xl={4}>
        <Button
          variant="warning"
          size="sm"
          onClick={() =>
            dispatch(
              getData({
                date: 'tom',
                m: Number(adminBagRegister.date.m),
                d: Number(adminBagRegister.date.d),
                y: Number(adminBagRegister.date.y),
              }),
            )
          }
        >
          روز بعد
        </Button>
      </Col>
      <Col xs={4} sm={4} md={4} xl={4}>
        <DatePicker
          value={
            adminBagRegister.date == null
              ? null
              : {
                  day: Number(adminBagRegister.date.d),
                  month: Number(adminBagRegister.date.m),
                  year: Number(adminBagRegister.date.y),
                }
          }
          onChange={e => {
            dispatch(
              getData({
                date: 'date',
                m: e.month,
                d: e.day,
                y: e.year,
              }),
            );
            setdate(e);
          }}
          shouldHighlightWeekends
          locale="fa" // add this
        />
      </Col>
      <Col xs={4} sm={4} md={4} xl={4}>
        <Button
          variant="warning"
          size="sm"
          onClick={() =>
            dispatch(
              getData({
                date: 'yes',
                m: Number(adminBagRegister.date.m),
                d: Number(adminBagRegister.date.d),
                y: Number(adminBagRegister.date.y),
              }),
            )
          }
        >
          روز قبل
        </Button>
      </Col>
    </Row>
  );

  return (
    <div>
      <Helmet>
        <title>لیست کیسه ها</title>
        <meta name="description" content="Description of AdminBagRegister" />
      </Helmet>
      {adminBagRegister.successDelete == -1
        ? null
        : adminBagRegister.successDelete}
      {adminBagRegister.load == 1 ? <Loading /> : null}

      {selectDate}

      {infoTabs}
    </div>
  );
}

AdminBagRegister.propTypes = {
  dispatch: PropTypes.func.isRequired,
  adminBagRegister: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  adminBagRegister: makeSelectAdminBagRegister(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(AdminBagRegister);
