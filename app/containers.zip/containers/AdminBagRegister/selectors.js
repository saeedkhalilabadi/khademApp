import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the adminBagRegister state domain
 */

const selectAdminBagRegisterDomain = state =>
  state.adminBagRegister || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by AdminBagRegister
 */

const makeSelectAdminBagRegister = () =>
  createSelector(
    selectAdminBagRegisterDomain,
    substate => substate,
  );

export default makeSelectAdminBagRegister;
export { selectAdminBagRegisterDomain };
