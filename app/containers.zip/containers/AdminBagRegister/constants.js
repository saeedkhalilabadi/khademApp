/*
 *
 * AdminBagRegister constants
 *
 */

export const GET_DATA = 'app/AdminBagRegister/GET_DATA';
export const GET_DATA_SUCCESS = 'app/AdminBagRegister/GET_DATA_SUCCESS';
export const GET_DATA_ERROR = 'app/AdminBagRegister/GET_DATA_ERROR';

export const ADD_DATA = 'app/AdminBagRegister/ADD_DATA';
export const ADD_DATA_SUCCESS = 'app/AdminBagRegister/ADD_DATA_SUCCESS';
export const ADD_DATA_ERROR = 'app/AdminBagRegister/ADD_DATA_ERROR';

export const EDIT_DATA = 'app/AdminBagRegister/EDIT_DATA';
export const EDIT_DATA_SUCCESS = 'app/AdminBagRegister/EDIT_DATA_SUCCESS';
export const EDIT_DATA_ERROR = 'app/AdminBagRegister/EDIT_DATA_ERROR';

export const DELETE_DATA = 'app/AdminBagRegister/DELETE_DATA';
export const DELETE_DATA_SUCCESS = 'app/AdminBagRegister/DELETE_DATA_SUCCESS';
export const DELETE_DATA_ERROR = 'app/AdminBagRegister/DELETE_DATA_ERROR';

export const FILTER_DATA = 'app/AdminBagRegister/FILTER_DATA';
