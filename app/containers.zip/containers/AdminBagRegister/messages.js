/*
 * AdminBagRegister Messages
 *
 * This contains all the text for the AdminBagRegister container.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.containers.AdminBagRegister';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the AdminBagRegister container!',
  },
});
