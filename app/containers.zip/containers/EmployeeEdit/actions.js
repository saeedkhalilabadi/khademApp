/*
 *
 * EmployeeEdit actions
 *
 */

import { 
  EMPLOYEE_ACTION,
  EMPLOYEE_ACTION_SUCCESS,
  EMPLOYEE_ACTION_FAIL,
  SET_VALUE
 } from './constants';
 export function setValue(data) {
  return {
    type: SET_VALUE,
    data
  };
}


export function employeeAction(data) {
  return {
    type: EMPLOYEE_ACTION,
    data
  };
}

export function employeeActionSuccess(data,act) {
  return {
    type: EMPLOYEE_ACTION_SUCCESS,
    data,act
  };
}

export function employeeActionFail(err,act) {
  return {
    type: EMPLOYEE_ACTION_FAIL,
    err,act
  };
}