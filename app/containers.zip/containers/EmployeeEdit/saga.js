import { takeLatest, call, put, select } from 'redux-saga/effects';
import { EMPLOYEE_ACTION } from './constants';
import { employeeActionSuccess, employeeActionFail } from './actions';
import axios from 'containers/axios/axios-user';

export function* getEmployee(params) {
  let data;
  let e = null;
  console.log(params, 'params');

  switch (params.data.act) {
    case 'editEmployee':
      yield axios
        .get('api/branches/' + params.data.data.id, {
          headers: JSON.parse(localStorage.getItem('userData')),
        })
        .then(response => {
          console.log(response.data, 'employees1');
          data = response.data;
          e = true;
        })
        .catch(error => {
          console.log(error.response);
          data = error.response;
          e = false;
        });
      if (e) yield put(employeeActionSuccess(data, 'editEmployee'));
      else yield put(employeeActionFail(data, 'editEmployee'));
      break;

    case 'updateEmployee':
      yield axios
        .put('api/branches/' + params.data.data.id, params.data.data, {
          headers: JSON.parse(localStorage.getItem('userData')),
        })
        .then(response => {
          console.log(response.data, 'employees1');
          data = response.data;
          e = true;
        })
        .catch(error => {
          console.log(error.response);
          data = error.response;
          e = false;
        });
      if (e) yield put(employeeActionSuccess(data, 'updateEmployee'));
      else yield put(employeeActionFail(data, 'updateEmployee'));
      break;

    default:
      break;
  }
}

// Individual exports for testing
// Individual exports for testing
export default function* employeeEditSaga() {
  yield takeLatest(EMPLOYEE_ACTION, getEmployee);
  // See example in containers/HomePage/saga.js
}
