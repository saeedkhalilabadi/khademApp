import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the employeeEdit state domain
 */

const selectEmployeeEditDomain = state => state.employeeEdit || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by EmployeeEdit
 */

const makeSelectEmployeeEdit = () =>
  createSelector(
    selectEmployeeEditDomain,
    substate => substate,
  );

export default makeSelectEmployeeEdit;
export { selectEmployeeEditDomain };
