/*
 *
 * EmployeeEdit reducer
 *
 */
import produce from 'immer';
import { DEFAULT_ACTION } from './constants';
import {
  EMPLOYEE_ACTION,
  EMPLOYEE_ACTION_SUCCESS,
  EMPLOYEE_ACTION_FAIL,
  SET_VALUE,
} from './constants';

export const initialState = {
  employee: null,
  load: 0,
  editsuccess: 0,
  editerror: { value: ' ', status: 0 },
};

/* eslint-disable default-case, no-param-reassign */
const employeeEditReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case EMPLOYEE_ACTION:
        draft.load = 1;
        draft.editsuccess = 0;
        break;

      case EMPLOYEE_ACTION_SUCCESS:
        draft.load = 0;
        draft.employee = action.data.data;
        action.act == 'updateEmployee' ? (draft.editsuccess = 1) : null;
        break;
      case EMPLOYEE_ACTION_FAIL:
        break;
      case SET_VALUE:
        if (action.data.subject == 'branche_name')
          draft.employee.branche_name = action.data.value;
        if (action.data.subject == 'name')
          draft.employee.name = action.data.value;
        if (action.data.subject == 'lname')
          draft.employee.lname = action.data.value;
        if (action.data.subject == 'gender')
          draft.employee.gender = action.data.value;
        if (action.data.subject == 'phone')
          draft.employee.phone = action.data.value;
        if (action.data.subject == 'tel')
          draft.employee.tel = action.data.value;
        if (action.data.subject == 'address')
          draft.employee.address = action.data.value;
        if (action.data.subject == 'shaba')
          draft.employee.shaba = action.data.value;
        if (action.data.subject == 'bankNumber')
          draft.employee.bankNumber = action.data.value;
        break;
    }
  });

export default employeeEditReducer;
