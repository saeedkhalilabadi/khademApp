// import { selectEmployeeEditDomain } from '../selectors';

describe('selectEmployeeEditDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
