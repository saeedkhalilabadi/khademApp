/**
 *
 * EmployeeEdit
 *
 */

import React, { memo, useState } from 'react';
import { makeStyles } from '@mui/styles';
import PropTypes from 'prop-types';
import NumberFormat from 'react-number-format';

import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import Loading from 'components/Loading/Loadable';
import Badge from '@mui/material/Badge';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { Row, Col, Button, Alert, Form } from 'react-bootstrap';
import { setShowItem, employees_Get_Data } from 'containers/Employees/actions';

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectEmployeeEdit from './selectors';
import { insertEmployeeEdit, newForm, AlertMessage, getRoles } from './actions';
import '../../src/allStyles.css';
import './index.css';
import reducer from './reducer';
import saga from './saga';
import { employeeAction, setValue } from './actions';

const useStyles = makeStyles({
  formControl: {
    margin: '0px',
    minWidth: 150,
  },
  formControladdress: {
    minWidth: 250,
  },
  selectEmpty: {
    marginTop: '0px',
  },
  formControL1: {
    margin: 0,
    minWidth: 120,
  },
});

export function EmployeeEdit({ employeeEdit, dispatch, props }) {
  useInjectReducer({ key: 'employeeEdit', reducer });
  useInjectSaga({ key: 'employeeEdit', saga });

  const [name, setname] = useState('');
  const [lname, setlname] = useState('');
  const [gender, setgender] = useState('');
  const [phone, setphone] = useState('');
  const [branche_name, setbrancheName] = useState('');
  const [address, setaddress] = useState('');
  const [shaba, setshaba] = useState('');
  const [bankNumber, setbankNumber] = useState('');
  const [wage, setwage] = useState('');
  const [password, setpassword] = useState(11111);
  const [meliCode, setmeliCode] = useState('');
  const [getdata, setgetdata] = useState(true);
  const [setdata, setsetdata] = useState(true);
  if (getdata)
    setTimeout(() => {
      setgetdata(false);
      dispatch(
        employeeAction({
          act: 'editEmployee',
          data: { id: props.substate.location.state.id },
        }),
      );
    }, 200);

  console.log(employeeEdit.employee);

  const classes = useStyles();

  const form =
    employeeEdit.employee == null ? null : (
      <>
        <Row className="form mt-3">
          <Col sm="12" className="title mb-3">
            ویرایش اطلاعات شعبه
          </Col>

          <Col sx={12} sm={12} md={6} xl={6} className="filde">
            <Form.Group className="mb-1" controlId="formBasicEmail">
              <Form.Text className="text-muted">نام شعبه</Form.Text>
              <Badge
                color="secondary"
                variant="dot"
                invisible={false}
                style={{ display: 'block' }}
              >
                <Form.Control
                  fullWidth
                  size="sm"
                  type="text"
                  value={employeeEdit.employee.branche_name}
                  placeholder=" نام شعبه"
                  onChange={e => {
                    dispatch(
                      setValue({
                        subject: 'branche_name',
                        value: e.target.value,
                      }),
                    );
                  }}
                />
              </Badge>
            </Form.Group>
          </Col>
          <Col sx={3} sm={3} md={2} xl={2} className="filde">
            <Form.Group className="mb-1" controlId="formBasicEmail">
              <Form.Text className="text-muted">خانم /آقای</Form.Text>
              <Badge color="secondary" variant="dot" invisible={false}>
                <Form.Control
                  as="select"
                  size="sm"
                  value={employeeEdit.employee.gender}
                  custom
                  style={{ maxWidth: '100px' }}
                  onChange={e => {
                    dispatch(
                      setValue({ subject: 'gender', value: e.target.value }),
                    );
                  }}
                >
                  <option> انتخاب کنید</option>

                  <option value="آقای">آقای</option>
                  <option value="خانم">خانم</option>
                </Form.Control>
              </Badge>
            </Form.Group>
          </Col>

          <Col sx={9} sm={9} md={4} xl={4} className="filde">
            <Form.Group className="mb-1" controlId="formBasicEmail">
              <Form.Text className="text-muted">نام مسئول</Form.Text>
              <Badge
                color="secondary"
                variant="dot"
                invisible={false}
                style={{ display: 'block' }}
              >
                <Form.Control
                  size="sm"
                  type="text"
                  value={employeeEdit.employee.name}
                  placeholder=" نام مسئول"
                  onChange={e => {
                    dispatch(
                      setValue({ subject: 'name', value: e.target.value }),
                    );
                  }}
                />
              </Badge>
            </Form.Group>
          </Col>
          <Col sx={12} sm={12} md={6} xl={6} className="filde">
            <Form.Group className="mb-1" controlId="formBasicEmail">
              <Form.Text className="text-muted">نام خانوادگی مسئول</Form.Text>
              <Badge
                color="secondary"
                variant="dot"
                invisible={false}
                style={{ display: 'block' }}
              >
                <Form.Control
                  size="sm"
                  type="text"
                  value={employeeEdit.employee.lname}
                  placeholder=" نام خانوادگی مسئول"
                  onChange={e => {
                    dispatch(
                      setValue({ subject: 'lname', value: e.target.value }),
                    );
                  }}
                />
              </Badge>
            </Form.Group>
          </Col>

          <Col sx={12} sm={12} md={6} xl={6} className="filde">
            <Form.Group className="mb-1" controlId="formBasicEmail">
              <Form.Text className="text-muted">شماره تلفن همراه</Form.Text>
              <Badge
                color="secondary"
                variant="dot"
                invisible={false}
                style={{ display: 'block' }}
              >
                <Form.Control
                  size="sm"
                  value={employeeEdit.employee.phone}
                  type="number"
                  placeholder="شماره تلفن همراه"
                  onChange={e => {
                    dispatch(
                      setValue({ subject: 'phone', value: e.target.value }),
                    );
                  }}
                />
              </Badge>
            </Form.Group>
          </Col>

          <Col sx={12} sm={12} md={6} xl={6} className="filde">
            <Form.Group className="mb-1" controlId="formBasicEmail">
              <Form.Text className="text-muted">کد ملی را وارد کنید</Form.Text>

              <Form.Control
                size="sm"
                value={employeeEdit.employee.meliCode}
                type="number"
                placeholder=" کد ملی"
                onChange={e => {
                  dispatch(
                    setValue({ subject: 'meliCode', value: e.target.value }),
                  );
                }}
              />
            </Form.Group>
          </Col>
          <Col sx={12} sm={12} md={12} xl={12} className="filde">
            <Form.Group className="mb-1" controlId="formBasicEmail">
              <Form.Text className="text-muted">آدرس : </Form.Text>

              <Form.Control
                size="sm"
                value={employeeEdit.employee.address}
                type="text"
                placeholder="آدرس"
                onChange={e => {
                  dispatch(
                    setValue({ subject: 'address', value: e.target.value }),
                  );
                }}
              />
            </Form.Group>
          </Col>

          <Col sx={12} sm={12} md={6} xl={6} className="filde">
            <Form.Group className="mb-1" controlId="formBasicEmail">
              <Form.Text className="text-muted">شماره شبا : </Form.Text>
              <NumberFormat
                value={employeeEdit.employee.shaba}
                placeholder="شماره شبا"
                format="IR## #### #### #### #### #### ##"
                style={{ direction: 'ltr', width: '100%' }}
                mask="_"
                onValueChange={e => {
                  dispatch(setValue({ subject: 'shaba', value: e.value }));
                }}
              />
            </Form.Group>
          </Col>
          <Col sx={12} sm={12} md={6} xl={6} className="filde">
            <Form.Group className="mb-1" controlId="formBasicEmail">
              <Form.Text className="text-muted">شماره کارت : </Form.Text>
              <NumberFormat
                value={employeeEdit.employee.bankNumber}
                placeholder="شماره کارت"
                format="#### #### #### ####"
                style={{ direction: 'ltr', width: '100%' }}
                mask="_"
                onValueChange={e => {
                  dispatch(setValue({ subject: 'bankNumber', value: e.value }));
                }}
              />
            </Form.Group>
          </Col>

          <Col sx={12} sm={12} md={6} xl={6} className="filde">
            <Button
              style={{ margin: 'auto', marginTop: '30px', minWidth: '100%' }}
              variant="warning"
              size="sm"
              onClick={handelinsert}
            >
              ثبت{' '}
            </Button>
          </Col>
          <Col sx={12} sm={12} md={6} xl={6} className="filde">
            <Link
              to={{
                pathname: '/employee',
                state: { id: props.substate.location.state.id },
              }}
            >
              <Button
                style={{ margin: 'auto', marginTop: '30px', minWidth: '100%' }}
                variant="outline-warning"
                size="sm"
              >
                برگشت
              </Button>
            </Link>
          </Col>
        </Row>
      </>
    );
  function handelinsert() {
    if (employeeEdit.employee.name.length < 3) {
      dispatch(
        AlertMessage({
          value: 'نام مسئول به درستی وارد نشده است',
          status: 1,
        }),
      );
    } else if (employeeEdit.employee.lname.length < 3) {
      dispatch(
        AlertMessage({
          value: 'نام  خانوادگی مسئول به درستی وارد نشده است',
          status: 1,
        }),
      );
    } else if (employeeEdit.employee.branche_name.length < 3) {
      dispatch(
        AlertMessage({
          value: 'نام شعبه به درستی وارد نشده است',
          status: 1,
        }),
      );
    } else if (employeeEdit.employee.phone.length < 10) {
      dispatch(
        AlertMessage({
          value: 'شماره تلفن همراه به درستی وارد نشده است',
          status: 1,
        }),
      );
    } else
      dispatch(
        employeeAction({
          act: 'updateEmployee',
          data: {
            id: props.substate.location.state.id,
            ...employeeEdit.employee,
          },
        }),
      );
  }
  const successform = (
    <div className="body-EmployeeEdit">
      <Row className="form" justify-content-center>
        <Col
          sm="12"
          className="filde"
          style={{ color: 'black', fontSize: '30px' }}
        >
          اطلاعات شعبه با موفقیت ویرایش شد <br />
          <br />
          <br />
          <br />
          <Link
            to={{
              pathname: '/employee',
              state: { id: props.substate.location.state.id },
            }}
          >
            <Button variant="warning" style={{ width: 200 }}>
              تایید
            </Button>
          </Link>
        </Col>
      </Row>
    </div>
  );

  return (
    <>
      <Helmet>
        <title>ویرایش اطلاعات شعبه</title>
        <meta name="description" content="Description of EmployeeEdit" />
      </Helmet>
      {employeeEdit.load == 1 ? <Loading /> : null}
      {employeeEdit.editerror.status === 1 ? (
        <Alert variant="danger" align="center">
          {employeeEdit.editerror.value}
        </Alert>
      ) : (
        <div />
      )}
      {employeeEdit.editsuccess === 0 ? form : successform}
    </>
  );
}

EmployeeEdit.propTypes = {
  dispatch: PropTypes.func.isRequired,
  employeeEdit: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  employeeEdit: makeSelectEmployeeEdit(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(EmployeeEdit);
