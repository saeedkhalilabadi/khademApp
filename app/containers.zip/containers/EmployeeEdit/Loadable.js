/**
 *
 * Asynchronously loads the component for EmployeeEdit
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
