/*
 *
 * EmployeeEdit constants
 *
 */

export const EMPLOYEE_ACTION = 'app/EmployeeEdit/EMPLOYEE_ACTION';
export const EMPLOYEE_ACTION_SUCCESS = 'app/EmployeeEdit/EMPLOYEE_ACTION_SUCCESS';
export const EMPLOYEE_ACTION_FAIL = 'app/EmployeeEdit/EMPLOYEE_ACTION_FAIL';

export const SET_VALUE = 'app/EmployeeEdit/SET_VALUE';