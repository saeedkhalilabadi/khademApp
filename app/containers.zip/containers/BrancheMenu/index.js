/**
 *
 * BrancheMenu
 *
 */

import React, { memo, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';

import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { Link } from 'react-router-dom';
import MenuIcon from '@mui/icons-material/Menu';
import PersonAddAlt1Icon from '@mui/icons-material/PersonAddAlt1';
import LocalFloristIcon from '@mui/icons-material/LocalFlorist';
import ContentPasteIcon from '@mui/icons-material/ContentPaste';
import GroupsIcon from '@mui/icons-material/Groups';
import LayersIcon from '@mui/icons-material/Layers';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import SpaIcon from '@mui/icons-material/Spa';
import CreditCardIcon from '@mui/icons-material/CreditCard';
import LocalAtmIcon from '@mui/icons-material/LocalAtm';
import HomeIcon from '@mui/icons-material/Home';
import { ButtonGroup, Button, Col, Row, Form } from 'react-bootstrap';
import MenuList from '@mui/material/MenuList';
import PowerSettingsNewIcon from '@mui/icons-material/PowerSettingsNew';
import {
  FcSupport,
  FcServices,
  FcSms,
  FcSurvey,
  FcAddDatabase,
  FcFactory,
  FcBullish,
  FcCollaboration,
  FcConferenceCall,
  FcOpenedFolder,
  FcSportsMode,
  FcSettings,
  FcMenu,
  FcBusinessman,
} from 'react-icons/fc';
import { AiOutlinePoweroff } from 'react-icons/ai';
import Avatar from '@mui/material/Avatar';
import { ImExit } from 'react-icons/im';
import { FaHome, FaSms } from 'react-icons/fa';
import Hidden from '@mui/material/Hidden';
import ListItemIcon from '@mui/material/ListItemIcon';

import Typography from '@mui/material/Typography';
import MenuItem from '@mui/material/MenuItem';

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import { logOut } from '../Routes/actions';
import makeSelectBrancheMenu from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import './index.css';
import { getDashboard } from './actions';
import PaymentIcon from '@mui/icons-material/Payment';

export function BrancheMenu({ dispatch, props, brancheMenu }) {
  useInjectReducer({ key: 'brancheMenu', reducer });
  useInjectSaga({ key: 'brancheMenu', saga });
  const [getdata, setgetdata] = useState(true);

  if (getdata)
    setTimeout(() => {
      setgetdata(false);
      dispatch(getDashboard());
    }, 200);

  function getWindowDimensions() {
    const { innerWidth: width, innerHeight: height } = window;
    return {
      width,
      height,
    };
  }

  const [windowDimensions, setWindowDimensions] = useState(
    getWindowDimensions(),
  );

  useEffect(() => {
    function handleResize() {
      setWindowDimensions(getWindowDimensions());
    }

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  console.log(windowDimensions, 'screen');

  const [menulist, setmenulist] = useState('-220px');
  const menu = (
    <div className="pcMenu">
      <MenuList>
        <Link to="/dashbord" className="linkstyle">
          <Col
            className="btn1"
            style={{
              backgroundColor: props.subject == 'Dashbord' ? '#acacf0' : null,
            }}
          >
            <HomeIcon className="menuIcons" />
            داشبورد
          </Col>
        </Link>

        <div className="menu_dividerPc" />
        <Link to="/SelectOpenedLists" className="linkstyle">
          <Col
            className="btn1"
            style={{
              backgroundColor: props.subject == 'Myjobs' ? '#acacf0' : null,
            }}
          >
            <LocalFloristIcon
              className="menuIcons"
              style={{ backgroundColor: '#0f9d58', color: 'white' }}
            />
            توزیع
          </Col>
        </Link>
        <Link to="/RegistrationHead" className="linkstyle">
          <Col
            className="btn1"
            style={{
              backgroundColor: props.subject == 'files' ? '#acacf0' : null,
            }}
          >
            <SpaIcon className="menuIcons" />
            ثبت سرگل
          </Col>
        </Link>

        <Link to="/BagRegister" className="linkstyle">
          <Col
            className="btn1"
            style={{
              backgroundColor: props.subject == 'files' ? '#acacf0' : null,
            }}
          >
            <LayersIcon className="menuIcons" />
            ثبت کیسه
          </Col>
        </Link>
        <Link to="/PaymentRegistr" className="linkstyle">
          <Col
            className="btn1"
            style={{
              backgroundColor: props.subject == 'customers' ? '#acacf0' : null,
            }}
          >
            <CreditCardIcon className="menuIcons" />
            ثبت پرداخت
          </Col>
        </Link>
        <div className="menu_dividerPc" />

        <Link to="/Sales" className="linkstyle">
          <Col
            className="btn1"
            style={{
              backgroundColor: props.subject == 'contracts' ? '#acacf0' : null,
            }}
          >
            <ShoppingCartIcon className="menuIcons" />
            فروش
          </Col>
        </Link>
        <Link to="/EmployeeLists" className="linkstyle">
          <Col
            className="btn1"
            style={{
              backgroundColor: props.subject == 'products' ? '#acacf0' : null,
            }}
          >
            <ContentPasteIcon className="menuIcons" />
            گزارش گیری و تایید
          </Col>
        </Link>
        <div className="menu_dividerPc" />
        <Link to="/EmployeeFinancialReport" className="linkstyle">
          <Col
            className="btn1"
            style={{
              backgroundColor: props.subject == 'employees' ? '#acacf0' : null,
            }}
          >
            <LocalAtmIcon className="menuIcons" />
            گزارش مالی
          </Col>
        </Link>
        <Link to="/NewSub" className="linkstyle">
          <Col
            className="btn1"
            style={{
              backgroundColor: props.subject == 'notes' ? '#acacf0' : null,
            }}
          >
            <PersonAddAlt1Icon className="menuIcons" />
            ثبت نام مشترک
          </Col>
        </Link>

        <Link to="/Subs" className="linkstyle">
          <Col
            className="btn1"
            style={{
              backgroundColor: props.subject == 'massages' ? '#acacf0' : null,
            }}
          >
            <GroupsIcon className="menuIcons" />
            مشترکین شعبه
          </Col>
        </Link>

        <div className="menu_dividerPc" />
        <Link to="/" className="linkstyle">
          <Col
            onClick={() => dispatch(logOut())}
            style={{ cursor: 'pointer' }}
            className="btn1"
          >
            <PowerSettingsNewIcon className="menuIcons" />
            خروج
          </Col>
        </Link>
      </MenuList>
    </div>
  );

  const menumob = (
    <div>
      {menulist == '0px' ? (
        <div className="menuback" onClick={() => setmenulist('-220px')} />
      ) : null}
      <div
        className="menulist"
        style={{ marginRight: menulist, transition: '1000ms' }}
      >
        {' '}
        <Col>
          <img
            src={require('../../images/logo.png')}
            style={{
              margin: 'auto',
              width: '100%',
            }}
          />
        </Col>
        <MenuList>
          <Link
            to="/dashbord"
            style={{ textDecoration: 'none' }}
            onClick={() => setmenulist('-220px')}
          >
            <Row>
              <Col className="iconsMob">
                <HomeIcon style={{ color: 'gray' }} />
              </Col>
              <Col className="menuTitleMob">صفحه اصلی</Col>
            </Row>
          </Link>
          <div className="menu_divider" />
          <Link
            to="/SelectOpenedLists"
            style={{ textDecoration: 'none' }}
            onClick={() => setmenulist('-220px')}
          >
            <Row>
              <Col className="iconsMob">
                <LocalFloristIcon style={{ color: 'gray' }} />
              </Col>
              <Col className="menuTitleMob">توزیع</Col>
            </Row>
          </Link>
          <div className="menu_divider" />
          <Link
            to="/RegistrationHead"
            style={{ textDecoration: 'none' }}
            onClick={() => setmenulist('-220px')}
          >
            <Row>
              <Col className="iconsMob">
                <SpaIcon style={{ color: 'gray' }} />
              </Col>
              <Col className="menuTitleMob">ثبت سرگل</Col>
            </Row>
          </Link>
          <div className="menu_divider" />
          <Link
            to="/BagRegister"
            style={{ textDecoration: 'none' }}
            onClick={() => setmenulist('-220px')}
          >
            <Row>
              <Col className="iconsMob">
                <LayersIcon style={{ color: 'gray' }} />
              </Col>
              <Col className="menuTitleMob">ثبت کیسه</Col>
            </Row>
          </Link>
          <div className="menu_divider" />
          <Link
            to="/PaymentRegistr"
            style={{ textDecoration: 'none' }}
            onClick={() => setmenulist('-220px')}
          >
            <Row>
              <Col className="iconsMob">
                <CreditCardIcon style={{ color: 'gray' }} />
              </Col>
              <Col className="menuTitleMob">ثبت پرداخت</Col>
            </Row>
          </Link>

          <div className="menu_divider" />

          <Link
            to="/Sales"
            style={{ textDecoration: 'none' }}
            onClick={() => setmenulist('-220px')}
          >
            <Row>
              <Col className="iconsMob">
                <ShoppingCartIcon style={{ color: 'gray' }} />
              </Col>
              <Col className="menuTitleMob">فروش</Col>
            </Row>
          </Link>
          <div className="menu_divider" />
          <Link
            to="/EmployeeLists"
            style={{ textDecoration: 'none' }}
            onClick={() => setmenulist('-220px')}
          >
            <Row>
              <Col className="iconsMob">
                <ContentPasteIcon style={{ color: 'gray' }} />
              </Col>
              <Col className="menuTitleMob">گزارش گیری و تایید</Col>
            </Row>
          </Link>

          <div className="menu_divider" />
          <Link
            to="/EmployeeFinancialReport"
            style={{ textDecoration: 'none' }}
            onClick={() => setmenulist('-220px')}
          >
            <Row>
              <Col className="iconsMob">
                <LocalAtmIcon style={{ color: 'gray' }} />
              </Col>
              <Col className="menuTitleMob">گزارش مالی</Col>
            </Row>
          </Link>

          <div className="menu_divider" />
          <Link
            to="/NewSub"
            style={{ textDecoration: 'none' }}
            onClick={() => setmenulist('-220px')}
          >
            <Row>
              <Col className="iconsMob">
                <PersonAddAlt1Icon style={{ color: 'gray' }} />
              </Col>
              <Col className="menuTitleMob">ثبت نام مشترک</Col>
            </Row>
          </Link>
          <div className="menu_divider" />
          <Link
            to="/Subs"
            style={{ textDecoration: 'none' }}
            onClick={() => setmenulist('-220px')}
          >
            <Row>
              <Col className="iconsMob">
                <GroupsIcon style={{ color: 'gray' }} />
              </Col>
              <Col className="menuTitleMob">مشترکین شعبه</Col>
            </Row>
          </Link>
          <div className="menu_divider" />
          <Row onClick={() => dispatch(logOut())} style={{ cursor: 'pointer' }}>
            <Col className="iconsMob">
              <PowerSettingsNewIcon style={{ color: 'gray' }} />
            </Col>
            <Col className="menuTitleMob">خروج</Col>
          </Row>
        </MenuList>
      </div>
    </div>
  );
  const btnmenumob = (
    <div>
      <MenuIcon
        style={{
          zIndex: '103',
          fontSize: '40px',
          cursor: 'pointer',
          position: 'fixed',
          top: '5px',
          right: '10px',
        }}
        onClick={() => setmenulist('0px')}
      />
      {menumob}
    </div>
  );
  const DashboardItem = (
    <Row className="DashboardItem">
      <Col xs={12} sm={12} md={12} xl={12}>
        <div className="supply">
          موجودی{' '}
          <span>
            {Math.round(brancheMenu.dashboardData.supply * 100) / 100} کیلوگرم
          </span>
        </div>
        <div className="disdel">
          <span className="del">
            دریافتی {brancheMenu.dashboardData.dif}{' '}
            {brancheMenu.dashboardData.bagsKg == null
              ? '0'
              : Math.round(brancheMenu.dashboardData.bagsKg * 100) / 100}{' '}
            کیلوگرم
          </span>{' '}
          -
          <span className="dis">
            {' '}
            توزیع شده {brancheMenu.dashboardData.dif}{' '}
            {brancheMenu.dashboardData.disFolwerKg == null
              ? '0'
              : Math.round(brancheMenu.dashboardData.disFolwerKg * 100) /
                100}{' '}
            کیلوگرم{' '}
          </span>
        </div>
      </Col>
      <Col xs={3} sm={3} md={2} xl={2}>
        <Link to="./BagRegister" className="DashboardItemLink">
          <div className="DashboardMainItem">
            <LayersIcon />
            <p>ثبت کیسه</p>
          </div>
        </Link>
      </Col>
      <Col xs={3} sm={3} md={2} xl={2}>
        <Link to="./SelectOpenedLists" className="DashboardItemLink">
          <div className="DashboardMainItem">
            <LocalFloristIcon />
            <p>توزیع</p>
          </div>
        </Link>
      </Col>

      <Col xs={3} sm={3} md={2} xl={2}>
        <Link to="./RegistrationHead" className="DashboardItemLink">
          <div className="DashboardMainItem">
            <SpaIcon />
            <p>ثبت سرگل</p>
          </div>
        </Link>
      </Col>
    </Row>
  );
  const navTop_pc = (
    <div
      className="d-flex  justify-content-center navTop_pc"
      style={
        props.subject == 'Dashbord' && windowDimensions.width < 1000
          ? {
              width: '100%',
              height: '230px',
              backgroundColor: '#BB86FC',
              position: 'fixed',
              top: '0px',
              zIndex: '102',
            }
          : {
              width: '100%',
              height: '50px',
              backgroundColor: '#BB86FC',
              position: 'fixed',
              top: '0px',
              zIndex: '102',
            }
      }
    >
      <div className="my-auto" />

      <img className="navbarTopLogo" src={require('../../images/logo.png')} />
      {props.subject == 'Dashbord' && windowDimensions.width < 1000
        ? DashboardItem
        : null}
    </div>
  );

  const avat = (
    <>
      <Link to="account">
        <Row className="avatar">
          <Col xs={3} sm={3} md={3} xl={3}>
            <Avatar
              style={{ width: '40px' }}
              alt="Remy Sharp"
              src={
                props.data1.userData.pic
                  ? props.data1.userData.pic
                  : require('../../images/avatar.png')
              }
            />
          </Col>

          <Col xs={9} sm={9} md={9} xl={9} className="profilename">
            {props.data1.userData.name + ' ' + props.data1.userData.lname}
          </Col>
        </Row>
      </Link>
    </>
  );

  return (
    <div className="menu_btn">
      {avat}
      {navTop_pc}

      {windowDimensions.width > 1000 ? menu : null}
      {windowDimensions.width < 1000 ? btnmenumob : null}
    </div>
  );
}

BrancheMenu.propTypes = {
  dispatch: PropTypes.func.isRequired,
  brancheMenu: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  brancheMenu: makeSelectBrancheMenu(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(BrancheMenu);
