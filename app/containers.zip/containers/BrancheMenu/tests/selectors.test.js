// import { selectBrancheMenuDomain } from '../selectors';

describe('selectBrancheMenuDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
