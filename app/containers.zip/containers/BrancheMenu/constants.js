/*
 *
 * BrancheMenu constants
 *
 */

export const GET_DASHBOARD = 'app/BrancheMenu/GET_DASHBOARD';
export const GET_DASHBOARD_SUCCESS = 'app/BrancheMenu/GET_DASHBOARD_SUCCESS';
export const GET_DASHBOARD_FAIL = 'app/BrancheMenu/GET_DASHBOARD_FAIL';
