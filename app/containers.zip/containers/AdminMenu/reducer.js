/*
 *
 * AdminMenu reducer
 *
 */
/*
 *
 * BrancheMenu reducer
 *
 */
import produce from 'immer';
import {
  GET_DASHBOARD,
  GET_DASHBOARD_SUCCESS,
  GET_DASHBOARD_FAIL,
} from './constants';

export const initialState = {
  dashboardData: [],
};

/* eslint-disable default-case, no-param-reassign */
const adminMenuReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case GET_DASHBOARD:
        break;
      case GET_DASHBOARD_SUCCESS:
        draft.dashboardData = action.data;
        break;
      case GET_DASHBOARD_FAIL:
        break;
    }
  });

export default adminMenuReducer;


