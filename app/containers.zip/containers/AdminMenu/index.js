/**
 *
 * AdminMenu
 *
 */

import React, { memo, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { Link } from 'react-router-dom';
import MenuIcon from '@mui/icons-material/Menu';
import { ButtonGroup, Button, Col, Row, Form } from 'react-bootstrap';
import MenuList from '@mui/material/MenuList';
import DownloadDoneIcon from '@mui/icons-material/DownloadDone';
import {
  FcSupport,
  FcServices,
  FcSms,
  FcSurvey,
  FcAddDatabase,
  FcFactory,
  FcBullish,
  FcCollaboration,
  FcConferenceCall,
  FcOpenedFolder,
  FcSportsMode,
  FcSettings,
  FcMenu,
  FcBusinessman,
} from 'react-icons/fc';
import { AiOutlinePoweroff } from 'react-icons/ai';
import Avatar from '@mui/material/Avatar';
import { ImExit } from 'react-icons/im';
import { FaHome, FaSms } from 'react-icons/fa';
import Hidden from '@mui/material/Hidden';
import ListItemIcon from '@mui/material/ListItemIcon';

import Typography from '@mui/material/Typography';
import MenuItem from '@mui/material/MenuItem';
import { useInjectSaga } from 'utils/injectSaga';
import { logOut } from '../Routes/actions';
import { useInjectReducer } from 'utils/injectReducer';

import makeSelectAdminMenu from './selectors';
import reducer from './reducer';
import saga from './saga';
import './index.css';
import SportsScoreIcon from '@mui/icons-material/SportsScore';
import PaymentIcon from '@mui/icons-material/Payment';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import LocalFloristIcon from '@mui/icons-material/LocalFlorist';
import GroupIcon from '@mui/icons-material/Group';
import ContentPasteIcon from '@mui/icons-material/ContentPaste';
import GroupsIcon from '@mui/icons-material/Groups';
import LocalAtmIcon from '@mui/icons-material/LocalAtm';
import SettingsIcon from '@mui/icons-material/Settings';
import LayersIcon from '@mui/icons-material/Layers';

import CreditCardIcon from '@mui/icons-material/CreditCard';
import ShowChartIcon from '@mui/icons-material/ShowChart';

import PowerSettingsNewIcon from '@mui/icons-material/PowerSettingsNew';
import HomeIcon from '@mui/icons-material/Home';
import { getDashboard } from './actions';

function getWindowDimensions() {
  const { innerWidth: width, innerHeight: height } = window;
  return {
    width,
    height,
  };
}

export function AdminMenu({ dispatch, adminMenu, props }) {
  useInjectReducer({ key: 'adminMenu', reducer });
  useInjectSaga({ key: 'adminMenu', saga });
  // console.log(props.data1.userData, 'props');
  const [windowDimensions, setWindowDimensions] = useState(
    getWindowDimensions(),
  );
  const [getdata, setgetdata] = useState(true);

  if (getdata)
    setTimeout(() => {
      setgetdata(false);
      dispatch(getDashboard());
    }, 200);
  useEffect(() => {
    function handleResize() {
      setWindowDimensions(getWindowDimensions());
    }

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  console.log(adminMenu);

  const [menulist, setmenulist] = useState('-220px');
  const menu = (
    <div className="pcMenu">
      <MenuList>
        <Link to="/dashbord" className="linkstyle">
          <Col
            className="btn1"
            style={{
              backgroundColor: props.subject == 'Dashbord' ? '#acacf0' : null,
            }}
          >
            <HomeIcon className="menuIcons" />
            داشبورد
          </Col>
        </Link>

        <div className="menu_dividerPc" />
        <Link to="/BagRegister" className="linkstyle">
          <Col
            className="btn1"
            style={{
              backgroundColor: props.subject == 'Myjobs' ? '#acacf0' : null,
            }}
          >
            <LayersIcon
              className="menuIcons"
              style={{ backgroundColor: '#0f9d58', color: 'white' }}
            />
            ثبت کیسه ها
          </Col>
        </Link>
        <Link to="/WetHeadRegister" className="linkstyle">
          <Col
            className="btn1"
            style={{
              backgroundColor: props.subject == 'files' ? '#acacf0' : null,
            }}
          >
            <LocalFloristIcon className="menuIcons" />
            ثبت سر گل خشک
          </Col>
        </Link>

        <Link to="/PaymentRegistr" className="linkstyle">
          <Col
            className="btn1"
            style={{
              backgroundColor: props.subject == 'files' ? '#acacf0' : null,
            }}
          >
            <CreditCardIcon className="menuIcons" />
            ثبت پرداخت
          </Col>
        </Link>
        <Link to="/employees" className="linkstyle">
          <Col
            className="btn1"
            style={{
              backgroundColor: props.subject == 'customers' ? '#acacf0' : null,
            }}
          >
            <GroupIcon className="menuIcons" />
            شعبه ها
          </Col>
        </Link>

        <Link to="/customers" className="linkstyle">
          <Col
            className="btn1"
            style={{
              backgroundColor: props.subject == 'customers' ? '#acacf0' : null,
            }}
          >
            <GroupsIcon className="menuIcons" />
            مشترکین شعبه
          </Col>
        </Link>
        <div className="menu_dividerPc" />

        <Link to="/contracts" className="linkstyle">
          <Col
            className="btn1"
            style={{
              backgroundColor: props.subject == 'contracts' ? '#acacf0' : null,
            }}
          >
            <LocalAtmIcon className="menuIcons" />
            گزارش مالی شعبه
          </Col>
        </Link>
        <Link to="/BrancheDistributionReport" className="linkstyle">
          <Col
            className="btn1"
            style={{
              backgroundColor: props.subject == 'products' ? '#acacf0' : null,
            }}
          >
            <ContentPasteIcon className="menuIcons" />
            گزارش توزیع
          </Col>
        </Link>
        <div className="menu_dividerPc" />
        <Link to="/BranchAnalyticalReport" className="linkstyle">
          <Col
            className="btn1"
            style={{
              backgroundColor: props.subject == 'employees' ? '#acacf0' : null,
            }}
          >
            <ShowChartIcon className="menuIcons" />
            گزارش تحلیلی شعب
          </Col>
        </Link>

        <Link to="/AdminSetting" className="linkstyle">
          <Col
            className="btn1"
            style={{
              backgroundColor: props.subject == 'massages' ? '#acacf0' : null,
            }}
          >
            <SettingsIcon className="menuIcons" />
            ثبت قیمت ها
          </Col>
        </Link>

        <div className="menu_dividerPc" />
        <Link to="/AdminScoreSetting" className="linkstyle">
          <Col
            className="btn1"
            style={{
              backgroundColor: props.subject == 'massages' ? '#acacf0' : null,
            }}
          >
            <SportsScoreIcon className="menuIcons" />
            امتیاز ها
          </Col>
        </Link>

        <div className="menu_dividerPc" />
        <Link to="/" className="linkstyle">
          <Col
            onClick={() => dispatch(logOut())}
            style={{ cursor: 'pointer' }}
            className="btn1"
          >
            <PowerSettingsNewIcon className="menuIcons" />
            خروج
          </Col>
        </Link>
      </MenuList>
    </div>
  );

  const menumob = (
    <div>
      {menulist == '0px' ? (
        <div className="menuback" onClick={() => setmenulist('-220px')} />
      ) : null}
      <div
        className="menulist"
        style={{ marginRight: menulist, transition: '1000ms' }}
      >
        {' '}
        <Col>
          <img
            src={require('../../images/logo.png')}
            style={{
              margin: 'auto',
              width: '100%',
            }}
          />
        </Col>
        <MenuList>
          <Link
            to="/dashbord"
            style={{ textDecoration: 'none' }}
            onClick={() => setmenulist('-220px')}
          >
            <Row>
              <Col className="iconsMob">
                <HomeIcon style={{ color: 'gray' }} />
              </Col>
              <Col className="menuTitleMob">صفحه اصلی</Col>
            </Row>
          </Link>
          <div className="menu_divider" />
          <Link
            to="/BagRegister"
            onClick={() => setmenulist('-220px')}
            style={{ textDecoration: 'none' }}
          >
            <Row>
              <Col className="iconsMob">
                <LayersIcon style={{ color: 'gray' }} />
              </Col>
              <Col className="menuTitleMob">ثبت کیسه ها</Col>
            </Row>
          </Link>
          <div className="menu_divider" />
          <Link
            to="/WetHeadRegister"
            onClick={() => setmenulist('-220px')}
            style={{ textDecoration: 'none' }}
          >
            <Row>
              <Col className="iconsMob">
                <LocalFloristIcon style={{ color: 'gray' }} />
              </Col>
              <Col className="menuTitleMob">ثبت سرگل خشک</Col>
            </Row>
          </Link>
          <div className="menu_divider" />
          <Link
            to="/PaymentRegistr"
            onClick={() => setmenulist('-220px')}
            style={{ textDecoration: 'none' }}
          >
            <Row>
              <Col className="iconsMob">
                <CreditCardIcon style={{ color: 'gray' }} />
              </Col>
              <Col className="menuTitleMob">ثبت پرداخت</Col>
            </Row>
          </Link>
          <div className="menu_divider" />
          <Link
            to="/employees"
            onClick={() => setmenulist('-220px')}
            style={{ textDecoration: 'none' }}
          >
            <Row>
              <Col className="iconsMob">
                <GroupIcon style={{ color: 'gray' }} />
              </Col>
              <Col className="menuTitleMob">شعبه ها</Col>
            </Row>
          </Link>

          <div className="menu_divider" />

          <Link
            to="/reports"
            onClick={() => setmenulist('-220px')}
            style={{ textDecoration: 'none' }}
          >
            <Row>
              <Col className="iconsMob">
                <GroupsIcon style={{ color: 'gray' }} />
              </Col>
              <Col className="menuTitleMob">مشترکین شعبه</Col>
            </Row>
          </Link>
          <div className="menu_divider" />

          <Link
            to="/reports"
            onClick={() => setmenulist('-220px')}
            style={{ textDecoration: 'none' }}
          >
            <Row>
              <Col className="iconsMob">
                <LocalAtmIcon style={{ color: 'gray' }} />
              </Col>
              <Col className="menuTitleMob">گزارش مالی شعبه</Col>
            </Row>
          </Link>
          <div className="menu_divider" />

          <Link
            to="/BrancheDistributionReport"
            style={{ textDecoration: 'none' }}
            onClick={() => setmenulist('-220px')}
          >
            <Row>
              <Col className="iconsMob">
                <ContentPasteIcon style={{ color: 'gray' }} />
              </Col>
              <Col className="menuTitleMob">گزارش توزیع</Col>
            </Row>
          </Link>

          <div className="menu_divider" />
          <Link
            to="/BranchAnalyticalReport"
            onClick={() => setmenulist('-220px')}
            style={{ textDecoration: 'none' }}
          >
            <Row>
              <Col className="iconsMob">
                <ShowChartIcon style={{ color: 'gray' }} />
              </Col>
              <Col className="menuTitleMob">گزارش تحلیلی شعب</Col>
            </Row>
          </Link>

          <div className="menu_divider" />
          <Link
            to="/AdminSetting"
            onClick={() => setmenulist('-220px')}
            style={{ textDecoration: 'none' }}
          >
            <Row>
              <Col className="iconsMob">
                <SettingsIcon style={{ color: 'gray' }} />
              </Col>
              <Col className="menuTitleMob"> ثبت قیمت ها</Col>
            </Row>
          </Link>
          <div className="menu_divider" />
          <Link
            to="/AdminScoreSetting"
            onClick={() => setmenulist('-220px')}
            style={{ textDecoration: 'none' }}
          >
            <Row>
              <Col className="iconsMob">
                <SportsScoreIcon style={{ color: 'gray' }} />
              </Col>
              <Col className="menuTitleMob"> امتیازها</Col>
            </Row>
          </Link>
          <div className="menu_divider" />
          <Row onClick={() => dispatch(logOut())} style={{ cursor: 'pointer' }}>
            <Col className="iconsMob">
              <PowerSettingsNewIcon style={{ color: 'gray' }} />
            </Col>
            <Col className="menuTitleMob">خروج</Col>
          </Row>
        </MenuList>
      </div>
    </div>
  );
  const btnmenumob = (
    <div>
      <MenuIcon
        style={{
          zIndex: '103',
          fontSize: '40px',
          cursor: 'pointer',
          position: 'fixed',
          top: '5px',
          right: '10px',
        }}
        onClick={() => setmenulist('0px')}
      />
      {menumob}
    </div>
  );
  const DashboardItem = (
    <Row className="DashboardItem">
      <Col xs={12} sm={12} md={12} xl={12}>
        <div className="supply">
          توزیع شده {adminMenu.dashboardData.dif}{' '}
          <span>
            {Math.round(
              (adminMenu.dashboardData.dis / adminMenu.dashboardData.bags) *
                100,
            )
              ? Math.round(
                  (adminMenu.dashboardData.dis / adminMenu.dashboardData.bags) *
                    100,
                )
              : 0}{' '}
            %
          </span>
        </div>
        <div className="disdel">
          <span className="del">
            دریافتی {adminMenu.dashboardData.dif}{' '}
            {adminMenu.dashboardData.bags == null
              ? '0'
              : Math.round(adminMenu.dashboardData.bags * 10) / 10}{' '}
            کیلوگرم
          </span>{' '}
          -
          <span className="dis">
            {' '}
            توزیع شده {adminMenu.dashboardData.dif}{' '}
            {adminMenu.dashboardData.dis == null
              ? '0'
              : Math.round(adminMenu.dashboardData.dis * 100) / 100}{' '}
            کیلوگرم{' '}
          </span>
        </div>
      </Col>
      <Col xs={3} sm={3} md={2} xl={2}>
        <Link to="./BagRegister" className="DashboardItemLink">
          <div className="DashboardMainItem">
            <LayersIcon />
            <p>کیسه ها</p>
          </div>
        </Link>
      </Col>
      <Col xs={3} sm={3} md={2} xl={2}>
        <Link to="./AdminSetting" className="DashboardItemLink">
          <div className="DashboardMainItem">
            <SettingsIcon />
            <p>قیمت ها</p>
          </div>
        </Link>
      </Col>
      <Col xs={3} sm={3} md={2} xl={2}>
        <Link to="./WetHeadRegister" className="DashboardItemLink">
          <div className="DashboardMainItem">
            <LocalFloristIcon />
            <p>ثبت سرگل</p>
          </div>
        </Link>
      </Col>
    </Row>
  );
  const navTop_pc = (
    <div
      className="d-flex  justify-content-center"
      style={
        props.subject == 'Dashbord' && windowDimensions.width < 1000
          ? {
              width: '100%',
              height: '250px',
              backgroundColor: '#fee600',
              position: 'fixed',
              top: '0px',
              zIndex: '102',
            }
          : {
              width: '100%',
              height: '50px',
              backgroundColor: '#fee600',
              position: 'fixed',
              top: '0px',
              zIndex: '102',
            }
      }
    >
      <div className="my-auto" />

      <img className="navbarTopLogo" src={require('../../images/logo.png')} />
      {props.subject == 'Dashbord' && windowDimensions.width < 1000
        ? DashboardItem
        : null}
    </div>
  );

  const avat = (
    <>
      <Link to="account">
        <Row className="avatar">
          <Col xs={3} sm={3} md={3} xl={3}>
            <Avatar
              style={{ width: '40px', marginTop: '5px' }}
              alt="Remy Sharp"
              src={
                props.data1.userData.pic
                  ? props.data1.userData.pic
                  : require('../../images/avatar.png')
              }
            />
          </Col>

          <Col xs={9} sm={9} md={9} xl={9} className="profilename">
            {props.data1.userData.name + ' ' + props.data1.userData.lname}
          </Col>
        </Row>
      </Link>
    </>
  );

  return (
    <div className="menu_btn">
      {avat}
      {navTop_pc}

      {windowDimensions.width > 1000 ? menu : null}
      {windowDimensions.width < 1000 ? btnmenumob : null}
    </div>
  );
}

AdminMenu.propTypes = {
  dispatch: PropTypes.func.isRequired,
  adminMenu: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  adminMenu: makeSelectAdminMenu(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(AdminMenu);
