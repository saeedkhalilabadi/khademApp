import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the adminMenu state domain
 */

const selectAdminMenuDomain = state => state.adminMenu || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by AdminMenu
 */

const makeSelectAdminMenu = () =>
  createSelector(
    selectAdminMenuDomain,
    substate => substate,
  );

export default makeSelectAdminMenu;
export { selectAdminMenuDomain };
