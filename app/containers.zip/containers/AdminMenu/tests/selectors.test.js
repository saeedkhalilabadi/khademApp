// import { selectAdminMenuDomain } from '../selectors';

describe('selectAdminMenuDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
