/*
 *
 * BrancheMenu actions
 *
 */

import { 
  GET_DASHBOARD,
  GET_DASHBOARD_SUCCESS,
  GET_DASHBOARD_FAIL,
 } from './constants';

export function getDashboard() {
  return {
    type: GET_DASHBOARD,
  };
}


export function getDashboardSuccess(data) {
  return {
    type: GET_DASHBOARD_SUCCESS,
    data
  };
}


export function getDashboardFail(err) {
  return {
    type: GET_DASHBOARD_FAIL,
    err
  };
}
