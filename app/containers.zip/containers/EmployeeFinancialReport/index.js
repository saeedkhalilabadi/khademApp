/**
 *
 * EmployeeFinancialReport
 *
 */

import React, { memo, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { Col, Row, Form, Button } from 'react-bootstrap';

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectEmployeeFinancialReport from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import { getData } from './actions';
import './index.css';
import '../../src/allStyles.css';

export function EmployeeFinancialReport({
  employeeFinancialReport,
  dispatch,
  props,
}) {
  useInjectReducer({ key: 'employeeFinancialReport', reducer });
  useInjectSaga({ key: 'employeeFinancialReport', saga });
  const [getdata, setgetdata] = useState(true);

  console.log(employeeFinancialReport);
  if (getdata)
    setTimeout(() => {
      setgetdata(false);
      dispatch(getData({ branche_id: 'self' }));
    }, 100);

  return (
    <div>
      <Helmet>
        <title>EmployeeFinancialReport</title>
        <meta
          name="description"
          content="Description of EmployeeFinancialReport"
        />
      </Helmet>
      <FormattedMessage {...messages.header} />
    </div>
  );
}

EmployeeFinancialReport.propTypes = {
  dispatch: PropTypes.func.isRequired,
  employeeFinancialReport: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  employeeFinancialReport: makeSelectEmployeeFinancialReport(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(EmployeeFinancialReport);
