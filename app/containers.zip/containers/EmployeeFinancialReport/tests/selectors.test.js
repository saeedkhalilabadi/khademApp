// import { selectEmployeeFinancialReportDomain } from '../selectors';

describe('selectEmployeeFinancialReportDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
