/**
 *
 * Asynchronously loads the component for EmployeeFinancialReport
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
