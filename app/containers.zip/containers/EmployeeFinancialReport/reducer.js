/*
 *
 * EmployeeFinancialReport reducer
 *
 */
import produce from 'immer';
import { GET_DATA, GET_DATA_SUCCESS, GET_DATA_ERROR } from './constants';

export const initialState = {
  data: [],
  load: 0,
};

/* eslint-disable default-case, no-param-reassign */
const employeeFinancialReportReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case GET_DATA:
        break;
      case GET_DATA_SUCCESS:
        draft.data = action.data.data;
        break;
      case GET_DATA_ERROR:
        break;
    }
  });

export default employeeFinancialReportReducer;
