/*
 *
 * EmployeeFinancialReport constants
 *
 */

export const GET_DATA = 'app/EmployeeFinancialReport/GET_DATA';
export const GET_DATA_SUCCESS = 'app/EmployeeFinancialReport/GET_DATA_SUCCESS';
export const GET_DATA_ERROR = 'app/EmployeeFinancialReport/GET_DATA_ERROR';
