import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the employeeFinancialReport state domain
 */

const selectEmployeeFinancialReportDomain = state =>
  state.employeeFinancialReport || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by EmployeeFinancialReport
 */

const makeSelectEmployeeFinancialReport = () =>
  createSelector(
    selectEmployeeFinancialReportDomain,
    substate => substate,
  );

export default makeSelectEmployeeFinancialReport;
export { selectEmployeeFinancialReportDomain };
