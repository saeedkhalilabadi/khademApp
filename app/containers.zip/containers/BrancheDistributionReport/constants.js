/*
 *
 * BrancheDistributionReport constants
 *
 */

export const GET_DATA = 'app/BrancheDistributionReport/GET_DATA';
export const GET_DATA_SUCCESS =
  'app/BrancheDistributionReport/GET_DATA_SUCCESS';
export const GET_DATA_ERROR = 'app/BrancheDistributionReport/GET_DATA_ERROR';
