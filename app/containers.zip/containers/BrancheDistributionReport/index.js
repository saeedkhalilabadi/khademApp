/**
 *
 * BrancheDistributionReport
 *
 */

import React, { memo, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { Col, Row, Form, Button } from 'react-bootstrap';

import 'react-modern-calendar-datepicker/lib/DatePicker.css';
import DatePicker from 'react-modern-calendar-datepicker';

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectBrancheDistributionReport from './selectors';
import reducer from './reducer';
import saga from './saga';

import '../../src/allStyles.css';
import './index.css';
import { getData } from './actions';

export function BrancheDistributionReport({
  brancheDistributionReport,
  props,
  dispatch, 
}) {
  useInjectReducer({ key: 'brancheDistributionReport', reducer });
  useInjectSaga({ key: 'brancheDistributionReport', saga });
  const [getdata, setgetdata] = useState(true);
  if (getdata)
    setTimeout(() => {
      setgetdata(false);
      dispatch(getData({ date: 'today' }));
    }, 50);
  const selectDate = (
    <Row className="title">
      <DatePicker
        value={
          brancheDistributionReport.date == null
            ? null
            : {
                day: brancheDistributionReport.date.d,
                month: brancheDistributionReport.date.m,
                year: brancheDistributionReport.date.y,
              }
        }
        onChange={e =>
          dispatch(
            getData({
              date: 'date',
              start_d: e.day,
              start_m: e.month,
              start_y: e.year,
            }),
          )
        }
        shouldHighlightWeekends
        locale="fa" // add this
      />
    </Row>
  );

  const showList = (
    <Row>
      {brancheDistributionReport.data.map(item => (
        <Col xs={12} sm={12} md={12} xl={12} >
          <Row className="showDistributionItem">
            <Col xs={12} sm={12} md={12} xl={12}>
              {item.branche.gender +
                ' ' +
                item.branche.name +
                ' ' +
                item.branche.lname}
            </Col>
            <Col xs={6} sm={6} md={6} xl={6}>
              {' توزیع:' +
                ( item.bags_sum_weight != 0 ?Math.round((item.folwerKg * 100) / item.bags_sum_weight):0) +
                'درصد'}
            </Col>
            <Col xs={6} sm={6} md={6} xl={6}>
              {' گل تحویلی:' +
                (item.bags_sum_weight
                  ? Math.round(item.bags_sum_weight/1000 * 100) / 100
                  : 0)}
            </Col>
            <Col xs={6} sm={6} md={6} xl={6}>
              {'گل توزیع شده:' +
                (item.folwerKg ? Math.round(item.folwerKg/1000 * 100) / 100 : 0)}
            </Col>
            <Col xs={6} sm={6} md={6} xl={6}>
              {'سرگل جمع شده:' + (item.headG ? item.headG : 0)}
            </Col>
            <Col xs={6} sm={6} md={6} xl={6}>
              {'سرگل خشک:' + (item.wetHead ? item.wetHead : 0)}
            </Col>
            <Col xs={6} sm={6} md={6} xl={6}>
              {'عیار خیس' +
                Math.round((item.head_flower ? item.head_flower : 0) * 10) / 10}
            </Col>
            <Col xs={6} sm={6} md={6} xl={6}>
              {'عیار خشک' +
                Math.round(
                  (item.wet_head_flower ? item.wet_head_flower : 0) * 10,
                ) /
                  10}
            </Col>
          </Row>
        </Col>
      ))}
    </Row>
  );

  return (
    <div>
      <Helmet>
        <title>BrancheDistributionReport</title>
        <meta
          name="description"
          content="Description of BrancheDistributionReport"
        />
      </Helmet>
      {selectDate}
      {showList}
    </div>
  );
}

BrancheDistributionReport.propTypes = {
  dispatch: PropTypes.func.isRequired,
  brancheDistributionReport: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  brancheDistributionReport: makeSelectBrancheDistributionReport(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(BrancheDistributionReport);
