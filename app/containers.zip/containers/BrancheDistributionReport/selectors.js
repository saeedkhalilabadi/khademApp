import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the brancheDistributionReport state domain
 */

const selectBrancheDistributionReportDomain = state =>
  state.brancheDistributionReport || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by BrancheDistributionReport
 */

const makeSelectBrancheDistributionReport = () =>
  createSelector(
    selectBrancheDistributionReportDomain,
    substate => substate,
  );

export default makeSelectBrancheDistributionReport;
export { selectBrancheDistributionReportDomain };
