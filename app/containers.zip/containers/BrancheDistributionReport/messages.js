/*
 * BrancheDistributionReport Messages
 *
 * This contains all the text for the BrancheDistributionReport container.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.containers.BrancheDistributionReport';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the BrancheDistributionReport container!',
  },
});
