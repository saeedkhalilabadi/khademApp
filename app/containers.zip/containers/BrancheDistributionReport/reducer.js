/*
 *
 * BrancheDistributionReport reducer
 *
 */
import produce from 'immer';
import { GET_DATA, GET_DATA_ERROR, GET_DATA_SUCCESS } from './constants';

export const initialState = {
  data: [],
  date: null,
};

/* eslint-disable default-case, no-param-reassign */
const brancheDistributionReportReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case GET_DATA:
        break;
      case GET_DATA_SUCCESS:
        draft.data = action.data.data;
        draft.date = action.data.date;
        break;
      case GET_DATA_ERROR:
        break;
    }
  });

export default brancheDistributionReportReducer;
