/**
 *
 * BranchAnalyticalReportShow
 *
 */

import React, { memo, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import Loading from 'components/Loading/Loadable';
import { Col, Row, Form, Button } from 'react-bootstrap';

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectBranchAnalyticalReportShow from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import '../../src/allStyles.css';
import './index.css';
import { getData } from './actions';


export function BranchAnalyticalReportShow({
  branchAnalyticalReportShow,
  props,
  dispatch,
}) {
  useInjectReducer({ key: 'branchAnalyticalReportShow', reducer });
  useInjectSaga({ key: 'branchAnalyticalReportShow', saga });

  const [getdata, setgetdata] = useState(true);

  if (getdata)
    setTimeout(() => {
      setgetdata(false);
      dispatch(getData(
        {
          branche_id: props.substate.location.state.em.id
        }));
    }, 50);
  console.log(branchAnalyticalReportShow);

  const title = (
    <Row className="title">
      <Col xs={12} sm={12} md={12} xl={12}>
        {props.substate.location.state.em.branche_name}
      </Col>
    </Row>
  );

  const list = (
    <Row className='emListBody'>
      <Col xs={12} sm={12} md={12} xl={12}>
        <Row className='emItem emItemHeader mx-sm-1'>
          <Col xs={6} sm={3} md={3} xl={3}>
            ردیف
          </Col>
          <Col xs={6} sm={3} md={3} xl={3}>
            تاریخ
          </Col>
          <Col xs={6} sm={3} md={3} xl={3}>
            وزن توزیع
          </Col>
          <Col xs={6} sm={3} md={3} xl={3}>
            هزینه پاک کردن
          </Col>
          <Col xs={6} sm={3} md={3} xl={3}>
            وزن ریشه
          </Col>
          <Col xs={6} sm={3} md={3} xl={3}>
            هزینه ریشه
          </Col>
          <Col xs={6} sm={3} md={3} xl={3}>
            وزن پاداش
          </Col>
          <Col xs={6} sm={3} md={3} xl={3}>
            هزینه پاداش
          </Col>
          <Col xs={12} sm={12} md={3} xl={3}>
            حق الزحمه توزیع
          </Col>
        </Row>
      </Col>
      {branchAnalyticalReportShow.data.lenght == 0 ? null :
        branchAnalyticalReportShow.data.map((rep, index) => (
          <Col xs={12} sm={12} md={12} xl={12} key={rep.id} >
            <Row className='emItem mx-sm-1'>
              <Col xs={6} sm={3} md={3} xl={3}>
                {index+1}
              </Col>
              <Col xs={6} sm={3} md={3} xl={3}>
                {rep.date_in_str.slice(0, 4) +
                  '/' +
                  rep.date_in_str.slice(5, 7) +
                  '/' +
                  rep.date_in_str.slice(8, 10)}
              </Col>
              <Col xs={6} sm={3} md={3} xl={3}>
                {rep.folwerKg / 1000}Kg
              </Col>
              <Col xs={6} sm={3} md={3} xl={3}>
                {rep.priceSub} تومان
              </Col>
              <Col xs={6} sm={3} md={3} xl={3}>
                {rep.root/1000}Kg
              </Col>
              <Col xs={6} sm={3} md={3} xl={3}>
                {rep.priceRoot} تومان
              </Col>
              <Col xs={6} sm={3} md={3} xl={3}>
              {rep.reward/1000}Kg
              </Col>
              <Col xs={6} sm={3} md={3} xl={3}>
              {rep.priceReward} تومان
              </Col>
              <Col xs={12} sm={12} md={3} xl={3}>
               {rep.priceBranche} تومان
              </Col>
            </Row>
          </Col>
        ))
      }
    </Row>
  );
  return (
    <div>
      <Helmet>
        <title>BranchAnalyticalReportShow</title>
        <meta
          name="description"
          content="Description of BranchAnalyticalReportShow"
        />
      </Helmet>
      {branchAnalyticalReportShow.load == 1 ? <Loading /> : null}
      {title}
      {list}
    </div>
  );
}

BranchAnalyticalReportShow.propTypes = {
  dispatch: PropTypes.func.isRequired,
  branchAnalyticalReportShow: PropTypes.func.isRequired
};

const mapStateToProps = createStructuredSelector({
  branchAnalyticalReportShow: makeSelectBranchAnalyticalReportShow(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(BranchAnalyticalReportShow);
