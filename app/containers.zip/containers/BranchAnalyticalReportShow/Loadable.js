/**
 *
 * Asynchronously loads the component for BranchAnalyticalReportShow
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
