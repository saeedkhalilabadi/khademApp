/*
 *
 * BranchAnalyticalReportShow constants
 *
 */

export const GET_DATA = 'app/BranchAnalyticalReportShow/GET_DATA';
export const GET_DATA_SUCCESS = 'app/BranchAnalyticalReportShow/GET_DATA_SUCCESS';
export const GET_DATA_ERROR = 'app/BranchAnalyticalReportShow/GET_DATA_ERROR';
