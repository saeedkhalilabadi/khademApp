// import { selectBranchAnalyticalReportShowDomain } from '../selectors';

describe('selectBranchAnalyticalReportShowDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
