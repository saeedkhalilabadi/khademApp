// import { take, call, put, select } from 'redux-saga/effects';
// import { take, call, put, select } from 'redux-saga/effects';

// Individual exports for testing

import { takeLatest, call, put, select } from 'redux-saga/effects';
import axios from '../axios/axios-user';
import { GET_DATA } from './constants';
import { getDataSuccess, getDataError } from './actions';


function* getdatasaga(params) {
  let data;
  let e = null;

  yield axios
    .post('api/deliveres/manager/getreport', params.data, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
       console.log(response.data, 'data');
      data = response.data;
      e = true;
    })
    .catch(error => {
      console.log(error.response);
      data = error;
      e = false;
    });
  if (e) yield put(getDataSuccess(data));
  else yield put(getDataError(data));
}


// Individual exports for testing
export default function* branchAnalyticalReportShowSaga() {
  yield takeLatest(GET_DATA, getdatasaga);
  // See example in containers/HomePage/saga.js
}

