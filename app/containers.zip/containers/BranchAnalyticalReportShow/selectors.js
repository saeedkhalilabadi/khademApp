import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the branchAnalyticalReportShow state domain
 */

const selectBranchAnalyticalReportShowDomain = state =>
  state.branchAnalyticalReportShow || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by BranchAnalyticalReportShow
 */

const makeSelectBranchAnalyticalReportShow = () =>
  createSelector(
    selectBranchAnalyticalReportShowDomain,
    substate => substate,
  );

export default makeSelectBranchAnalyticalReportShow;
export { selectBranchAnalyticalReportShowDomain };
