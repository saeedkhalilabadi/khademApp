/*
 *
 * AdminSetting constants
 *
 */

export const GET_DATA = 'app/AdminSetting/GET_DATA';
export const GET_DATA_SUCCESS = 'app/AdminSetting/GET_DATA_SUCCESS';
export const GET_DATA_ERROR = 'app/AdminSetting/GET_DATA_ERROR';

export const SET_DATA = 'app/AdminSetting/SET_DATA';
export const SET_DATA_SUCCESS = 'app/AdminSetting/SET_DATA_SUCCESS';
export const SET_DATA_ERROR = 'app/AdminSetting/SET_DATA_ERROR';
