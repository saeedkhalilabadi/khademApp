/*
 *
 * AdminSetting actions
 *
 */

import {
  GET_DATA,
  GET_DATA_ERROR,
  GET_DATA_SUCCESS,
  SET_DATA,
  SET_DATA_ERROR,
  SET_DATA_SUCCESS,
} from './constants';

export function getData(data) {
  return {
    type: GET_DATA,
    data,
  };
}
export function getDataSuccess(data) {
  return {
    type: GET_DATA_SUCCESS,
    data,
  };
}
export function getDataError(data) {
  return {
    type: GET_DATA_ERROR,
    data,
  };
}
export function setData(data) {
  return {
    type: SET_DATA,
    data,
  };
}
export function setDataSuccess(data) {
  return {
    type: SET_DATA_SUCCESS,
    data,
  };
}
export function setDataError(data) {
  return {
    type: SET_DATA_ERROR,
    data,
  };
}
