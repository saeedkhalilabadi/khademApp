/**
 *
 * AdminSetting
 *
 */

import React, { memo, useState } from 'react';
import PropTypes, { object } from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import NumberFormat from 'react-number-format';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { Col, Row, Form, Button } from 'react-bootstrap';
import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectAdminSetting from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import { getData, setData } from './actions';
import '../../src/allStyles.css';
import './index.css';

export function AdminSetting({ adminSetting, props, dispatch }) {
  useInjectReducer({ key: 'adminSetting', reducer });
  useInjectSaga({ key: 'adminSetting', saga });
  const [getdata, setgetdata] = useState(true);
  const [selectedId, setselectedId] = useState(0);
  const [value, setvalue] = useState(0);

  if (getdata)
    setTimeout(() => {
      setgetdata(false);
      dispatch(getData());
    }, 100);

  const title = (
    <Row>
      <Col className="title">تنظیمات</Col>
    </Row>
  );
  const showSetting = (
    <Row>
      {Object.keys(adminSetting.data).map(item => (
        <Col xs={12} sm={12} md={12} xl={12} className="setting">
          <Row className="settingItems">
            <Col xs={5} sm={5} md={5} xl={5}>
              {adminSetting.data[item].name}
            </Col>
            {item == selectedId ? (
              <Col xs={7} sm={7} md={7} xl={7}>
                <NumberFormat
                  onFocus={e => e.target.select()}
                  style={{ maxWidth: '80px', marginLeft: '5px' }}
                  defaultValue={adminSetting.data[item].value}
                  thousandSeparator={true}
                  onValueChange={e => setvalue(e.value)}
                />
                <Button
                  variant="warning"
                  size="sm"
                  disabled={value <= 0}
                  onClick={() => {
                    dispatch(
                      setData({
                        key: adminSetting.data[item].key,
                        value,
                      }),
                    );
                    setselectedId(0);
                  }}
                >
                  ثبت
                </Button>
                <Button
                  className="mx-2"
                  variant="warning"
                  size="sm"
                  onClick={() => {
                    setselectedId(0);
                  }}
                >
                  انصراف
                </Button>
              </Col>
            ) : (
              <Col xs={7} sm={7} md={7} xl={7}>
                <Row>
                  <Col>
                    <NumberFormat
                      value={adminSetting.data[item].value}
                      displayType={'text'}
                      thousandSeparator={true}
                      renderText={value => <div>{value + ' تومان '}</div>}
                    />
                  </Col>
                  <Col>
                    <Button
                      variant="warning"
                      size="sm"
                      onClick={() => setselectedId(item)}
                    >
                      ویرایش
                    </Button>
                  </Col>
                </Row>
              </Col>
            )}
          </Row>
        </Col>
      ))}
    </Row>
  );

  return (
    <div>
      <Helmet>
        <title>تنظیمات</title>
      </Helmet>
      {title}

      {showSetting}
    </div>
  );
}

AdminSetting.propTypes = {
  dispatch: PropTypes.func.isRequired,
  adminSetting: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  adminSetting: makeSelectAdminSetting(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(AdminSetting);
