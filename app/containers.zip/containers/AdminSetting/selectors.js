import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the adminSetting state domain
 */

const selectAdminSettingDomain = state => state.adminSetting || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by AdminSetting
 */

const makeSelectAdminSetting = () =>
  createSelector(
    selectAdminSettingDomain,
    substate => substate,
  );

export default makeSelectAdminSetting;
export { selectAdminSettingDomain };
