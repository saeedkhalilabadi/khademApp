/**
 *
 * Asynchronously loads the component for AdminSetting
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
