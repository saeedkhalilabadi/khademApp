/*
 *
 * EmployeeDashbord constants
 *
 */

export const DEFAULT_ACTION = 'app/EmployeeDashbord/DEFAULT_ACTION';
