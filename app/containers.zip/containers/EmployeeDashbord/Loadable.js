/**
 *
 * Asynchronously loads the component for EmployeeDashbord
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
