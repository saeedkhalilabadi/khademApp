// import { selectEmployeeDashbordDomain } from '../selectors';

describe('selectEmployeeDashbordDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
