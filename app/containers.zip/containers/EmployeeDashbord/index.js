/**
 *
 * EmployeeDashbord
 *
 */

import React, { memo, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { Col, Row, Foem } from 'react-bootstrap';
import Test from '../../components/Test/Loadable';
import PersonAddAlt1Icon from '@mui/icons-material/PersonAddAlt1';
import LocalFloristIcon from '@mui/icons-material/LocalFlorist';
import ContentPasteIcon from '@mui/icons-material/ContentPaste';
import GroupsIcon from '@mui/icons-material/Groups';
import LayersIcon from '@mui/icons-material/Layers';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import SpaIcon from '@mui/icons-material/Spa';
import CreditCardIcon from '@mui/icons-material/CreditCard';
import LocalAtmIcon from '@mui/icons-material/LocalAtm';
import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectEmployeeDashbord from './selectors';
import reducer from './reducer';
import saga from './saga';
import './index.css';
import { getDashboard } from '../BrancheMenu/actions';

export function EmployeeDashbord({ employeeDashbord, dispatch, props }) {
  useInjectReducer({ key: 'employeeDashbord', reducer });
  useInjectSaga({ key: 'employeeDashbord', saga });

  const [getdata, setgetdata] = useState(true);

  if (getdata)
    setTimeout(() => {
      setgetdata(false);
      dispatch(getDashboard());
    }, 200);

  const desk = (
    <Row className="justify-content-center">
      <Col className="jobsIcons" xs={3} sm={3} md={3} xl={3}>
        <Link to="/NewSub" className="textIcons">
          <Row>
            <Col xs={12} sm={12} md={12} xl={12}>
              <PersonAddAlt1Icon
                className="icons"
                style={{
                  color: '#0f9d58',
                  background: 'rgba(15, 157, 88, 0.11)',
                }}
              />
            </Col>
            <Col xs={12} sm={12} md={12} xl={12}>
              ثبت نام مشترک
            </Col>
            <Col
              xs={12}
              sm={12}
              md={12}
              xl={12}
              className="numbersIcons"
              style={{
                color: '#0f9d58',
              }}
            />
          </Row>
        </Link>
      </Col>
      <Col className="jobsIcons" xs={3} sm={3} md={3} xl={3}>
        <Link to="/BagRegister" className="textIcons">
          <Row>
            <Col xs={12} sm={12} md={12} xl={12}>
              <LayersIcon
                className="icons"
                style={{
                  color: '#0f9d58',
                  background: 'rgba(15, 157, 88, 0.11)',
                }}
              />
            </Col>
            <Col xs={12} sm={12} md={12} xl={12}>
              ثبت کیسه
            </Col>
            <Col
              xs={12}
              sm={12}
              md={12}
              xl={12}
              className="numbersIcons"
              style={{
                color: '#0f9d58',
              }}
            />
          </Row>
        </Link>
      </Col>
      <Col className="jobsIcons" xs={3} sm={3} md={3} xl={3}>
        <Link to="/SelectOpenedLists" className="textIcons">
          <Row>
            <Col xs={12} sm={12} md={12} xl={12}>
              <LocalFloristIcon
                className="icons"
                style={{
                  color: '#ff8561',
                  background: 'rgba(255, 133, 97, 0.11)',
                }}
              />
            </Col>

            <Col xs={12} sm={12} md={12} xl={12} className="textIcons">
              توزیع
            </Col>
            <Col
              xs={12}
              sm={12}
              md={12}
              xl={12}
              className="numbersIcons"
              style={{
                color: '#ff8561',
              }}
            />
          </Row>
        </Link>
      </Col>
      <Col className="jobsIcons" xs={3} sm={3} md={3} xl={3}>
        <Link to="/Sales" className="textIcons">
          <Row>
            <Col xs={12} sm={12} md={12} xl={12}>
              <ShoppingCartIcon
                className="icons"
                style={{
                  color: '#9c27b0',
                  background: 'rgba(156, 39, 176, 0.11)',
                }}
              />
            </Col>

            <Col xs={12} sm={12} md={12} xl={12} className="textIcons">
              {' '}
              فروش
            </Col>
            <Col
              xs={12}
              sm={12}
              md={12}
              xl={12}
              className="numbersIcons"
              style={{
                color: '#9c27b0',
              }}
            />
          </Row>
        </Link>
      </Col>
      <Col className="jobsIcons" xs={3} sm={3} md={3} xl={3}>
        <Link to="/RegistrationHead" className="textIcons">
          <Row>
            <Col xs={12} sm={12} md={12} xl={12}>
              <SpaIcon
                className="icons"
                style={{
                  color: '#9c27b0',
                  background: 'rgba(156, 39, 176, 0.11)',
                }}
              />
            </Col>

            <Col xs={12} sm={12} md={12} xl={12} className="textIcons">
              {' '}
              ثبت سرگل
            </Col>
            <Col
              xs={12}
              sm={12}
              md={12}
              xl={12}
              className="numbersIcons"
              style={{
                color: '#9c27b0',
              }}
            />
          </Row>
        </Link>
      </Col>
      <Col className="jobsIcons" xs={3} sm={3} md={3} xl={3}>
        <Link to="/Subs" className="textIcons">
          <Row>
            <Col xs={12} sm={12} md={12} xl={12}>
              <GroupsIcon
                className="icons"
                style={{
                  color: '#4287f4',
                  background: 'rgba(66, 135, 244, 0.11)',
                }}
              />
            </Col>

            <Col xs={12} sm={12} md={12} xl={12} className="textIcons">
              {' '}
              مشترکین شعبه
            </Col>
            <Col
              xs={12}
              sm={12}
              md={12}
              xl={12}
              className="numbersIcons"
              style={{
                color: '#4287f4',
              }}
            />
          </Row>
        </Link>
      </Col>
      <Col className="jobsIcons" xs={3} sm={3} md={3} xl={3}>
        <Link to="/EmployeeLists" className="textIcons">
          <Row>
            <Col xs={12} sm={12} md={12} xl={12}>
              <ContentPasteIcon
                className="icons"
                style={{
                  color: '#4287f4',
                  background: 'rgba(66, 135, 244, 0.11)',
                }}
              />
            </Col>

            <Col xs={12} sm={12} md={12} xl={12} className="textIcons">
              {' '}
              گزارش گیری و تایید
            </Col>
            <Col
              xs={12}
              sm={12}
              md={12}
              xl={12}
              className="numbersIcons"
              style={{
                color: '#4287f4',
              }}
            />
          </Row>
        </Link>
      </Col>
      <Col className="jobsIcons" xs={3} sm={3} md={3} xl={3}>
        <Link to="/PaymentRegistr" className="textIcons">
          <Row>
            <Col xs={12} sm={12} md={12} xl={12}>
              <CreditCardIcon
                className="icons"
                style={{
                  color: '#4287f4',
                  background: 'rgba(66, 135, 244, 0.11)',
                }}
              />
            </Col>

            <Col xs={12} sm={12} md={12} xl={12}>
              {' '}
              ثبت پرداخت
            </Col>
            <Col
              xs={12}
              sm={12}
              md={12}
              xl={12}
              className="numbersIcons"
              style={{
                color: '#4287f4',
              }}
            />
          </Row>
        </Link>
      </Col>
      <Col className="jobsIcons" xs={3} sm={3} md={3} xl={3}>
        <Link to="/EmployeeFinancialReport" className="textIcons">
          <Row>
            <Col xs={12} sm={12} md={12} xl={12}>
              <LocalAtmIcon
                className="icons"
                style={{
                  color: '#4287f4',
                  background: 'rgba(66, 135, 244, 0.11)',
                }}
              />
            </Col>

            <Col xs={12} sm={12} md={12} xl={12} className="textIcons">
              {' '}
              گزارش مالی
            </Col>
            <Col
              xs={12}
              sm={12}
              md={12}
              xl={12}
              className="numbersIcons"
              style={{
                color: '#4287f4',
              }}
            />
          </Row>
        </Link>
      </Col>
    </Row>
  );

  return (
    <div className={props.screen.width < 1000 ? 'mobile' : 'mainBodyDashbord'}>
      <Helmet>
        <title>داشبورد</title>
        <meta name="description" content="Description of EmployeeDashbord" />
      </Helmet>

      {desk}
    </div>
  );
}

EmployeeDashbord.propTypes = {
  dispatch: PropTypes.func.isRequired,
  employeeDashbord: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  employeeDashbord: makeSelectEmployeeDashbord(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(EmployeeDashbord);
