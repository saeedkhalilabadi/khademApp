import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the employeeDashbord state domain
 */

const selectEmployeeDashbordDomain = state =>
  state.employeeDashbord || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by EmployeeDashbord
 */

const makeSelectEmployeeDashbord = () =>
  createSelector(
    selectEmployeeDashbordDomain,
    substate => substate,
  );

export default makeSelectEmployeeDashbord;
export { selectEmployeeDashbordDomain };
