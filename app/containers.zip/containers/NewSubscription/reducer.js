/*
 *
 * NewSubscription reducer
 *
 */
import produce from 'immer';
import {
  GET_DATA,
  GET_DATA_ERROR,
  GET_DATA_SUCCESS,
  ADD_NEW,
  ADD_NEW_ERROR,
  ADD_NEW_SUCCESS,
  SET_SHOW_ITEM,
  ALERT,
  SET_VALUE,
} from './constants';

export const initialState = {
  load: 0,
  data: {
    id: '',
    name: '',
    lname: '',
    gender: '',
    code: '',
    mobile: '',
    phone: '',
    address: '',
    meliCode: '',
    shaba: '',
    bankNumber: '',
    desc: '',
    description: '',
    foreigners: false,
  },
  showItem: 0,
  roles: [],
  createsuccess: 0,
  createerror: { value: ' ', status: 0 },
};

/* eslint-disable default-case, no-param-reassign */
const newSubscriptionReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case SET_VALUE:
        if (action.data.subject == 'name') draft.data.name = action.data.value;
        if (action.data.subject == 'lname')
          draft.data.lname = action.data.value;
        if (action.data.subject == 'gender')
          draft.data.gender = action.data.value;
          if (action.data.subject == 'foreigners')
          draft.data.foreigners = action.data.value;
        if (action.data.subject == 'mobile')
          draft.data.mobile = action.data.value;
        if (action.data.subject == 'phone')
          draft.data.phone = action.data.value;
        if (action.data.subject == 'address')
          draft.data.address = action.data.value;
        if (action.data.subject == 'meliCode')
          draft.data.meliCode = action.data.value;
        if (action.data.subject == 'shaba')
          draft.data.shaba = action.data.value;
        if (action.data.subject == 'bankNumber')
          draft.data.bankNumber = action.data.value;
        if (action.data.subject == 'desc') draft.data.desc = action.data.value;
        if (action.data.subject == 'description') draft.data.description = action.data.value;

        break;
      case SET_SHOW_ITEM:
        draft.createsuccess = action.data;
        if (action.data == 0) {
          draft.data.meliCode = '';
          draft.data.foreigners = false;
        }
        break;
      case GET_DATA:
        draft.load = 1;

        break;
      case GET_DATA_SUCCESS:
        draft.load = 0;
        draft.createsuccess = 1;
        if (action.data.status == 'true') draft.data = action.data.data;
        else
          draft.data = {
            id: '',
            name: '',
            lname: '',
            gender: '',
            code: '',
            mobile: '',
            phone: '',
            address: '',
            meliCode: draft.data.meliCode,
            shaba: '',
            bankNumber: '',
            desc: '',
            foreigners: draft.data.foreigners,
          };

        break;
      case GET_DATA_ERROR:
        draft.load = 0;
        break;
      case ADD_NEW:
        draft.load = 1;
        break;
      case ADD_NEW_SUCCESS:
        draft.load = 0;
        draft.createsuccess = 2;
        draft.createerror = { value: ' ', status: 0 };
        if (action.data.status == 'true') draft.data = action.data.data;

        break;
      case ADD_NEW_ERROR:
        draft.load = 0;
        draft.createerror.status = 1;
        console.log(
          action.data.data.errors[Object.keys(action.data.data.errors)[0]],
        );
        draft.createerror.value =
          action.data.data.errors[Object.keys(action.data.data.errors)[0]];

        break;
      case ALERT:
        draft.createerror = action.createerror;
        break;
      case 'text':
        draft.data = {
          id: '',
          name: '',
          lname: '',
          gender: '',
          code: '',
          mobile: '',
          phone: '',
          address: '',
          meliCode: '',
          shaba: '',
          bankNumber: '',
          desc: '',
          foreigners: false,
        };
        break;
    }
  });

export default newSubscriptionReducer;
