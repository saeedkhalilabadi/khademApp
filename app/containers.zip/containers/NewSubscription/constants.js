/*
 *
 * NewSubscription constants
 *
 */

export const GET_DATA = 'app/NewSubscription/GET_DATA';
export const GET_DATA_SUCCESS = 'app/NewSubscription/GET_DATA_SUCCESS';
export const GET_DATA_ERROR = 'app/NewSubscription/GET_DATA_ERROR';

export const ADD_NEW = 'app/NewSubscription/ADD_NEW';
export const ADD_NEW_SUCCESS = 'app/NewSubscription/ADD_NEW_SUCCESS';
export const ADD_NEW_ERROR = 'app/NewSubscription/ADD_NEW_ERROR';

export const SET_SHOW_ITEM = 'app/NewSubscription/SET_SHOW_ITEM';
export const ALERT = 'app/AddEmployee/ALERT';
export const SET_VALUE = 'app/AddEmployee/SET_VALUE';
