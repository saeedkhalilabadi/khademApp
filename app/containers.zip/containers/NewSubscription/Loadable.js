/**
 *
 * Asynchronously loads the component for NewSubscription
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
