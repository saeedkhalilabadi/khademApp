import { takeLatest, call, put, select } from 'redux-saga/effects';

import axios from '../axios/axios-user';
import {
  addNewError,
  addNewSuccess,
  getDataError,
  getDataSuccess,
} from './actions';
import { ADD_NEW, GET_DATA } from './constants';

function* addnew(data) {
  let Data = null;
  let e = null;
  console.log(data.data);
  yield axios
    .post('api/subscriptions', data.data, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      Data = response;
      console.log(Data, 'ss');

      e = true;
    })
    .catch(error => {
      Data = error;
      console.log(error.response, 'ee');

      e = false;
    });

  if (e) yield put(addNewSuccess(Data.data));
  else yield put(addNewError(Data.response));
}
function* getdata(data) {
  let Data = null;
  let e = null;
  console.log(data.data);
  yield axios
    .post('api/subscriptions/find', data.data, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      Data = response;
      console.log(Data, 'ss');

      e = true;
    })
    .catch(error => {
      Data = error;
      console.log(error.response, 'ee');

      e = false;
    });

  if (e) yield put(getDataSuccess(Data.data));
  else yield put(getDataError(Data.response));
}

// Individual exports for testing
export default function* newSubscriptionSaga() {
  yield takeLatest(ADD_NEW, addnew);
  yield takeLatest(GET_DATA, getdata);

  // See example in containers/HomePage/saga.js
}
