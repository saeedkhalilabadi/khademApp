/*
 *
 * NewSubscription actions
 *
 */

import {
  GET_DATA,
  GET_DATA_ERROR,
  GET_DATA_SUCCESS,
  SET_SHOW_ITEM,
  ALERT,
  SET_VALUE,
  ADD_NEW,
  ADD_NEW_ERROR,
  ADD_NEW_SUCCESS,
} from './constants';

export function getData(data) {
  return {
    type: GET_DATA,
    data,
  };
}

export function getDataSuccess(data) {
  return {
    type: GET_DATA_SUCCESS,
    data,
  };
}

export function getDataError(data) {
  return {
    type: GET_DATA_ERROR,
    data,
  };
}
export function addNew(data) {
  return {
    type: ADD_NEW,
    data,
  };
}

export function addNewSuccess(data) {
  return {
    type: ADD_NEW_SUCCESS,
    data,
  };
}

export function addNewError(data) {
  return {
    type: ADD_NEW_ERROR,
    data,
  };
}

export function setShowItem(data) {
  return {
    type: SET_SHOW_ITEM,
    data,
  };
}
export function AlertMessage(createerror) {
  return {
    type: ALERT,
    createerror,
  };
}
export function setValue(data) {
  return {
    type: SET_VALUE,
    data,
  };
}
