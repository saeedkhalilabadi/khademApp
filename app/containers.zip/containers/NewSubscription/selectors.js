import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the newSubscription state domain
 */

const selectNewSubscriptionDomain = state =>
  state.newSubscription || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by NewSubscription
 */

const makeSelectNewSubscription = () =>
  createSelector(
    selectNewSubscriptionDomain,
    substate => substate,
  );

export default makeSelectNewSubscription;
export { selectNewSubscriptionDomain };
