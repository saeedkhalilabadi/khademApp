/**
 *
 * NewSubscription
 *
 */

import React, { memo, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import NumberFormat from 'react-number-format';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import Loading from 'components/Loading/Loadable';
import Checkbox from '@mui/material/Checkbox';
import Badge from '@mui/material/Badge';
import IconButton from '@mui/material/IconButton';
import Collapse from '@mui/material/Collapse';
import CloseIcon from '@mui/icons-material/Close';
import { Col, Row, Form, Button } from 'react-bootstrap';
import Alert from '@mui/material/Alert';
import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectNewSubscription from './selectors';
import SubValidate from '../SubValidate/Loadable';
import {
  setShowItem,
  AlertMessage,
  addNew,
  getData,
  setValue,
} from './actions';
import reducer from './reducer';
import saga from './saga';

import './index.css';
import '../../src/allStyles.css';

export function NewSubscription({ newSubscription, dispatch, props }) {
  useInjectReducer({ key: 'newSubscription', reducer });
  useInjectSaga({ key: 'newSubscription', saga });

  console.log(newSubscription);

  const form =
    newSubscription.data == null ? null : (
      <div style={{ margin: '0px' }}>
        <Row className="form" justify-content-center>
          <Col sx={12} sm={12} md={3} xl={3} className="filde">
            <Form.Group className="mb-1" controlId="formBasicEmail">
              <Form.Text className="text-muted">خانم /آقای</Form.Text>
              <Form.Control
                as="select"
                size="sm"
                value={
                  newSubscription.data.gender && newSubscription.data.gender
                }
                custom
                style={{ maxWidth: '100px' }}
                onChange={e => {
                  dispatch(
                    setValue({ subject: 'gender', value: e.target.value }),
                  );
                }}
              >
                <option value={0}> انتخاب کنید</option>

                <option value="آقای">آقای</option>
                <option value="خانم">خانم</option>
              </Form.Control>
            </Form.Group>
          </Col>

          <Col sx={12} sm={12} md={3} xl={3} className="filde">
            <Form.Group className="mb-1" controlId="formBasicEmail">
              <Form.Text className="text-muted">نام </Form.Text>

              <Form.Control
                autoComplete="off"
                size="sm"
                type="text"
                value={newSubscription.data.name && newSubscription.data.name}
                placeholder=" نام"
                onChange={e => {
                  dispatch(
                    setValue({ subject: 'name', value: e.target.value }),
                  );
                }}
              />
            </Form.Group>
          </Col>
          <Col sx={12} sm={12} md={3} xl={3} className="filde">
            <Form.Group className="mb-1" controlId="formBasicEmail">
              <Form.Text className="text-muted">نام خانوادگی</Form.Text>

              <Form.Control
                autoComplete="off"

                size="sm"
                type="text"
                value={newSubscription.data.lname && newSubscription.data.lname}
                placeholder=" نام خانوادگی"
                onChange={e => {
                  dispatch(
                    setValue({ subject: 'lname', value: e.target.value }),
                  );
                }}
              />
            </Form.Group>{' '}
          </Col>

          <Col sx={12} sm={12} md={6} xl={6} className="filde">
            <Form.Group className="mb-1" controlId="formBasicEmail">
              <Form.Text className="text-muted">شماره تلفن همراه</Form.Text>

              <Form.Control
                autoComplete="off"

                size="sm"
                value={
                  newSubscription.data.mobile && newSubscription.data.mobile
                }
                type="number"
                placeholder="شماره تلفن همراه"
                onChange={e => {
                  dispatch(
                    setValue({ subject: 'mobile', value: e.target.value }),
                  );
                }}
              />
            </Form.Group>
          </Col>
          <Col sx={12} sm={12} md={6} xl={6} className="filde">
            <Form.Group className="mb-1" controlId="formBasicEmail">
              <Form.Text className="text-muted">شماره تلفن ثابت</Form.Text>

              <Form.Control
                autoComplete="off"

                size="sm"
                value={newSubscription.data.phone && newSubscription.data.phone}
                type="number"
                placeholder="شماره تلفن ثابت"
                onChange={e => {
                  dispatch(
                    setValue({ subject: 'phone', value: e.target.value }),
                  );
                }}
              />
            </Form.Group>
          </Col>

          <Col sx={12} sm={12} md={6} xl={6} className="filde">
            <Form.Group className="mb-1" controlId="formBasicEmail">
              <Form.Text className="text-muted">آدرس</Form.Text>

              <Form.Control
                autoComplete="off"

                size="sm"
                value={
                  newSubscription.data.address && newSubscription.data.address
                }
                type="text"
                placeholder="آدرس"
                onChange={e => {
                  dispatch(
                    setValue({ subject: 'address', value: e.target.value }),
                  );
                }}
              />
            </Form.Group>
          </Col>
          <Col sx={12} sm={12} md={6} xl={6} className="filde">
            <Form.Group className="mb-1" controlId="formBasicEmail">
              <Form.Text className="text-muted">شماره شبا</Form.Text>

              <NumberFormat
                autoComplete="off"

                value={newSubscription.data.shaba && newSubscription.data.shaba}
                placeholder="شماره شبا"
                format="IR## #### #### #### #### #### ##"
                style={{ direction: 'ltr', width: '100%' }}
                mask="_"
                onValueChange={e => {
                  dispatch(setValue({ subject: 'shaba', value: e.value }));
                }}
              />
            </Form.Group>
          </Col>
          <Col sx={12} sm={12} md={6} xl={6} className="filde">
            <Form.Group className="mb-1" controlId="formBasicEmail">
              <Form.Text className="text-muted">شماره کارت</Form.Text>

              <NumberFormat
                value={
                  newSubscription.data.bankNumber &&
                  newSubscription.data.bankNumber
                }
                placeholder="شماره کارت"
                format="#### #### #### ####"
                style={{ direction: 'ltr', width: '100%' }}
                mask="_"
                onValueChange={e => {
                  dispatch(setValue({ subject: 'bankNumber', value: e.value }));
                }}
              />
            </Form.Group>
          </Col>
          <Col sx={12} sm={12} md={6} xl={6} className="filde">
            <Form.Group className="mb-1" controlId="formBasicEmail">
              <Form.Text className="text-muted">مدرک/معرف</Form.Text>

              <Form.Control
                autoComplete="off"

                size="sm"
                value={newSubscription.data.desc && newSubscription.data.desc}
                type="text"
                placeholder="مدرک/معرف"
                onChange={e => {
                  dispatch(
                    setValue({ subject: 'desc', value: e.target.value }),
                  );
                }}
              />
            </Form.Group>
          </Col>

          <Col sx={12} sm={12} md={12} xl={12} className="filde">
            <Form.Group className="mb-1" controlId="formBasicEmail">
              <Form.Text className="text-muted">توضیحات</Form.Text>

              <Form.Control
                autoComplete="off"

                size="sm"
                value={newSubscription.data.description && newSubscription.data.description}
                type="text"
                placeholder="توضیحات"
                onChange={e => {
                  dispatch(
                    setValue({ subject: 'description', value: e.target.value }),
                  );
                }}
              />
            </Form.Group>
          </Col>

          

          <Col sx={12} sm={12} md={6} xl={6} className="filde">
            <Button
              style={{ margin: 'auto', marginTop: '30px', minWidth: '100%' }}
              variant="warning"
              size="sm"
              onClick={handelinsert}
            >
              ثبت{' '}
            </Button>
          </Col>
          <Col sx={12} sm={12} md={6} xl={6} className="filde">
            <Link to="/dashbord">
              <Button
                style={{ margin: 'auto', marginTop: '30px', minWidth: '100%' }}
                variant="outline-warning"
                size="sm"
                onClick={() => dispatch(setShowItem(0))}
              >
                برگشت
              </Button>
            </Link>
          </Col>
        </Row>
      </div>
    );

  const title = (
    <Col sm="12" className="title">
      افزودن اشتراک جدید
    </Col>
  );

  function handelinsert() {
    if (newSubscription.data.gender.length < 3) {
      dispatch(
        AlertMessage({
          value: 'جنسیت انتخاب نشده است',
          status: 1,
        }),
      );
    } else if (newSubscription.data.name.length < 3) {
      dispatch(
        AlertMessage({
          value: 'نام به درستی وارد نشده است',
          status: 1,
        }),
      );
    } else if (newSubscription.data.lname.length < 3) {
      dispatch(
        AlertMessage({
          value: 'نام  خانوادگی به درستی وارد نشده است',
          status: 1,
        }),
      );
    } else if (newSubscription.data.mobile.length < 11) {
      dispatch(
        AlertMessage({
          value: 'شماره تلفن همراه به درستی وارد نشده است',
          status: 1,
        }),
      );
    } else if (newSubscription.data.address.length < 10) {
      dispatch(
        AlertMessage({
          value: 'آدرس  به درستی وارد نشده است',
          status: 1,
        }),
      );
    } else if (!newSubscription.data.foreigners && newSubscription.data.meliCode.length < 10) {
      dispatch(
        AlertMessage({
          value: 'کد ملی به درستی وارد نشده است',
          status: 1,
        }),
      );
    } else dispatch(addNew(newSubscription.data));
  }

  const successform = (
    <div>
      <div className="body-addemployee">
        <Row className="form" justify-content-center>
          <Col
            sm="12"
            className="filde"
            style={{ color: 'black', fontSize: '30px' }}
          >
            اطلاعات با موفقیت ثبت شد <br />
            <br />
            <br />
            <br />
            <Link to="subs">
              <Button
                variant="warning"
                style={{ width: 200 }}
                onClick={() => dispatch(setShowItem(0))}
              >
                پایان
              </Button>
            </Link>
          </Col>
        </Row>
      </div>
    </div>
  );

  const getMelicode = (
    <Row style={{ direction: 'rtl' }}>
      <Col xs={9} sm={9} md={3} xl={3}>
        <Checkbox
          Checked={newSubscription.data.foreigners}
          onChange={e => {
            dispatch(
              setValue({ subject: 'foreigners', value: e.target.checked }),
            );
          }}
        />
        اتباع خارجی
      </Col>
      <Col xs={9} sm={9} md={3} xl={3}>
        <Form.Group className="mb-1" controlId="formBasicEmail">
          <Form.Text className="text-muted">
            {newSubscription.data.foreigners ? 'کد اتباع ' : 'کد ملی '}
          </Form.Text>

          <Form.Control
            autoComplete="off"
            size="sm"
            value={newSubscription.data.meliCode}
            type="number"
            placeholder={newSubscription.data.foreigners ? 'کد اتباع ' : 'کد ملی '}
            onChange={e => {
              dispatch(
                setValue({ subject: 'meliCode', value: e.target.value }),
              );
            }}
          />
        </Form.Group>
      </Col>
      <Col xs={3} sm={3} md={6} xl={6}>
        <Button
          style={{ margin: 'auto', marginTop: '23px', minWidth: '100%' }}
          disabled={(!newSubscription.data.foreigners || newSubscription.data.meliCode.length < 3) && newSubscription.data.meliCode.length < 10}
          variant="warning"
          size="sm"
          onClick={() =>
            dispatch(getData({ meliCode: newSubscription.data.meliCode }))
          }
        >
          بررسی
        </Button>
      </Col>
    </Row>
  );

  return (
    <div
      data-aos="fade-right"
      onKeyDown={e => {
        if (e.key === 'Enter') {
          const fields =
            Array.from(e.currentTarget.querySelectorAll('input')) || [];
          const position = fields.indexOf(
            e.target, // as HTMLInputElement (for TypeScript)
          );
          fields[position + 1] && fields[position + 1].focus();
        }
      }}
    >
      <Helmet>
        <title>مشترک جدید</title>
        <meta name="description" content="Description of NewSubscription" />
      </Helmet>

      {title}
      {newSubscription.load == 1 ? <Loading /> : null}
      {newSubscription.createerror.status === 1 ? (
        <Alert
          severity="error"
          align="center"
          style={{
            position: 'fixed',
            top: '60px',
            left: '5%',
            width: '90%',
            zIndex: '100',
          }}
          action={
            <IconButton
              aria-label="close"
              color="inherit"
              size="small"
              onClick={() => {
                dispatch(
                  AlertMessage({
                    value: '',
                    status: 0,
                  }),
                );
              }}
            >
              <CloseIcon fontSize="inherit" />
            </IconButton>
          }
          sx={{ mb: 2 }}
        >
          {newSubscription.createerror.value}
        </Alert>
      ) : (
        <div />
      )}
      {newSubscription.createsuccess === 0 ? getMelicode : null}
      {newSubscription.createsuccess === 1 ? getMelicode : null}
      {newSubscription.createsuccess === 1 ? form : null}
      {newSubscription.createsuccess === 2 ? successform : null}
    </div>
  );
}

NewSubscription.propTypes = {
  dispatch: PropTypes.func.isRequired,
  newSubscription: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  newSubscription: makeSelectNewSubscription(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(NewSubscription);
