/*
 *
 * BranchAnalyticalReport actions
 *
 */

import {
  GET_DATA,
  GET_DATA_ERROR,
  GET_DATA_SUCCESS,
  SEARCH_DATA,
  SEARCH_DATA_ERROR,
  SEARCH_DATA_SUCCESS
} from './constants';

export function getData() {
  return {
    type: GET_DATA,
  };
}
export function getDataSuccess(data) {
  return {
    type: GET_DATA_SUCCESS,
    data,
  };
}
export function getDataError(data) {
  return {
    type: GET_DATA_ERROR,
    data,
  };
}
export function searchData(data) {
  return {
    type: SEARCH_DATA,
    data
  };
}
export function searchDataSuccess(data) {
  return {
    type: SEARCH_DATA_SUCCESS,
    data,
  };
}
export function searchDataError(data) {
  return {
    type: SEARCH_DATA_ERROR,
    data,
  };
}

