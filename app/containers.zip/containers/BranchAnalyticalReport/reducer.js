/*
 *
 * BranchAnalyticalReport reducer
 *
 */
import produce from 'immer';
import {
  GET_DATA,
  GET_DATA_SUCCESS,
  GET_DATA_ERROR,
  SEARCH_DATA,
  SEARCH_DATA_SUCCESS,
  SEARCH_DATA_ERROR,
} from './constants';

export const initialState = {
  data: [],
  load:0
};

/* eslint-disable default-case, no-param-reassign */
const branchAnalyticalReportReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case GET_DATA:
        draft.load = 1
        break;
      case GET_DATA_SUCCESS:
        draft.data=action.data.data;
        draft.load = 0
        break;
      case GET_DATA_ERROR:
        draft.load = 0
        break;
      case SEARCH_DATA:
        draft.load = 1
        break;
      case SEARCH_DATA_SUCCESS:
        draft.data=action.data.branches;
        draft.load = 0
        break;
      case SEARCH_DATA_ERROR:
        draft.load = 0
        break;
    }
  });

export default branchAnalyticalReportReducer;
