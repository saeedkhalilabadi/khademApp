/*
 *
 * BranchAnalyticalReport constants
 *
 */

export const GET_DATA = 'app/BranchAnalyticalReport/GET_DATA';
export const GET_DATA_SUCCESS = 'app/BranchAnalyticalReport/GET_DATA_SUCCESS';
export const GET_DATA_ERROR = 'app/BranchAnalyticalReport/GET_DATA_ERROR'; 



export const SEARCH_DATA = 'app/BranchAnalyticalReport/SEARCH_DATA';
export const SEARCH_DATA_SUCCESS = 'app/BranchAnalyticalReport/SEARCH_DATA_SUCCESS';
export const SEARCH_DATA_ERROR = 'app/BranchAnalyticalReport/SEARCH_DATA_ERROR'; 