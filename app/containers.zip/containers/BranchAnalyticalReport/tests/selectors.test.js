// import { selectBranchAnalyticalReportDomain } from '../selectors';

describe('selectBranchAnalyticalReportDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
