/**
 *
 * Asynchronously loads the component for BranchAnalyticalReport
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
