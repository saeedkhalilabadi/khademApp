/**
 *
 * BranchAnalyticalReport
 *
 */

import React, { memo,useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectBranchAnalyticalReport from './selectors';
import Loading from 'components/Loading/Loadable';
import { Col, Row, Form, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';

import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import '../../src/allStyles.css';
import './index.css';
import { getData,searchData } from './actions';


export function BranchAnalyticalReport({
  branchAnalyticalReport,
  props, 
  dispatch, 
}) {
  useInjectReducer({ key: 'branchAnalyticalReport', reducer });
  useInjectSaga({ key: 'branchAnalyticalReport', saga });
  const [getdata, setgetdata] = useState(true);

  if (getdata)
  setTimeout(() => {
    setgetdata(false);
    dispatch(getData());
  }, 50);
  console.log(branchAnalyticalReport);
  const title = (
    <Row className="title">
     <Col xs={12} sm={12} md={12} xl={12}>
        گزارش تحلیلی شعب
     </Col>
    </Row>
  );
  const search=(
    <Row className='search emListBody'>
       <Col xs={12} sm={12} md={12} xl={12}>
       <Form.Group className="mb-1" controlId="formBasicEmail">
              <Form.Control
                size="sm"
                type="text"
                autoComplete={'off'}
                placeholder="جستجوی شعبه"
                onChange={e => {
                  e.target.value.trim().length > 1 ? dispatch(searchData({word: e.target.value.trim()})) :null;
                  e.target.value.trim().length == 0 ? setgetdata(true) :null;
                }}
              />
            </Form.Group>
       </Col>
    </Row>
  );
  const list=(
   <Row className='emListBody'>
      {branchAnalyticalReport.data.lenght == 0 ? null : 
          branchAnalyticalReport.data.map(em=>(
            <Col  xs={12} sm={6} md={4} xl={3} key={em.id} >
                <Link
                className="textIcons"
                to={{
                  pathname: '/BranchAnalyticalReportShow',
                  state: { em },
                }}
              >
              <Row className='emItem mx-sm-1'>
                 <Col xs={12} sm={12} md={12} xl={12} className='brancheName'>
                   {em.branche_name}
                 </Col>
                 <Col xs={12} sm={12} md={12} xl={12} className='brancheAmdin'>
                    <Row>
                      <Col xs={8} sm={8} md={8} xl={8}>
                         {em.name} {em.lname}

                      </Col>

                      <Col xs={4} sm={4} md={4} xl={4}>
                        کد:{em.id}

                      </Col>
                    </Row>
                 </Col>
              </Row>
              </Link>   
            </Col>
          ))
      }
   </Row>
  );
  return (
    <div>
      <Helmet>
        <title>BranchAnalyticalReport</title>
        <meta
          name="description"
          content="Description of BranchAnalyticalReport"
        />
      </Helmet>
      {branchAnalyticalReport.load==1?<Loading />:null}
      {title}
      {search}
      {list}
    </div>
  );
}

BranchAnalyticalReport.propTypes = {
  dispatch: PropTypes.func.isRequired,
  branchAnalyticalReport: PropTypes.object.isRequired
};

const mapStateToProps = createStructuredSelector({
  branchAnalyticalReport: makeSelectBranchAnalyticalReport(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(BranchAnalyticalReport);
