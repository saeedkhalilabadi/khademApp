import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the branchAnalyticalReport state domain
 */

const selectBranchAnalyticalReportDomain = state =>
  state.branchAnalyticalReport || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by BranchAnalyticalReport
 */

const makeSelectBranchAnalyticalReport = () =>
  createSelector(
    selectBranchAnalyticalReportDomain,
    substate => substate,
  );

export default makeSelectBranchAnalyticalReport;
export { selectBranchAnalyticalReportDomain };
