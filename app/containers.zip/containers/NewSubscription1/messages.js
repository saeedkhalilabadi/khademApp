/*
 * NewSubscription1 Messages
 *
 * This contains all the text for the NewSubscription1 container.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.containers.NewSubscription1';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the NewSubscription1 container!',
  },
});
