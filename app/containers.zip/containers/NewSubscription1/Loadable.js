/**
 *
 * Asynchronously loads the component for NewSubscription1
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
