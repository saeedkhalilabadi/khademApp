import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the newSubscription1 state domain
 */

const selectNewSubscription1Domain = state =>
  state.newSubscription1 || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by NewSubscription1
 */

const makeSelectNewSubscription1 = () =>
  createSelector(
    selectNewSubscription1Domain,
    substate => substate,
  );

export default makeSelectNewSubscription1;
export { selectNewSubscription1Domain };
