/*
 *
 * NewSubscription1 constants
 *
 */

export const DEFAULT_ACTION = 'app/NewSubscription1/DEFAULT_ACTION';
