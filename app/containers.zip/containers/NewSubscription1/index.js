/**
 *
 * NewSubscription1
 *
 */

import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectNewSubscription1 from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';

export function NewSubscription1() {
  useInjectReducer({ key: 'newSubscription1', reducer });
  useInjectSaga({ key: 'newSubscription1', saga });

  return (
    <div>
      <Helmet>
        <title>NewSubscription1</title>
        <meta name="description" content="Description of NewSubscription1" />
      </Helmet>
      <FormattedMessage {...messages.header} />
    </div>
  );
}

NewSubscription1.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  newSubscription1: makeSelectNewSubscription1(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(NewSubscription1);
