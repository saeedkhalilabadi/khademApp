/**
 * Test sagas
 */

/* eslint-disable redux-saga/yield-effects */
// import { take, call, put, select } from 'redux-saga/effects';
// import newSubscription1Saga from '../saga';

// const generator = newSubscription1Saga();

describe('newSubscription1Saga Saga', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
