import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the employeeDistribution state domain
 */

const selectEmployeeDistributionDomain = state =>
  state.employeeDistribution || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by EmployeeDistribution
 */

const makeSelectEmployeeDistribution = () =>
  createSelector(
    selectEmployeeDistributionDomain,
    substate => substate,
  );

export default makeSelectEmployeeDistribution;
export { selectEmployeeDistributionDomain };
