/*
 *
 * EmployeeDistribution constants
 *
 */

export const GET_DATA = 'app/EmployeeDistribution/GET_DATA';
export const GET_DATA_SUCCESS = 'app/EmployeeDistribution/GET_DATA_SUCCESS';
export const GET_DATA_ERROR = 'app/EmployeeDistribution/GET_DATA_ERROR';


export const GET_SUBS = 'app/EmployeeDistribution/GET_SUBS';
export const GET_SUBS_SUCCESS = 'app/EmployeeDistribution/GET_SUBS_SUCCESS';
export const GET_SUBS_ERROR = 'app/EmployeeDistribution/GET_SUBS_ERROR';

export const GET_SUPPLY = 'app/EmployeeDistribution/GET_SUPPLY';
export const GET_SUPPLY_SUCCESS = 'app/EmployeeDistribution/GET_SUPPLY_SUCCESS';
export const GET_SUPPLY_ERROR = 'app/EmployeeDistribution/GET_SUPPLY_ERROR';

export const ADD_DATA = 'app/EmployeeDistribution/ADD_DATA';
export const ADD_DATA_SUCCESS = 'app/EmployeeDistribution/ADD_DATA_SUCCESS';
export const ADD_DATA_ERROR = 'app/EmployeeDistribution/ADD_DATA_ERROR';

export const UPDATE_DATA = 'app/EmployeeDistribution/UPDATE_DATA';
export const UPDATE_DATA_SUCCESS = 'app/EmployeeDistribution/UPDATE_DATA_SUCCESS';
export const UPDATE_DATA_ERROR = 'app/EmployeeDistribution/UPDATE_DATA_ERROR';
export const SEARCH = 'app/EmployeeDistribution/SEARCH';

