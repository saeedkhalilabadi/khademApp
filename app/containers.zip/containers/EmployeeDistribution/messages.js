/*
 * EmployeeDistribution Messages
 *
 * This contains all the text for the EmployeeDistribution container.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.containers.EmployeeDistribution';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the EmployeeDistribution container!',
  },
});
