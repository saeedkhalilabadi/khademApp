/*
 *
 * EmployeeDistribution actions
 *
 */

import {
  GET_DATA,
  GET_DATA_ERROR,
  GET_DATA_SUCCESS,
  GET_SUPPLY,
  GET_SUPPLY_ERROR,
  GET_SUPPLY_SUCCESS,
  GET_SUBS,
  GET_SUBS_ERROR,
  GET_SUBS_SUCCESS,
  ADD_DATA,
  ADD_DATA_ERROR,
  ADD_DATA_SUCCESS,
  UPDATE_DATA,
  UPDATE_DATA_SUCCESS,
  UPDATE_DATA_FAIL,
  SEARCH,
} from './constants';

export function search(data) {
  return {
    type: SEARCH,
    data,
  };
}

export function getData(data) {
  return {
    type: GET_DATA,
    data,
  };
}
export function getDataSuccess(data) {
  return {
    type: GET_DATA_SUCCESS,
    data,
  };
}
export function getDataError(data) {
  return {
    type: GET_DATA_ERROR,
    data,
  };
}
export function getSupply(data) {
  return {
    type: GET_SUPPLY,
    data,
  };
}
export function getSupplySuccess(data) {
  return {
    type: GET_SUPPLY_SUCCESS,
    data,
  };
}
export function getSupplyError(data) {
  return {
    type: GET_SUPPLY_ERROR,
    data,
  };
}

export function getSubs() {
  return {
    type: GET_SUBS,
  };
}
export function getSubsSuccess(data) {
  return {
    type: GET_SUBS_SUCCESS,
    data,
  };
}
export function getSubsError(data) {
  return {
    type: GET_SUBS_ERROR,
    data,
  };
}
export function addData(data) {
  return {
    type: ADD_DATA,
    data,
  };
}
export function addDataSuccess(data) {
  return {
    type: ADD_DATA_SUCCESS,
    data,
  };
}
export function addDataError(data) {
  return {
    type: ADD_DATA_ERROR,
    data,
  };
}

export function updateData(data) {
  return {
    type: UPDATE_DATA,
    data,
  };
}
export function updateDataSuccess(data,act) {
  return {
    type: UPDATE_DATA_SUCCESS,
    data,act
  };
}
export function updateDataError(data,act) {
  return {
    type: UPDATE_DATA_FAIL,
    data,act
  };
}
