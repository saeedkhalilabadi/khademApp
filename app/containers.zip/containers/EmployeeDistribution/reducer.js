/*
 *
 * EmployeeDistribution reducer
 *
 */
import produce from 'immer';
import {
  GET_SUBS,
  GET_SUBS_ERROR,
  GET_SUBS_SUCCESS,
  ADD_DATA_ERROR,
  ADD_DATA,
  ADD_DATA_SUCCESS,
  GET_DATA,
  GET_DATA_ERROR,
  GET_DATA_SUCCESS,
  UPDATE_DATA,
  UPDATE_DATA_SUCCESS,
  UPDATE_DATA_FAIL,
  GET_SUPPLY,
  GET_SUPPLY_ERROR,
  GET_SUPPLY_SUCCESS,
  SEARCH,
  UPDATE_DATA_ERROR,
} from './constants';

export const initialState = {
  load: 0,
  date: 0,
  supply: 0,
  data: null,
  searchSubs: [],
  done: [],
  inDo: [],
  subs: [],
  price: null,
};

/* eslint-disable default-case, no-param-reassign */
const employeeDistributionReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case SEARCH:
        draft.searchSubs = draft.subs.filter(
          item =>
            item.name
              .toLowerCase()
              .match(new RegExp(action.data.toLowerCase())) ||
            item.lname
              .toLowerCase()
              .match(new RegExp(action.data.toLowerCase())) ||
            item.code
              .toLowerCase()
              .match(new RegExp(action.data.toLowerCase())),
        );

        break;
      case GET_DATA:
        draft.load = 1;
        break;
      case GET_DATA_SUCCESS:
        console.log(action.data);
        draft.load = 0;
        draft.data = action.data;
        draft.date = action.data.date;
        draft.supply = Math.round(action.data.supply*100)/100;

        draft.price = action.data.config.subWage.value;
        break;
      case GET_DATA_ERROR:
        draft.load = 0;
        break;
      case GET_SUPPLY:
        draft.load = 1;
        break;
      case GET_SUPPLY_SUCCESS:
        draft.load = 0;
        draft.date = action.data.date;
        draft.supply = Math.round(action.data.data*100)/100;
        draft.price = action.data.config.subWage.value;

        break;
      case GET_SUPPLY_ERROR:
        draft.load = 0;
        break;
      case GET_SUBS:
        draft.load = 1;

        break;
      case GET_SUBS_SUCCESS:
        draft.load = 0;
        draft.subs = action.data.data;
        draft.searchSubs = action.data.data;
        break;
      case GET_SUBS_ERROR:
        draft.load = 0;
        break;
      case ADD_DATA:
        draft.load = 1;

        break;
      case ADD_DATA_SUCCESS:
        draft.load = 0;
        draft.date = action.data.date;
        draft.data.data = action.data.data;
        draft.supply = Math.round(action.data.supply*100)/100;
        break;
      case ADD_DATA_ERROR:
        draft.load = 0;
        break;
      case UPDATE_DATA:
        draft.load = 1;
        break;
      case UPDATE_DATA_SUCCESS:
        draft.load = 0;
        if(action.act=='update'){
          draft.data.data=action.data.data;
          draft.supply = Math.round(action.data.supply*100)/100;
        }
        if(action.act=='delete'){
          draft.data.data=action.data.data;
          draft.supply = Math.round(action.data.supply*100)/100;
        }
        break;
      case UPDATE_DATA_FAIL:
        draft.load = 0;
        break;
    }
  });

export default employeeDistributionReducer;
