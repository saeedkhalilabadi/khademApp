import { takeLatest, call, put, select } from 'redux-saga/effects';
import axios from '../axios/axios-user';
import { GET_DATA, ADD_DATA, GET_SUBS, GET_SUPPLY, UPDATE_DATA } from './constants';
import {
  getDataSuccess,
  getDataError,
  addDataError,
  addDataSuccess,
  getSubsError,
  getSubsSuccess,
  getSupplyError,
  getSupplySuccess,
  updateDataSuccess,
  updateDataFail
  
} from './actions';

// Individual exports for testing

function* getdata(params) {
  let data;
  let e = null;
  console.log(params,'saga params');
  yield axios
    .post('/api/distribution/getdata', params.data, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      // console.log(response.data, 'data');
      data = response.data;
      e = true;
    })
    .catch(error => {
      //console.log(error.response);
      data = error;
      e = false;
    });
  if (e) yield put(getDataSuccess(data));
  else yield put(getDataError(data));
}

function* getsupply(params) {
  let data;
  let e = null;
  console.log(params);
  yield axios
    .post('/api/distribution/supply', params.data, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      console.log(response.data, 'data');
      data = response.data;
      e = true;
    })
    .catch(error => {
      console.log(error.response);
      data = error;
      e = false;
    });
  if (e) yield put(getSupplySuccess(data));
  else yield put(getSupplyError(data));
}
function* adddata(params) {
  let data;
  let e = null;
  console.log(params.data, 'PARA');
  yield axios
    .post('api/distribution', params.data, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      console.log(response.data, 'data1');
      data = response.data;
      e = true;
    })
    .catch(error => {
      console.log(error.response);
      data = error;
      e = false;
    });
  if (e) yield put(addDataSuccess(data));
  else yield put(addDataError(data));
}
function* getsubs() {
  let data;
  let e = null;

  yield axios
    .get('api/subscriptions', {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      console.log(response.data, 'data');
      data = response.data;
      e = true;
    })
    .catch(error => {
      console.log(error.response);
      data = error;
      e = false;
    });
  if (e) yield put(getSubsSuccess(data));
  else yield put(getSubsError(data));
}

function* updateDataSaga(params) {
  let data;
  let e = null;
  switch (params.data.act) {
    case 'update':
      yield axios
      .put('api/distribution/'+params.data.data.id, params.data.data,{
        headers: JSON.parse(localStorage.getItem('userData')),
      })
      .then(response => {
        console.log(response.data, 'data saga');
        data = response.data;
        e = true;
      })
      .catch(error => {
        console.log(error.response);
        data = error;
        e = false;
      });
    if (e) yield put(updateDataSuccess(data,'update'));
    else yield put(updateDataFail(data,'update'));
      break;
      case 'delete':
        yield axios
        .delete('api/distribution/'+params.data.data.id,{
          headers: JSON.parse(localStorage.getItem('userData')),
        })
        .then(response => {
          console.log(response.data, 'data saga');
          data = response.data;
          e = true;
        })
        .catch(error => {
          console.log(error.response);
          data = error;
          e = false;
        });
      if (e) yield put(updateDataSuccess(data,'delete'));
      else yield put(updateDataFail(data,'delete'));
        break;
  
    default:
      break;
  }
 
}
// Individual exports for testing
export default function* employeeDistributionSaga() {
  yield takeLatest(GET_DATA, getdata);
  yield takeLatest(GET_SUPPLY, getsupply);

  yield takeLatest(ADD_DATA, adddata);
  yield takeLatest(GET_SUBS, getsubs);
  yield takeLatest(UPDATE_DATA, updateDataSaga);

  // See example in containers/HomePage/saga.js
}
