/**
 *
 * EmployeeDistribution
 *
 */

import React, { memo, useState } from 'react';
import PropTypes, { number } from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { Col, Row, Button, Form } from 'react-bootstrap';
import PhoneIcon from '@mui/icons-material/Phone';
import 'react-modern-calendar-datepicker/lib/DatePicker.css';
import NumberFormat from 'react-number-format';
import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import Loading from '../../components/Loading/Loadable';
import AddIcon from '@mui/icons-material/Add';
import Typography from '@mui/material/Typography';
import { Link } from 'react-router-dom';
import makeSelectEmployeeDistribution from './selectors';
import reducer from './reducer';
import saga from './saga';
import './index.css';
import '../../src/allStyles.css';
import { getData, addData, getSupply, updateData } from './actions';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
export function EmployeeDistribution({
  employeeDistribution,
  dispatch,
  props,
}) {
  useInjectReducer({ key: 'employeeDistribution', reducer });
  useInjectSaga({ key: 'employeeDistribution', saga });
  const [getdata, setgetdata] = useState(true);
  const [showItem, setshowItem] = useState(0);
  const [price, setprice] = useState(0);
  const [weight, setweight] = useState('');
  const [editDiv, setEditDiv] = useState(-1);
  const [deleteDiv, setDeleteDiv] = useState(-1);

  const [showDistrbutionOpen, setshowDistrbutionOpen] = useState('inDo');
  const [subscribe_id, setsubscribe_id] = useState(0);
  console.log(employeeDistribution, 'index');
  const words = {
    completed: 'تکمیل شده',
    nocompleted: 'تکمیل نشده',
    toman: 'تومان',
  };
  const date = {
    y: props.substate.location.state.date.slice(0, 4),
    m: props.substate.location.state.date.slice(5, 7),
    d: props.substate.location.state.date.slice(8, 10),
  };
  console.log(date);
  if (getdata)
    setTimeout(() => {
      setgetdata(false);
      dispatch(
        getData({
          subscribe_id: props.substate.location.state.id,
          status: 'inDo',
          date: 'date',
          start_y: date.y,
          start_m: date.m,
          start_d: date.d,
        }),
      );
    }, 100);

  const showSub =
    employeeDistribution && employeeDistribution.data ? (
      <Row className="form">
        <Col xs={12} sm={12} md={12} xl={12}>
          {employeeDistribution.data.sub.gender +
            ' ' +
            employeeDistribution.data.sub.name +
            ' ' +
            employeeDistribution.data.sub.lname}
        </Col>
        <Col xs={6} sm={6} md={6} xl={6} style={{ fontSize: '12px' }}>
          {'کد اشتراک : ' + employeeDistribution.data.sub.code}
        </Col>
        <Col xs={5} sm={5} md={5} xl={5} style={{ fontSize: '12px' }}>
          <a href={'tel:' + employeeDistribution.data.sub.mobile}>
            {employeeDistribution.data.sub.mobile}
            <PhoneIcon />
          </a>
        </Col>
      </Row>
    ) : null;

  const AddDistrbution =
    employeeDistribution.price == null ? null : (
      <Row className="form">
        <Col xs={6} sm={6} md={6} xl={6} className="fieldItem">
          {date.y + '/' + date.m + '/' + date.d}{' '}
        </Col>
        <Col
          xs={6}
          sm={6}
          md={6}
          xl={6}
          className="fieldItem"
          style={{ fontSize: '17px' }}
        >
          {' موجودی : ' + employeeDistribution.supply}
        </Col>

        <Col xs={12} sm={12} md={12} xl={12} className="fieldItem">
          <Form.Group className="mb-1" controlId="formBasicEmail">
            وزن :
            <Form.Control
              size="sm"
              isInvalid={weight > employeeDistribution.supply}
              value={weight}
              type="number"
              placeholder="وزن (کیلو)"
              style={{ maxWidth: '130px', display: 'inline' }}
              onChange={e => {
                setweight(e.target.value);
              }}
            />
            <Form.Control.Feedback type="invalid">
              مقدار وارد شده بیشتر از موجودی است
            </Form.Control.Feedback>
          </Form.Group>
        </Col>

        <Col xs={12} sm={12} md={12} xl={12} className="fieldItem">
          <Form.Group className="mb-1" controlId="formBasicEmail">
            <Form.Text className="text-muted">قیمت </Form.Text>

            <NumberFormat
              value={price == 0 ? Number(employeeDistribution.price) : price}
              onFocus={event => event.target.select()}
              style={{ height: '40px', fontSize: '20px' }}
              thousandSeparator={true}
              placeholder="قیمت "
              onValueChange={e => {
                setprice(e.value);
              }}
            />
          </Form.Group>
        </Col>
        <Col xs={6} sm={6} md={6} xl={6} className="fieldItem">
          <Button
            variant="warning"
            style={{ width: '100%', marginTop: '20px' }}
            disabled={weight > employeeDistribution.supply || weight <= 0}
            onClick={() => {
              dispatch(
                addData({
                  subscribe_id: employeeDistribution.data.sub.id,
                  flowerKg: weight,
                  price: price == 0 ? employeeDistribution.price : price,
                  date: 'date',
                  y: date.y,
                  m: date.m,
                  d: date.d,
                }),
              );
              setweight('');
            }}
          >
            ثبت
          </Button>
        </Col>
        <Col xs={6} sm={6} md={6} xl={6} className="fieldItem">
          <Link
            className="textIcons"
            to={{
              pathname: '/SelectSubDectrbution',
              state: { date: props.substate.location.state.date },
            }}
          >
            <Button
              variant="warning"
              style={{ width: '100%', marginTop: '20px' }}
            >
              بازگشت
            </Button>
          </Link>
        </Col>
      </Row>
    );
  const deleteDis =
    deleteDiv == -1 ? null : (
      <>
        <Row className="form">
          <Col xs={12} sm={12} md={12} xl={12}>
            <Typography align="center" variant="h5" component="h5" gutterBottom>
              فیلد حذف شود.
            </Typography>
          </Col>
          <Col xs={6} sm={6} md={6} xl={6} className="fieldItem">
            <Button
              variant="danger"
              style={{ width: '100%' }}
              size="sm"
              onClick={() => {
                dispatch(
                  updateData({
                    act: 'delete',
                    data: {
                      id: employeeDistribution.data.data[deleteDiv].id,
                    },
                  }),
                );
                setweight('');
                setprice('');
                setDeleteDiv(-1);
              }}
            >
              حذف
            </Button>
          </Col>
          <Col xs={6} sm={6} md={6} xl={6} className="fieldItem">
            <Button
              variant="warning"
              style={{ width: '100%' }}
              size="sm"
              onClick={() => {
                setDeleteDiv(-1);
              }}
            >
              بستن
            </Button>
          </Col>
        </Row>
      </>
    );
  const editSub =
    editDiv == -1 ? null : (
      <>
        <Row className="form">
          <Col
            xs={5}
            sm={5}
            md={5}
            xl={5}
            className="fieldItem"
            style={{ fontSize: '11px' }}
          >
            {' مقدار در دسترس : ' +
              (Number(employeeDistribution.supply) +
                Number(employeeDistribution.data.data[editDiv].flowerKg_kg))}
          </Col>

          <Col xs={12} sm={12} md={12} xl={12} className="fieldItem">
            <Form.Group className="mb-1" controlId="formBasicEmail">
              وزن :
              <Form.Control
                size="sm"
                isInvalid={
                  weight >
                  Number(employeeDistribution.supply) +
                    Number(employeeDistribution.data.data[editDiv].flowerKg_kg)
                }
                value={weight}
                type="number"
                placeholder="وزن (کیلو)"
                style={{ maxWidth: '130px', display: 'inline' }}
                onChange={e => {
                  setweight(e.target.value);
                }}
              />
              <Form.Control.Feedback type="invalid">
                مقدار وارد شده بیشتر از موجودی است
              </Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col xs={12} sm={12} md={12} xl={12} className="fieldItem">
            <Form.Group className="mb-1" controlId="formBasicEmail">
              <Form.Text className="text-muted">قیمت </Form.Text>

              <NumberFormat
                value={price}
                style={{ height: '40px', fontSize: '20px' }}
                thousandSeparator={true}
                placeholder="قیمت "
                onValueChange={e => {
                  setprice(e.value);
                  console.log(e.value, 'test');
                }}
              />
            </Form.Group>
          </Col>
          <Col xs={6} sm={6} md={6} xl={6} className="fieldItem">
            <Button
              variant="warning"
              style={{ width: '100%' }}
              size="sm"
              disabled={
                weight >
                  Number(employeeDistribution.supply) +
                    Number(
                      employeeDistribution.data.data[editDiv].flowerKg_kg,
                    ) || weight <= 0
              }
              onClick={() => {
                dispatch(
                  updateData({
                    act: 'update',
                    data: {
                      id: employeeDistribution.data.data[editDiv].id,
                      flowerKg: weight,
                      price: price,
                    },
                  }),
                );
                setEditDiv(-1);
                setweight('');
                setprice('');
              }}
            >
              ثبت
            </Button>
          </Col>
          <Col xs={6} sm={6} md={6} xl={6} className="fieldItem">
            <Button
              variant="warning"
              style={{ width: '100%' }}
              size="sm"
              onClick={() => {
                setweight('');
                setprice('');
                setEditDiv(-1);
              }}
            >
              بستن
            </Button>
          </Col>
        </Row>
      </>
    );

  const showInDoList =
    showDistrbutionOpen == 'inDo' ? (
      <Row>
        {employeeDistribution.data &&
          employeeDistribution.data.data.map((item, index) => (
            <Col
              key={item.id}
              className="distrbutionItems"
              xs={12}
              sm={12}
              md={12}
              xl={12}
              style={
                editDiv == index
                  ? { height: '237px' }
                  : deleteDiv == index
                  ? { height: '150px' }
                  : { height: 'auto' }
              }
            >
              <Row>
                <Col xs={4} sm={4} md={3} xl={3}>
                  {item.date_in_str.slice(0, 4) +
                    '/' +
                    item.date_in_str.slice(5, 7) +
                    '/' +
                    item.date_in_str.slice(8, 10)}
                </Col>
                <Col xs={4} sm={4} md={2} xl={2}>
                  گل:{item.flowerKg_kg + ' کیلو '}
                </Col>

                <Col xs={2} sm={2} md={1} xl={1}>
                  <EditIcon
                    sx={{ color: '#414dca' }}
                    style={{ cursor: 'pointer', fontSize: '1.3rem' }}
                    onClick={() => {
                      setEditDiv(index);
                      setweight(item.flowerKg_kg);
                      setprice(item.price);
                    }}
                  />
                </Col>
                <Col xs={2} sm={2} md={1} xl={1}>
                  <DeleteIcon
                    sx={{ color: '#ca7241' }}
                    style={{ cursor: 'pointer', fontSize: '1.3rem' }}
                    onClick={() => setDeleteDiv(index)}
                  />
                </Col>
              </Row>
              {editDiv == index ? (
                <Row className="editDiv">
                  <Col xs={12} sm={12} md={12} xl={12}>
                    {editSub}
                  </Col>
                </Row>
              ) : null}
              {deleteDiv == index ? (
                <Row className="editDiv">
                  <Col xs={12} sm={12} md={12} xl={12}>
                    {deleteDis}
                  </Col>
                </Row>
              ) : null}
            </Col>
          ))}
      </Row>
    ) : null;

  return (
    <div
      onKeyDown={e => {
        if (e.key === 'Enter') {
          const fields =
            Array.from(e.currentTarget.querySelectorAll('input')) || [];
          const position = fields.indexOf(
            e.target, // as HTMLInputElement (for TypeScript)
          );
          fields[position + 1] && fields[position + 1].focus();
        }
      }}
    >
      <Helmet>
        <title>توزیع</title>
        <meta
          name="description"
          content="Description of EmployeeDistribution"
        />
      </Helmet>
      {employeeDistribution.load == 1 ? <Loading /> : null}

      {showSub}

      {editDiv == -1 ? AddDistrbution : null}

      {showInDoList}
    </div>
  );
}

EmployeeDistribution.propTypes = {
  dispatch: PropTypes.func.isRequired,
  employeeDistribution: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  employeeDistribution: makeSelectEmployeeDistribution(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(EmployeeDistribution);
