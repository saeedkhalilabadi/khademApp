/**
 *
 * Asynchronously loads the component for SelectSubDectrbution
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
