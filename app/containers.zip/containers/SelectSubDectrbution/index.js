/**
 *
 * SelectSubDectrbution
 *
 */

import React, { memo, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { Link } from 'react-router-dom';
import { Row, Col, Form, Button } from 'react-bootstrap';
import IconButton from '@mui/material/IconButton';
import Paper from '@mui/material/Paper';
import InputBase from '@mui/material/InputBase';
import SearchIcon from '@mui/icons-material/Search';

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectSelectSubDectrbution from './selectors';
import reducer from './reducer';
import saga from './saga';
import { getData, search } from './actions';
import messages from './messages';
import './index.css';
import '../../src/allStyles.css';

export function SelectSubDectrbution({
  selectSubDectrbution,
  dispatch,
  props,
}) {
  useInjectReducer({ key: 'selectSubDectrbution', reducer });
  useInjectSaga({ key: 'selectSubDectrbution', saga });
  const [getdata, setgetdata] = useState(true);
  const date = {
    y: props.substate.location.state.date.slice(0, 4),
    m: props.substate.location.state.date.slice(5, 7),
    d: props.substate.location.state.date.slice(8, 10),
  };
  console.log(date);
  if (getdata)
    setTimeout(() => {
      setgetdata(false);
      dispatch(getData(date));
    }, 50);

  const showList = (
    <Row>
      <Col className="title" xs={12} sm={12} md={12} xl={12}>
        توزیع
      </Col>
      <Col xs={6} sm={6} md={6} xl={6}>
        <Paper
          component="form"
          sx={{
            direction: 'rtl',
            margin: 'auto',
            marginTop: '10px',
            marginBottom: '10px',
            p: '2px 4px',
            display: 'flex',
            alignItems: 'center',
            width: '100%',
          }}
        >
          <InputBase
            sx={{ ml: 1, flex: 1 }}
            type="text"
            placeholder="نام و نام خانوادگی "
            inputProps={{ 'aria-label': 'جستجو' }}
            onChange={e => dispatch(search({ word: e.target.value }))}
          />

          <SearchIcon />
        </Paper>
      </Col>
      <Col xs={6} sm={6} md={6} xl={6}>
        <Paper
          component="form"
          sx={{
            direction: 'rtl',
            margin: 'auto',
            marginTop: '10px',
            marginBottom: '10px',
            p: '2px 4px',
            display: 'flex',
            alignItems: 'center',
            width: '100%',
          }}
        >
          <InputBase
            sx={{ ml: 1, flex: 1 }}
            type="number"
            placeholder="کد اشتراک"
            inputProps={{ 'aria-label': 'جستجو' }}
            onChange={e => dispatch(search({ word: e.target.value }))}
          />

          <SearchIcon />
        </Paper>
      </Col>

      {selectSubDectrbution.searchSubs.length == 0 ? (
        <p style={{ textAlign: 'center' }}>مشترکی پیدا نشد</p>
      ) : (
        <>
          {selectSubDectrbution.searchSubs.map(sub => (
            <Col className="subItems" key={sub.id}>
              <Link
                className="textIcons"
                to={{
                  pathname: '/Distribution',
                  state: {
                    id: sub.id,
                    date: props.substate.location.state.date,
                  },
                }}
              >
                <Row>
                  <Col xs={12} sm={12} md={12} xl={12}>
                    {sub.code}
                  </Col>
                  <Col xs={12} sm={12} md={12} xl={12}>
                    {sub.gender + ' ' + sub.name + ' ' + sub.lname}
                  </Col>
                  <Col xs={12} sm={12} md={12} xl={12}>
                    {sub.score}
                  </Col>
                </Row>
              </Link>
            </Col>
          ))}
        </>
      )}
    </Row>
  );

  return (
    <div>
      <Helmet>
        <title>انتخاب مشترک</title>
      </Helmet>
      {showList}
    </div>
  );
}

SelectSubDectrbution.propTypes = {
  dispatch: PropTypes.func.isRequired,
  selectSubDectrbution: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  selectSubDectrbution: makeSelectSelectSubDectrbution(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(SelectSubDectrbution);
