import { takeLatest, call, put, select } from 'redux-saga/effects';
import axios from '../axios/axios-user';
import { GET_DATA,SEARCH } from './constants';
import { getDataSuccess, getDataError, searchSuccess,searchFail } from './actions';

function* getdata(params) {
  let data;
  let e = null;
  console.log(params);
  yield axios
    .post('api/subscriptions/flower',params.data, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      console.log(response.data, 'data');
      data = response.data;
      e = true;
    })
    .catch(error => {
      console.log(error.response);
      data = error;
      e = false;
    });
  if (e) yield put(getDataSuccess(data));
  else yield put(getDataError(data));
}
function* search1(params) {
  let data;
  let e = null;
  console.log(params.data);

  yield axios
    .post('api/getdata', params.data, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      console.log(response.data, 'data');
      data = response.data;
      e = true;
    })
    .catch(error => {
      console.log(error.response);
      data = error;
      e = false;
    });
  if (e) yield put(searchSuccess(data));
  else yield put(searchFail(data));
}
// Individual exports for testing
export default function* selectSubDectrbutionSaga() {
  yield takeLatest(GET_DATA, getdata);
  yield takeLatest(SEARCH, search1);
  // See example in containers/HomePage/saga.js
}
