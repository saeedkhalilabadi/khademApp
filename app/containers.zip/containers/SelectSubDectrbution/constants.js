/*
 *
 * SelectSubDectrbution constants
 *
 */
export const SEARCH = 'app/SelectSubDectrbution/SEARCH';
export const SEARCH_SUCCESS = 'app/SelectSubDectrbution/SEARCH_SUCCESS';
export const SEARCH_FAIL = 'app/SelectSubDectrbution/SEARCH_FAIL';

export const GET_DATA = 'app/SelectSubDectrbution/GET_DATA';
export const GET_DATA_SUCCESS = 'app/SelectSubDectrbution/GET_DATA_SUCCESS';
export const GET_DATA_ERROR = 'app/SelectSubDectrbution/GET_DATA_ERROR';
