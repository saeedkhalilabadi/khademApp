import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the selectSubDectrbution state domain
 */

const selectSelectSubDectrbutionDomain = state =>
  state.selectSubDectrbution || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by SelectSubDectrbution
 */

const makeSelectSelectSubDectrbution = () =>
  createSelector(
    selectSelectSubDectrbutionDomain,
    substate => substate,
  );

export default makeSelectSelectSubDectrbution;
export { selectSelectSubDectrbutionDomain };
