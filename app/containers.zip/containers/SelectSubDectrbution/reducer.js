/*
 *
 * SelectSubDectrbution reducer
 *
 */
import produce from 'immer';
import {
  GET_DATA,
  GET_DATA_ERROR,
  GET_DATA_SUCCESS,
  SEARCH,
  SEARCH_SUCCESS,
  SEARCH_FAIL,
} from './constants';

export const initialState = {
  data: [],
  searchSubs: [],
};

/* eslint-disable default-case, no-param-reassign */
const selectSubDectrbutionReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case SEARCH:
        break;

      case SEARCH_SUCCESS:
        draft.data = action.data.subs;
        draft.searchSubs = action.data.subs;

        break;
      case SEARCH_FAIL:
        break;
      case GET_DATA:
        draft.load = 1;
        break;
      case GET_DATA_SUCCESS:
        draft.load = 0;
        draft.data = action.data.data;
        draft.searchSubs = action.data.data;

        break;
      case GET_DATA_ERROR:
        break;
    }
  });

export default selectSubDectrbutionReducer;
