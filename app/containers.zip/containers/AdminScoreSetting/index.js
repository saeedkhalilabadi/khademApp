/**
 *
 * AdminScoreSetting
 *
 */

import React, { memo, useState } from 'react';
import PropTypes, { object } from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import NumberFormat from 'react-number-format';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { Col, Row, Form, Button } from 'react-bootstrap';
import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectAdminScoreSetting from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import { getData, setData } from './actions';
import '../../src/allStyles.css';
import './index.css';

export function AdminScoreSetting({ adminScoreSetting, props, dispatch }) {
  useInjectReducer({ key: 'adminScoreSetting', reducer });
  useInjectSaga({ key: 'adminScoreSetting', saga });
  const [getdata, setgetdata] = useState(true);
  const [selectedId, setselectedId] = useState(0);
  const [value, setvalue] = useState(0);

  if (getdata)
    setTimeout(() => {
      setgetdata(false);
      dispatch(getData());
    }, 100);

  const title = (
    <Row>
      <Col className="title">امتیاز ها</Col>
    </Row>
  );
  const showSetting = (
    <Row>
      {Object.keys(adminScoreSetting.data).map(item => (
        <Col xs={12} sm={12} md={12} xl={12} className="setting">
          <Row className="settingItems">
            <Col xs={5} sm={5} md={5} xl={5}>
              {adminScoreSetting.data[item].name}
            </Col>
            {item == selectedId ? (
              <Col xs={7} sm={7} md={7} xl={7}>
                <NumberFormat
                  style={{ maxWidth: "80px", marginLeft: '5px' }}
                  defaultValue={adminScoreSetting.data[item].value}
                  thousandSeparator={true}
                  onValueChange={e => setvalue(e.value)}
                />
                <Button
                  variant="warning"
                  size="sm"
                  disabled={value <= 0}
                  onClick={() => {
                    dispatch(
                      setData({
                        key: adminScoreSetting.data[item].key,
                        value,
                      }),
                    );
                    setselectedId(0);
                  }}
                >
                  ثبت
                </Button>
                <Button
                  variant="warning"
                  size="sm"
                  className="mx-2"
                  onClick={() => {
                   
                    setselectedId(0);
                  }}
                >
                  انصراف
                </Button>
              </Col>
            ) : (
              <Col xs={7} sm={7} md={7} xl={7}>
                <Row>
                  <Col>
                    <NumberFormat
                      value={adminScoreSetting.data[item].value}
                      displayType={'text'}
                      thousandSeparator={true}
                      renderText={value => <div>{value}</div>}
                    />
                  </Col>
                  <Col>
                    <Button
                      variant="warning"
                      size="sm"
                      onClick={() => setselectedId(item)}
                    >
                      ویرایش
                    </Button>
                  </Col>
                </Row>
              </Col>
            )}
          </Row>
        </Col>
      ))}
    </Row>
  );
  return (
    <div>
      <Helmet>
        <title>تنظیمات امتیازات</title>
        <meta name="description" content="Description of AdminScoreSetting" />
      </Helmet>
      {title}

      {showSetting}
    </div>
  );
}

AdminScoreSetting.propTypes = {
  dispatch: PropTypes.func.isRequired,
  adminScoreSetting: PropTypes.object.isRequired
};

const mapStateToProps = createStructuredSelector({
  adminScoreSetting: makeSelectAdminScoreSetting(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(AdminScoreSetting);
