import axios from 'containers/axios/axios-user';
import { takeLatest, call, put, select } from 'redux-saga/effects';
import { GET_DATA, SET_DATA } from './constants';
import {
  getDataSuccess,
  getDataError,
  setDataError,
  setDataSuccess,
} from './actions';

export function* getdata() {
  let data;
  let e = null;
  //console.log(params);
  yield axios
    .get('api/scoreconfigs', {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      console.log(response.data, 'employees1');
      data = response.data;
      e = true;
    })
    .catch(error => {
      console.log(error.response);
      data = error.response;
      e = false;
    });
  if (e) yield put(getDataSuccess(data));
  else yield put(getDataError(data));
}
export function* setdata(params) {
  let data;
  let e = null;
  console.log(params);

  yield axios
    .put('api/scoreconfigs/' + params.data.key, params.data, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      console.log(response.data, 'employees1');
      data = response.data;
      e = true;
    })
    .catch(error => {
      console.log(error.response);
      data = error.response;
      e = false;
    });
  if (e) yield put(setDataSuccess(data));
  else yield put(setDataError(data));
}
// Individual exports for testing
export default function* adminScoreSettingSaga() {
  yield takeLatest(GET_DATA, getdata);
  yield takeLatest(SET_DATA, setdata);

  // See example in containers/HomePage/saga.js
}
