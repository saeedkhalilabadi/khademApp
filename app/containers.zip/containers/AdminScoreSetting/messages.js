/*
 * AdminScoreSetting Messages
 *
 * This contains all the text for the AdminScoreSetting container.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.containers.AdminScoreSetting';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the AdminScoreSetting container!',
  },
});
