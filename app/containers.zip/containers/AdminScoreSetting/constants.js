/*
 *
 * AdminScoreSetting constants
 *
 */

export const GET_DATA = 'app/AdminScoreSetting/GET_DATA';
export const GET_DATA_SUCCESS = 'app/AdminScoreSetting/GET_DATA_SUCCESS';
export const GET_DATA_ERROR = 'app/AdminScoreSetting/GET_DATA_ERROR';

export const SET_DATA = 'app/AdminScoreSetting/SET_DATA';
export const SET_DATA_SUCCESS = 'app/AdminScoreSetting/SET_DATA_SUCCESS';
export const SET_DATA_ERROR = 'app/AdminScoreSetting/SET_DATA_ERROR'; 