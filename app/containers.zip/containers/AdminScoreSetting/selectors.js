import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the adminScoreSetting state domain
 */

const selectAdminScoreSettingDomain = state =>
  state.adminScoreSetting || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by AdminScoreSetting
 */

const makeSelectAdminScoreSetting = () =>
  createSelector(
    selectAdminScoreSettingDomain,
    substate => substate,
  );

export default makeSelectAdminScoreSetting;
export { selectAdminScoreSettingDomain };
