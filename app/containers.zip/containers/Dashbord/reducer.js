/*
 *
 * Dashbord reducer
 *
 */
import produce from 'immer';
import { GET_DATA, GET_DATA_ERROR, GET_DATA_SUCCESS } from './constants';

export const initialState = {
  data: [],
};

/* eslint-disable default-case, no-param-reassign */
const dashbordReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case GET_DATA:
        break;
      case GET_DATA_SUCCESS:
        draft.data = action.data.data;
        break;
      case GET_DATA_ERROR:
        break;
    }
  });

export default dashbordReducer;
