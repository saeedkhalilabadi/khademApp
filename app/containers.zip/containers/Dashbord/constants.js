/*
 *
 * Dashbord constants
 *
 */

export const GET_DATA = 'app/Dashbord/GET_DATA';
export const GET_DATA_SUCCESS = 'app/Dashbord/GET_DATA_SUCCESS';
export const GET_DATA_ERROR = 'app/Dashbord/GET_DATA_ERROR';
