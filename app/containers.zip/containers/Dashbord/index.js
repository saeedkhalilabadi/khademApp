/**
 *
 * Dashbord
 *
 */

import React, { memo, useState } from 'react';
import PropTypes from 'prop-types';

import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { Col, Row } from 'react-bootstrap';
import DoneAllIcon from '@mui/icons-material/DoneAll';
import EventNoteIcon from '@mui/icons-material/EventNote';
import EventAvailableIcon from '@mui/icons-material/EventAvailable';
import TimerIcon from '@mui/icons-material/Timer';
import GroupIcon from '@mui/icons-material/Group';
import LocalFloristIcon from '@mui/icons-material/LocalFlorist';
import ContentPasteIcon from '@mui/icons-material/ContentPaste';
import GroupsIcon from '@mui/icons-material/Groups';
import LocalAtmIcon from '@mui/icons-material/LocalAtm';
import SettingsIcon from '@mui/icons-material/Settings';
import LayersIcon from '@mui/icons-material/Layers';
import CreditCardIcon from '@mui/icons-material/CreditCard';
import ShowChartIcon from '@mui/icons-material/ShowChart';

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectDashbord from './selectors';
import { getDashboard } from '../AdminMenu/actions';
import reducer from './reducer';
import saga from './saga';
import './index.css';
export function Dashbord({ dashbord, props, dispatch }) {
  useInjectReducer({ key: 'dashbord', reducer });
  useInjectSaga({ key: 'dashbord', saga });

  const [getdata, setgetdata] = useState(true);

  if (getdata)
    setTimeout(() => {
      setgetdata(false);
      dispatch(getDashboard());
    }, 200);

  // console.log(dashbord, props, 'props');

  const desk = (
    <Row className="justify-content-center">
      <Col className="jobsIcons" xs={3} sm={3} md={3} xl={3}>
        <Link to="/employees" className="textIcons">
          <Row>
            <Col xs={12} sm={12} md={12} xl={12}>
              <GroupIcon
                className="icons"
                style={{
                  color: '#0f9d58',
                  background: 'rgba(15, 157, 88, 0.11)',
                }}
              />
            </Col>
            <Col xs={12} sm={12} md={12} xl={12} style={{ fontWeight: 'bold' }}>
              شعبه ها
            </Col>
            <Col
              xs={12}
              sm={12}
              md={12}
              xl={12}
              className="numbersIcons"
              style={{
                color: '#0f9d58',
              }}
            />
          </Row>
        </Link>
      </Col>

      <Col className="jobsIcons" xs={3} sm={3} md={3} xl={3}>
        <Link to="/WetHeadRegister" className="textIcons">
          <Row>
            <Col xs={12} sm={12} md={12} xl={12}>
              <LocalFloristIcon
                className="icons"
                style={{
                  color: '#ff8561',
                  background: 'rgba(255, 133, 97, 0.11)',
                }}
              />
            </Col>

            <Col xs={12} sm={12} md={12} xl={12}>
              ثبت سرگل خشک
            </Col>
            <Col
              xs={12}
              sm={12}
              md={12}
              xl={12}
              className="numbersIcons"
              style={{
                color: '#ff8561',
              }}
            />
          </Row>
        </Link>
      </Col>
      <Col className="jobsIcons" xs={3} sm={3} md={3} xl={3}>
        <Link to="/BrancheDistributionReport" className="textIcons">
          <Row>
            <Col xs={12} sm={12} md={12} xl={12}>
              <ContentPasteIcon
                className="icons"
                style={{
                  color: '#9c27b0',
                  background: 'rgba(156, 39, 176, 0.11)',
                }}
              />
            </Col>

            <Col xs={12} sm={12} md={12} xl={12}>
              {' '}
              گزارش توزیع
            </Col>
            <Col
              xs={12}
              sm={12}
              md={12}
              xl={12}
              className="numbersIcons"
              style={{
                color: '#9c27b0',
              }}
            />
          </Row>
        </Link>
      </Col>
      <Col className="jobsIcons" xs={3} sm={3} md={3} xl={3}>
        <Link to="/BrancheDistributionReport" className="textIcons">
          <Row>
            <Col xs={12} sm={12} md={12} xl={12}>
              <LocalAtmIcon
                className="icons"
                style={{
                  color: '#9c27b0',
                  background: 'rgba(156, 39, 176, 0.11)',
                }}
              />
            </Col>

            <Col xs={12} sm={12} md={12} xl={12}>
              {' '}
              گزارش مالی شعبه
            </Col>
            <Col
              xs={12}
              sm={12}
              md={12}
              xl={12}
              className="numbersIcons"
              style={{
                color: '#9c27b0',
              }}
            />
          </Row>
        </Link>
      </Col>
      <Col className="jobsIcons" xs={3} sm={3} md={3} xl={3}>
        <Row>
          <Col xs={12} sm={12} md={12} xl={12}>
            <GroupsIcon
              className="icons"
              style={{
                color: '#4287f4',
                background: 'rgba(66, 135, 244, 0.11)',
              }}
            />
          </Col>

          <Col xs={12} sm={12} md={12} xl={12}>
            {' '}
            مشترکین شعبه
          </Col>
          <Col
            xs={12}
            sm={12}
            md={12}
            xl={12}
            className="numbersIcons"
            style={{
              color: '#4287f4',
            }}
          />
        </Row>
      </Col>
      <Col className="jobsIcons" xs={3} sm={3} md={3} xl={3}>
        <Link to="/BagRegister" className="textIcons">
          <Row>
            <Col xs={12} sm={12} md={12} xl={12}>
              <LayersIcon
                className="icons"
                style={{
                  color: '#4287f4',
                  background: 'rgba(66, 135, 244, 0.11)',
                }}
              />
            </Col>

            <Col xs={12} sm={12} md={12} xl={12}>
              {' '}
              ثبت کیسه ها
            </Col>
            <Col
              xs={12}
              sm={12}
              md={12}
              xl={12}
              className="numbersIcons"
              style={{
                color: '#4287f4',
              }}
            />
          </Row>
        </Link>
      </Col>
      <Col className="jobsIcons" xs={3} sm={3} md={3} xl={3}>
        <Link to="/PaymentRegistr" className="textIcons">
          <Row>
            <Col xs={12} sm={12} md={12} xl={12}>
              <CreditCardIcon
                className="icons"
                style={{
                  color: '#4287f4',
                  background: 'rgba(66, 135, 244, 0.11)',
                }}
              />
            </Col>

            <Col xs={12} sm={12} md={12} xl={12}>
              {' '}
              ثبت پرداخت
            </Col>
            <Col
              xs={12}
              sm={12}
              md={12}
              xl={12}
              className="numbersIcons"
              style={{
                color: '#4287f4',
              }}
            />
          </Row>
        </Link>
      </Col>
      <Col className="jobsIcons" xs={3} sm={3} md={3} xl={3}>
      <Link to="/BranchAnalyticalReport" className="textIcons">
        <Row>
          <Col xs={12} sm={12} md={12} xl={12}>
            <ShowChartIcon
              className="icons"
              style={{
                color: '#4287f4',
                background: 'rgba(66, 135, 244, 0.11)',
              }}
            />
          </Col>

          <Col xs={12} sm={12} md={12} xl={12}>
            {' '}
            گزارش تحلیلی شعب
          </Col>
          <Col
            xs={12}
            sm={12}
            md={12}
            xl={12}
            className="numbersIcons"
            style={{
              color: '#4287f4',
            }}
          />
        </Row>
        </Link>
      </Col>
      <Col className="jobsIcons" xs={3} sm={3} md={3} xl={3}>
        <Link to="/AdminSetting" className="textIcons">
          <Row>
            <Col xs={12} sm={12} md={12} xl={12}>
              <SettingsIcon
                className="icons"
                style={{
                  color: '#4287f4',
                  background: 'rgba(66, 135, 244, 0.11)',
                }}
              />
            </Col>

            <Col xs={12} sm={12} md={12} xl={12}>
              {' '}
              ثبت قیمت ها
            </Col>
            <Col
              xs={12}
              sm={12}
              md={12}
              xl={12}
              className="numbersIcons"
              style={{
                color: '#4287f4',
              }}
            />
          </Row>
        </Link>
      </Col>
    </Row>
  );

  const myJobs = (
    <Row
      style={{
        border: '1px solid #e1e1e1',
        backgroundColor: 'rgba(255, 255, 255, 0.86)',
        borderRadius: '15px',
      }}
    >
      <Col
        xs={12}
        sm={12}
        md={12}
        xl={12}
        style={{
          background: '#4CAF50',
          color: '#ffffff',
          fontWeight: ' bold',
          padding: '5px',
          textAlign: 'center',
        }}
      >
        کار های من
      </Col>
      <Col xs={12} sm={12} md={12} xl={12}>
        1
      </Col>
      <Col xs={12} sm={12} md={12} xl={12}>
        1
      </Col>
    </Row>
  );
  const otherJobs = (
    <Row
      style={{
        border: '1px solid #e1e1e1',
        backgroundColor: 'rgba(255, 255, 255, 0.86)',
        borderRadius: '15px',
      }}
    >
      <Col
        xs={12}
        sm={12}
        md={12}
        xl={12}
        style={{
          background: '#db4c3f',
          color: '#ffffff',
          fontWeight: ' bold',
          padding: '5px',
          textAlign: 'center',
        }}
      >
        پیگیری از دیگران
      </Col>
      <Col xs={12} sm={12} md={12} xl={12}>
        1
      </Col>
      <Col xs={12} sm={12} md={12} xl={12}>
        1
      </Col>
    </Row>
  );

  return (
    <div
      className={
        props.screen.width > 1000
          ? 'mainBodyDashbord'
          : 'mainBodyDashbordMobile'
      }
    >
      <Helmet>
        <title>داشبورد</title>
        <meta name="description" content="Description of Dashbord" />
      </Helmet>

      {desk}
    </div>
  );
}

Dashbord.propTypes = {
  dispatch: PropTypes.func.isRequired,
  dashbord: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  dashbord: makeSelectDashbord(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(Dashbord);
