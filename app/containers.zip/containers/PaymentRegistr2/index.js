/**
 *
 * PaymentRegistr2
 *
 */

import React, { memo, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { Link } from 'react-router-dom';
import { Form, Row, Col, Button } from 'react-bootstrap';
import NumberFormat from 'react-number-format';
import 'react-modern-calendar-datepicker/lib/DatePicker.css';
import DatePicker from 'react-modern-calendar-datepicker';

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectPaymentRegistr2 from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import { getData, addData, setValue } from './actions';
import './index.css';
import '../../src/allStyles.css';

export function PaymentRegistr2({ paymentRegistr2, dispatch, props }) {
  useInjectReducer({ key: 'paymentRegistr2', reducer });
  useInjectSaga({ key: 'paymentRegistr2', saga });
  const [getdata, setgetdata] = useState(true);

  
  console.log(paymentRegistr2);
  if (getdata)
    setTimeout(() => {
      setgetdata(false);

      dispatch(
        setValue({
          subject: 'recipient',
          value: props.substate.location.state.id,
        }),
      );
      if (props.substate.location.state.subject == 'sub') {
        dispatch(setValue({ subject: 'recipientSubject', value: 'sub' }));
        dispatch(getData({ sub_id: props.substate.location.state.id }));
      }

      if (props.substate.location.state.subject == 'branche') {
        dispatch(setValue({ subject: 'recipientSubject', value: 'branche' }));
        dispatch(getData({ branche_id: props.substate.location.state.id }));
      }
    }, 100);

  const info = (
    <Row className="form">
      {paymentRegistr2.user ? (
        <Col>
          {paymentRegistr2.user.gender +
            ' ' +
            paymentRegistr2.user.name +
            ' ' +
            paymentRegistr2.user.lname}
        </Col>
      ) : null}

      <Col>
        <NumberFormat
          value={paymentRegistr2.financialAccountStatus.price}
          displayType={'text'}
          thousandSeparator={true}
          renderText={value => (
            <div>
              {value + ' ' + paymentRegistr2.financialAccountStatus.status}
            </div>
          )}
        />
      </Col>
    </Row>
  );

  const getDataForm = (
    <Row className="form">
      <Col xs={6} sm={6} md={6} xl={6} className="filde">
        <Form.Group className="mb-1" controlId="formBasicEmail">
          <Form.Text className="text-muted">نحوه پرداخت</Form.Text>
          <Form.Control
            as="select"
            size="sm"
            value={paymentRegistr2.newData.typeOfPayment}
            custom
            style={{ maxWidth: '170px' }}
            onChange={e => {
              dispatch(
                setValue({ subject: 'typeOfPayment', value: e.target.value }),
              );
            }}
          >
            <option value="واریز">واریز به حساب</option>
            <option value="نقدی">نقدی</option>
            <option value="چک">چک </option>
          </Form.Control>
        </Form.Group>
      </Col>
      <Col xs={6} sm={6} md={6} xl={6} className="filde">
        <Form.Group className="mb-1" controlId="formBasicEmail">
          <Form.Text className="text-muted">تاریخ</Form.Text>
          <DatePicker
            value={{
              month: paymentRegistr2.newData.m,
              day: paymentRegistr2.newData.d,
              year: paymentRegistr2.newData.y,
            }}
            onChange={e =>
              dispatch(
                setValue({
                  subject: 'date',
                  date: 'date',
                  m: e.month,
                  y: e.year,
                  d: e.day,
                }),
              )
            }
            shouldHighlightWeekends
            locale="fa" // add this
          />
        </Form.Group>
      </Col>

      <Col xs={12} sm={12} md={6} xl={6} className="filde">
        <Form.Group className="mb-1" controlId="formBasicEmail">
          <Form.Text className="text-muted">مبلغ</Form.Text>

          <NumberFormat
            placeholder="مبلغ"
            thousandSeparator={true}
            value={paymentRegistr2.newData.price}
            style={{
              direction: 'ltr',
              width: '100%',
              height: '40px',
              fontSize: '20px',
            }}
            onValueChange={e => {
              dispatch(setValue({ subject: 'price', value: e.value }));
            }}
          />
        </Form.Group>
      </Col>

      <Col xs={12} sm={12} md={6} xl={6} className="filde">
        <Form.Group className="mb-1" controlId="formBasicEmail">
          <Form.Text className="text-muted">کد پیگیری</Form.Text>

          <Form.Control
            size="sm"
            type="number"
            placeholder="کد پیگیری"
            value={paymentRegistr2.newData.trackingCode}
            onChange={e => {
              dispatch(
                setValue({ subject: 'trackingCode', value: e.target.value }),
              );
            }}
          />
        </Form.Group>
      </Col>

      <Col xs={12} sm={12} md={6} xl={6} className="filde">
        <Form.Group className="mb-1" controlId="formBasicEmail">
          <Form.Text className="text-muted">توضیحات</Form.Text>

          <Form.Control
            size="sm"
            type="text"
            value={paymentRegistr2.newData.desc}
            placeholder="توضیحات"
            onChange={e => {
              dispatch(setValue({ subject: 'desc', value: e.target.value }));
            }}
          />
        </Form.Group>
      </Col>

      <Col xs={12} sm={12} md={6} xl={6} className="filde">
        <Button
          style={{ margin: 'auto', marginTop: '30px', minWidth: '100%' }}
          variant="warning"
          size="sm"
          onClick={() => dispatch(addData(paymentRegistr2.newData))}
        >
          ثبت{' '}
        </Button>
      </Col>
    </Row>
  );

  const paymentList = (
    <Row>
      {paymentRegistr2.payments
        ? paymentRegistr2.payments.map(item => (
            <Col xs={12} sm={12} md={12} xl={12}>
              <Row className="showPaymentsItem">
                <Col xs={4} sm={4} md={4} xl={4}>
                  {item.date_str.slice(0, 4) +
                    '/' +
                    item.date_str.slice(5, 7) +
                    '/' +
                    item.date_str.slice(8, 10)}
                </Col>
                <Col xs={3} sm={3} md={3} xl={3}>
                  {item.typeOfPayment}
                </Col>
                <Col xs={5} sm={5} md={5} xl={5}>
                  <NumberFormat
                    value={item.price}
                    displayType={'text'}
                    thousandSeparator={true}
                    renderText={value => <div>{value}</div>}
                  />
                </Col>
              </Row>
            </Col>
          ))
        : null}
    </Row>
  );

  return (
    <div
      onKeyDown={e => {
        if (e.key === 'Enter') {
          const fields =
            Array.from(e.currentTarget.querySelectorAll('input')) || [];
          const position = fields.indexOf(
            e.target, // as HTMLInputElement (for TypeScript)
          );
          fields[position + 1] && fields[position + 1].focus();
        }
      }}
    >
      <Helmet>
        <title>ثبت پرداختی</title>
      </Helmet>
      <Col className=" title" xs={12} sm={12} md={12} xl={12}>
        {' '}
        ثبت پرداختی
      </Col>
      {info}
      {getDataForm}
      {paymentList}
    </div>
  );
}

PaymentRegistr2.propTypes = {
  dispatch: PropTypes.func.isRequired,
  paymentRegistr2: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  paymentRegistr2: makeSelectPaymentRegistr2(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(PaymentRegistr2);
