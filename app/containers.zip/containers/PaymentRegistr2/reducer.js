/*
 *
 * PaymentRegistr2 reducer
 *
 */
import produce from 'immer';
import {
  GET_DATA,
  GET_DATA_ERROR,
  GET_DATA_SUCCESS,
  ADD_DATA,
  ADD_DATA_ERROR,
  ADD_DATA_SUCCESS,
  SET_VALUE,
} from './constants';

export const initialState = {
  data: [],
  user: null,
  payments: [],
  financialAccountStatus: {
    price: 0,
    status: '',
  },
  newData: {
    recipient: '',
    recipientSubject: '',
    price: '',
    typeOfPayment: 'واریز',
    typeOfTransaction: 'حق الزحمه',
    trackingCode: '',
    date: 'date',
    y: '',
    m: '',
    d: '',
    desc: '',
  },
};


/* eslint-disable default-case, no-param-reassign */
const paymentRegistr2Reducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case SET_VALUE:
        action.data.subject == 'recipient'
          ? (draft.newData.recipient = action.data.value)
          : null;
        action.data.subject == 'recipientSubject'
          ? (draft.newData.recipientSubject = action.data.value)
          : null;
        action.data.subject == 'price'
          ? (draft.newData.price = action.data.value)
          : null;
        action.data.subject == 'typeOfPayment'
          ? (draft.newData.typeOfPayment = action.data.value)
          : null;
        action.data.subject == 'typeOfTransaction'
          ? (draft.newData.typeOfTransaction = action.data.value)
          : null;
        action.data.subject == 'trackingCode'
          ? (draft.newData.trackingCode = action.data.value)
          : null;
        action.data.subject == 'desc'
          ? (draft.newData.desc = action.data.value)
          : null;
        if (action.data.subject == 'date') {
          draft.newData.date = action.data.date;
          draft.newData.m = action.data.m;
          draft.newData.y = action.data.y;
          draft.newData.d = action.data.d;
        }
        break;
      case GET_DATA:
        break;
      case GET_DATA_SUCCESS:
        draft.newData.m = action.data.date.m;
        draft.newData.y = action.data.date.y;
        draft.newData.d = action.data.date.d;
        draft.financialAccountStatus = action.data.financialAccountStatus;
        draft.user = action.data.data.user;
        draft.payments = action.data.data.payments;
        break;
      case GET_DATA_ERROR:
        break;
      case ADD_DATA:
        break;
      case ADD_DATA_SUCCESS:
        draft.financialAccountStatus = action.data.financialAccountStatus;
        draft.payments = action.data.data;
        draft.newData.price = '';
        draft.newData.trackingCode = '';
        draft.newData.desc = '';
     

        break;
      case ADD_DATA_ERROR:
        break;
    }
  });

export default paymentRegistr2Reducer;
