import { takeLatest, call, put, select } from 'redux-saga/effects';
import axios from '../axios/axios-user';
import { GET_DATA, ADD_DATA } from './constants';
import {
  getDataSuccess,
  getDataError,
  addDataError,
  addDataSuccess,
} from './actions';

function* getdata(params) {
  let data;
  let e = null;
  console.log(params.data);
  yield axios
    .post('api/paymants/getpays', params.data, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      console.log(response.data, 'data');
      data = response.data;
      e = true;
    })
    .catch(error => {
      console.log(error.response);
      data = error;
      e = false;
    });
  if (e) yield put(getDataSuccess(data));
  else yield put(getDataError(data));
}
function* adddata(params) {
  let data;
  let e = null;
  console.log(params.data);
  yield axios
    .post('api/paymants', params.data, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      console.log(response.data, 'data');
      data = response.data;
      e = true;
    })
    .catch(error => {
      console.log(error.response);
      data = error;
      e = false;
    });
  if (e) yield put(addDataSuccess(data));
  else yield put(addDataError(data));
}

// Individual exports for testing
export default function* paymentRegistr2Saga() {
  yield takeLatest(GET_DATA, getdata);
  yield takeLatest(ADD_DATA, adddata);

  // See example in containers/HomePage/saga.js
}
