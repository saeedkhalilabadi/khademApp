import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the paymentRegistr2 state domain
 */

const selectPaymentRegistr2Domain = state =>
  state.paymentRegistr2 || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by PaymentRegistr2
 */

const makeSelectPaymentRegistr2 = () =>
  createSelector(
    selectPaymentRegistr2Domain,
    substate => substate,
  );

export default makeSelectPaymentRegistr2;
export { selectPaymentRegistr2Domain };
