// import { selectPaymentRegistr2Domain } from '../selectors';

describe('selectPaymentRegistr2Domain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
