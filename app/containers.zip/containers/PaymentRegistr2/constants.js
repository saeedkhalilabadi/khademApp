/*
 *
 * PaymentRegistr2 constants
 *
 */

export const SET_VALUE = 'app/PaymentRegistr2/SET_VALUE';

export const GET_DATA = 'app/PaymentRegistr2/GET_DATA';
export const GET_DATA_SUCCESS = 'app/PaymentRegistr2/GET_DATA_SUCCESS';
export const GET_DATA_ERROR = 'app/PaymentRegistr2/GET_DATA_ERROR';

export const ADD_DATA = 'app/PaymentRegistr2/ADD_DATA';
export const ADD_DATA_SUCCESS = 'app/PaymentRegistr2/ADD_DATA_SUCCESS';
export const ADD_DATA_ERROR = 'app/PaymentRegistr2/ADD_DATA_ERROR';
