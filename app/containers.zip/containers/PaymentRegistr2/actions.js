/*
 *
 * PaymentRegistr2 actions
 *
 */

import {
  GET_DATA,
  GET_DATA_ERROR,
  GET_DATA_SUCCESS,
  ADD_DATA,
  ADD_DATA_ERROR,
  ADD_DATA_SUCCESS,
  SET_VALUE,
} from './constants';

export function setValue(data) {
  return {
    type: SET_VALUE,
    data,
  };
}
export function getData(data) {
  return {
    type: GET_DATA,
    data,
  };
}
export function getDataSuccess(data) {
  return {
    type: GET_DATA_SUCCESS,
    data,
  };
}
export function getDataError(data) {
  return {
    type: GET_DATA_ERROR,
    data,
  };
}

export function addData(data) {
  return {
    type: ADD_DATA,
    data,
  };
}
export function addDataSuccess(data) {
  return {
    type: ADD_DATA_SUCCESS,
    data,
  };
}
export function addDataError(data) {
  return {
    type: ADD_DATA_ERROR,
    data,
  };
}
