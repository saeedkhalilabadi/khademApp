/*
 * PaymentRegistr2 Messages
 *
 * This contains all the text for the PaymentRegistr2 container.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.containers.PaymentRegistr2';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the PaymentRegistr2 container!',
  },
});
