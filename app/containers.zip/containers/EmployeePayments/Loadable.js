/**
 *
 * Asynchronously loads the component for EmployeePayments
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
