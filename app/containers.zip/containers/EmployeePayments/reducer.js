/*
 *
 * EmployeePayments reducer
 *
 */
import produce from 'immer';
import {
  GET_DATA,
  GET_DATA_SUCCESS,
  GET_DATA_FAIL,
} from './constants';

export const initialState = {
  data:[],
};

/* eslint-disable default-case, no-param-reassign */
const employeePaymentsReducer = (state = initialState, action) =>
  produce(state,draft => {
    switch (action.type) {
      case GET_DATA:
        break;
      case GET_DATA_SUCCESS:
        draft.data=action.data;
        break;
      case GET_DATA_FAIL:
        break;
    }
  });

export default employeePaymentsReducer;
