/*
 *
 * EmployeePayments constants
 *
 */

export const GET_DATA = 'app/EmployeePayments/GET_DATA';
export const GET_DATA_SUCCESS = 'app/EmployeePayments/GET_DATA_SUCCESS';
export const GET_DATA_FAIL = 'app/EmployeePayments/GET_DATA_FAIL';
