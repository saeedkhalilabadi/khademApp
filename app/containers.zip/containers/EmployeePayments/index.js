/**
 *
 * EmployeePayments
 *
 */

import React, { memo, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { Col, Row, Button, Form } from 'react-bootstrap';
import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectEmployeePayments from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import NumberFormat from 'react-number-format';

import { getData } from './actions';
import './index.css';
export function EmployeePayments({ employeePayments, dispatch, props }) {
  useInjectReducer({ key: 'employeePayments', reducer });
  useInjectSaga({ key: 'employeePayments', saga });

  const [getdata, setgetdata] = useState(true);
  const words = {
    sale: 'فروش',
    wage: 'حق الزحمه',
    kgGole: 'کیلو گرم گل',
  };
  if (getdata)
    setTimeout(() => {
      setgetdata(false);
      dispatch(getData({ id: props.id }));
    }, 200);
  console.log(employeePayments.data);
  const payments = (
    <Row>
      {employeePayments.data.length == 0 ? (
        <p>اطلاعاتی پیدا نشد</p>
      ) : (
        <>
          {employeePayments.data.length > 0 &&
            employeePayments.data.map(payment => (
              <Col
                xs={12}
                sm={12}
                md={12}
                xl={12}
                className="payItems"
                key={payment.id}
              >
                <Row>
                  <Col xs={6} sm={6} md={3} xl={3}>
                    تاریخ:{' '}
                    {payment.date_str.slice(0, 4) +
                      '/' +
                      payment.date_str.slice(5, 7) +
                      '/' +
                      payment.date_str.slice(8, 10)}
                  </Col>
                  <Col xs={6} sm={6} md={2} xl={2}>
                    نوع پرداخت: {payment.typeOfPayment}
                  </Col>
                  <Col xs={6} sm={6} md={3} xl={3}>
                    مبلغ:{' '}
                    <NumberFormat
                      value={Number(payment.price)}
                      displayType={'text'}
                      thousandSeparator={true}
                      renderText={(value, props) => (
                        <span {...props}>{value} تومان</span>
                      )}
                    />
                  </Col>
                  <Col xs={6} sm={6} md={2} xl={2}>
                    موضوع پرداخت:
                    {payment.payerSubject == 'sale'
                      ? words.sale +
                        ' ' +
                        payment.payer_detail.weight +
                        ' ' +
                        words.kgGole
                      : words.wage}
                  </Col>
                  <Col xs={6} sm={6} md={2} xl={2}>
                    پرداخت کننده:{' '}
                    {payment.payerSubject == 'sale'
                      ? payment.payer_detail.buyer_name ||
                        '' + ' ' + payment.payer_detail.buyer_lname ||
                        ''
                      : payment.payer_detail.name ||
                        '' + ' ' + payment.payer_detail.lname ||
                        ''}
                  </Col>

                  <Col xs={6} sm={6} md={2} xl={2}>
                    کدپیگیری: {payment.trackingCode}
                  </Col>
                </Row>
              </Col>
            ))}
        </>
      )}
    </Row>
  );
  return (
    <div>
      <Helmet>
        <title>EmployeePayments</title>
        <meta name="description" content="Description of EmployeePayments" />
      </Helmet>
      {payments}
    </div>
  );
}

EmployeePayments.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  employeePayments: makeSelectEmployeePayments(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(EmployeePayments);
