import { take, call, put, select, takeLatest } from 'redux-saga/effects';
import axios from '../axios/axios-user';
import {
  GET_DATA
} from './constants';
import {
  getDataSuccess,
  getDataFail,
} from './actions';
export function* getPayments(Data) {
    console.log(data);
    let e = 0;
    let data = 0;
    const d = {
        branche_id: Data.data.id,
    };
    console.log(d);
    
        yield axios
            .post('/api/paymants/getdata/manager',d, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
            .then(response => {
              //  console.log(response.data.data, 'response333');
                data = response.data.data;
                // console.log(response.data.data.userData, 'res');
                e = 1;
            })
            .catch(error => {
                data = error;
                console.log(error.response);
            });
        if (e == 1) yield put(getDataSuccess(data));
        else yield put(getDataFail(data)); 
    }
export default function* employeePaymentsSaga() {
  yield takeLatest(GET_DATA, getPayments);
}
