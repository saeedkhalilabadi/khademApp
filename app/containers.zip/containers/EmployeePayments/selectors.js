import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the employeePayments state domain
 */

const selectEmployeePaymentsDomain = state =>
  state.employeePayments || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by EmployeePayments
 */

const makeSelectEmployeePayments = () =>
  createSelector(
    selectEmployeePaymentsDomain,
    substate => substate,
  );

export default makeSelectEmployeePayments;
export { selectEmployeePaymentsDomain };
