// import { selectEmployeeSalesDomain } from '../selectors';

describe('selectEmployeeSalesDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
