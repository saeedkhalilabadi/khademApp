/**
 *
 * Asynchronously loads the component for EmployeeSales
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
