import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the employeeSales state domain
 */

const selectEmployeeSalesDomain = state => state.employeeSales || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by EmployeeSales
 */

const makeSelectEmployeeSales = () =>
  createSelector(
    selectEmployeeSalesDomain,
    substate => substate,
  );

export default makeSelectEmployeeSales;
export { selectEmployeeSalesDomain };
