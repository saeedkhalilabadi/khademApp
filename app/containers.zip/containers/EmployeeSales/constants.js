/*
 *
 * EmployeeSales constants
 *
 */

export const GET_DATA = 'app/EmployeeSales/GET_DATA';
export const GET_DATA_SUCCESS = 'app/EmployeeSales/GET_DATA_SUCCESS';
export const GET_DATA_ERROR = 'app/EmployeeSales/GET_DATA_ERROR';

export const ADD_NEW = 'app/EmployeeSales/ADD_NEW';
export const ADD_NEW_SUCCESS = 'app/EmployeeSales/ADD_NEW_SUCCESS';
export const ADD_NEW_ERROR = 'app/EmployeeSales/ADD_NEW_ERROR';

export const UPDATE_DATA = 'app/EmployeeSales/UPDATE_DATA';
export const UPDATE_DATA_SUCCESS = 'app/EmployeeSales/UPDATE_DATA_SUCCESS';
export const UPDATE_DATA_ERROR = 'app/EmployeeSales/UPDATE_DATA_ERROR';
