import axios from 'containers/axios/axios-user';
import { takeLatest, call, put, select } from 'redux-saga/effects';
import {
  GET_DATA
  , ADD_NEW,
  UPDATE_DATA
} from './constants';
import {
  getDataSuccess,
  getDataError,
  addNewSuccess,
  addNewError,
  updateDataSuccess,
  updateDataError,
  updateData
} from './actions';

export function* getdata(params) {
  let data;
  let e = null;
  console.log(params);
  yield axios
    .post('api/sales/getdata', params.data, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      console.log(response.data, 'employees1');
      data = response.data;
      e = true;
    })
    .catch(error => {
      console.log(error.response);
      data = error.response;
      e = false;
    });
  if (e) yield put(getDataSuccess(data));
  else yield put(getDataError(data));
}
export function* addnew(params) {
  let data;
  let e = null;
  console.log(params);
  yield axios
    .post('api/sales', params.data, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      console.log(response.data, 'employees1');
      data = response.data;
      e = true;
    })
    .catch(error => {
      console.log(error.response);
      data = error.response;
      e = false;
    });
  if (e) yield put(addNewSuccess(data));
  else yield put(addNewError(data));
}

export function* updateDataSaga(params) {
  let data;
  let e = null;
  console.log(params);
  switch (params.data.act) {
    case 'update':
      yield axios
      .put('api/sales/'+ params.data.data.id, params.data.data, {
        headers: JSON.parse(localStorage.getItem('userData')),
      })
      .then(response => {
        console.log(response.data, 'employees1');
        data = response.data;
        e = true;
      })
      .catch(error => {
        console.log(error.response);
        data = error.response;
        e = false;
      });
    if (e) yield put(updateDataSuccess(data,'update'));
    else yield put(updateDataError(data,'update'));
      break;

      case 'delete':
      yield axios
      .delete('api/sales/'+ params.data.data.id, {
        headers: JSON.parse(localStorage.getItem('userData')),
      })
      .then(response => {
        console.log(response.data, 'employees1');
        data = response.data;
        e = true;
      })
      .catch(error => {
        console.log(error.response);
        data = error.response;
        e = false;
      });
    if (e) yield put(updateDataSuccess(data,'update'));
    else yield put(updateDataError(data,'delete'));
      break;
  
    default:
      break;
  }
 
}
// Individual exports for testing
export default function* employeeSalesSaga() {
  yield takeLatest(GET_DATA, getdata);
  yield takeLatest(ADD_NEW, addnew);
  yield takeLatest(UPDATE_DATA, updateDataSaga);
  // See example in containers/HomePage/saga.js
}
