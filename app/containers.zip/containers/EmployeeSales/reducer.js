/*
 *
 * EmployeeSales reducer
 *
 */
import produce from 'immer';
import {
  GET_DATA,
  GET_DATA_ERROR,
  GET_DATA_SUCCESS,
  ADD_NEW,
  ADD_NEW_ERROR,
  ADD_NEW_SUCCESS,
  UPDATE_DATA,
  UPDATE_DATA_SUCCESS,
  UPDATE_DATA_ERROR
} from './constants';

export const initialState = {
  data: [],
  date: [],
  config: 0,
  supply: 0,
  load: 0,
  del:null,
};

/* eslint-disable default-case, no-param-reassign */
const employeeSalesReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case GET_DATA:
        draft.load = 1;
        break;
      case GET_DATA_SUCCESS:
        draft.load = 0;

        draft.date = action.data.date;
        if (action.data.status == 'true') {

          draft.data = action.data.data;
          draft.config = action.data.config;
          draft.supply = Math.round(action.data.supply * 100) / 100;
          draft.del = action.data.del;
        }
        break;
      case GET_DATA_ERROR:
        draft.load = 0;

        break;
      case ADD_NEW:
        draft.load = 1;

        break;
      case ADD_NEW_SUCCESS:
        draft.load = 0;
        draft.data = action.data.data;
        draft.supply = Math.round(action.data.supply * 100) / 100;
        break;
      case ADD_NEW_ERROR:
        draft.load = 0;
        break;

      case UPDATE_DATA:
        draft.load = 1;
        break;
      case UPDATE_DATA_SUCCESS:
        draft.load = 0;
        if(action.act == 'update'){
          draft.data = action.data.data;
          draft.supply = Math.round(action.data.supply * 100) / 100;
        } 

        if(action.act == 'delete'){
          draft.data = action.data.data;
          draft.supply = Math.round(action.data.supply * 100) / 100;
        } 
          
        break;
      case UPDATE_DATA_ERROR:
        draft.load = 0;
        break;
    }
  });

export default employeeSalesReducer;
