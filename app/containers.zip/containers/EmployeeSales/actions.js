/*
 *
 * EmployeeSales actions
 *
 */

import {
  GET_DATA,
  GET_DATA_ERROR,
  GET_DATA_SUCCESS,
  ADD_NEW,
  ADD_NEW_ERROR,
  ADD_NEW_SUCCESS,
  UPDATE_DATA,
  UPDATE_DATA_SUCCESS,
  UPDATE_DATA_ERROR,
} from './constants';

export function getData(data) {
  return {
    type: GET_DATA,
    data,
  };
}
export function getDataSuccess(data) {
  return {
    type: GET_DATA_SUCCESS,
    data,
  };
}
export function getDataError(data) {
  return {
    type: GET_DATA_ERROR,
    data,
  };
}
export function addNew(data) {
  return {
    type: ADD_NEW,
    data,
  };
}
export function addNewSuccess(data) {
  return {
    type: ADD_NEW_SUCCESS,
    data,
  };
}
export function addNewError(data) {
  return {
    type: ADD_NEW_ERROR,
    data,
  };
}
export function updateData(data) {
  return {
    type: UPDATE_DATA,
    data,
  };
}
export function updateDataSuccess(data,act) {
  return {
    type: UPDATE_DATA_SUCCESS,
    data,act
  };
}
export function updateDataError(data,act) {
  return {
    type: UPDATE_DATA_ERROR,
    data,act
  };
}
