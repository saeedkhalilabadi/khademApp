/**
 *
 * EmployeeSales
 *
 */

import React, { memo, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import Loading from 'components/Loading/Loadable';

import { compose } from 'redux';
import { Col, Row, Form, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import 'react-modern-calendar-datepicker/lib/DatePicker.css';
import DatePicker from 'react-modern-calendar-datepicker';
import NumberFormat from 'react-number-format';
import Typography from '@mui/material/Typography';
import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectEmployeeSales from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import { getData, addNew, updateData } from './actions';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import './index.css';
import '../../src/allStyles.css';

export function EmployeeSales({ employeeSales, dispatch, props }) {
  useInjectReducer({ key: 'employeeSales', reducer });
  useInjectSaga({ key: 'employeeSales', saga });
  const [getdata, setgetdata] = useState(true);
  const [date, setdate] = useState(null);
  const [weight, setweight] = useState('');
  const [name, setname] = useState('');
  const [phone, setphone] = useState('');
  const [address, setaddress] = useState('');
  const [price, setprice] = useState(0);
  const [openNew, setopenNew] = useState(false);
  const [showInfoItemId, setshowInfoItemId] = useState(0);
  const [editDiv, setEditDiv] = useState(-1);
  const [deleteDiv, setDeleteDiv] = useState(-1);
  console.log(employeeSales);
  if (getdata) {
    setTimeout(() => {
      setgetdata(false);
      dispatch(getData({ branche_id: 'self', date: 'today' }));
    }, 50);
  }

  const selectDate = (
    <Row className="title">
      <Col xs={6} sm={6} md={6} xl={6}>

      <Typography variant="h5" gutterBottom component="h5" className="titleText">
        فروش گل در تاریخ:
      </Typography>
      </Col>
      <Col xs={6} sm={6} md={6} xl={6}>

      <DatePicker
        value={
          employeeSales.date == null
            ? null
            : {
                day: Number(employeeSales.date.d),
                month: Number(employeeSales.date.m),
                year: Number(employeeSales.date.y),
              }
        }
        onChange={e => {
          dispatch(
            getData({
              branche_id: 'self',
              date: 'date',
              start_m: e.month,
              start_d: e.day,
              start_y: e.year,
            }),
          );
          setdate(e);
        }}
        shouldHighlightWeekends
        locale="fa" // add this
      />
      </Col>
    </Row>
  );
  const newBtn = (
    <Button
      variant="warning"
      className="newBtn"
      onClick={() => setopenNew(true)}
      style={
        props.screen.width > 1000
          ? {
              top: '60px',
              left: '10px',
            }
          : {
              bottom: '20px',
              right: '10px',
            }
      }
    >
      ثبت
    </Button>
  );
  const addNewForm =
    editDiv != -1 || employeeSales.config == 0 ? null : (
      <Row className="form">
        <Col xs={6} sm={6} md={6} xl={6} className="fieldItem">
          <Form.Group className="mb-1" controlId="formBasicEmail">
            <Form.Text className="text-muted">وزن </Form.Text>

            <NumberFormat
              style={{ width: '100%' }}
              value={weight}
              thousandSeparator={true}
              placeholder="وزن"
              onValueChange={e => setweight(e.value)}
            />
          </Form.Group>
        </Col>
        <Col xs={6} sm={6} md={6} xl={6} className="fieldItem">
          {'موجودی : ' + employeeSales.supply}
        </Col>
        <Col xs={12} sm={12} md={12} xl={12} className="fieldItem">
          <Form.Group className="mb-1" controlId="formBasicEmail">
            <Form.Text className="text-muted">قیمت</Form.Text>
            <NumberFormat
              defaultValue={Number(employeeSales.config.sale.value)}
              style={{ width: '100%', height: '40px', fontSize: '20px' }}
              placeholder="قیمت"
              thousandSeparator={true}
              onValueChange={e => setprice(e.value)}
            />
          </Form.Group>
        </Col>
        <Col xs={12} sm={12} md={12} xl={12} className="fieldItem">
          <Form.Group className="mb-1" controlId="formBasicEmail">
            <Form.Text column sm="2" className="text-muted">
              نام و نام خاوادگی
            </Form.Text>

            <Form.Control
              size="sm"
              value={name}
              type="text"
              placeholder="نام و نام خانوادگی"
              onChange={e => {
                setname(e.target.value);
              }}
            />
          </Form.Group>
        </Col>
        <Col xs={12} sm={12} md={12} xl={12} className="fieldItem">
          <Form.Group className="mb-1" controlId="formBasicEmail">
            <Form.Text className="text-muted">شماره تماس</Form.Text>

            <Form.Control
              size="sm"
              value={phone}
              type="number"
              placeholder="شماره تماس"
              onChange={e => {
                setphone(e.target.value);
              }}
            />
          </Form.Group>
        </Col>
        <Col xs={12} sm={12} md={12} xl={12} className="fieldItem">
          <Form.Group className="mb-1" controlId="formBasicEmail">
            <Form.Text className="text-muted">توضیحات</Form.Text>

            <Form.Control
              size="sm"
              value={address}
              type="text"
              placeholder="توضیحات و آدرس"
              onChange={e => {
                setaddress(e.target.value);
              }}
            />
          </Form.Group>
        </Col>

        <Col xs={12} sm={12} md={12} xl={12} className="fieldItem">
          <Button
            variant="warning"
            style={{ width: '100%' }}
            disabled={weight <= 0 || weight > employeeSales.supply}
            size="sm"
            onClick={() => {
              dispatch(
                addNew({
                  weight,
                  price: price == 0 ? employeeSales.config.sale.value : price,
                  total: weight * price,
                  buyer_name: name,
                  buyer_lname: ' ',
                  buyer_phone: phone,
                  buyer_address: address,
                  date: 'date',
                  y: employeeSales.date.y,
                  m: employeeSales.date.m,
                  d: employeeSales.date.d,
                }),
              );
              setweight('');
              setname('');
              setphone('');
              setaddress('');
            }}
          >
            {weight > employeeSales.supply ? 'مقدارموجودی کافی نیست' : 'ثبت'}
          </Button>
        </Col>
      </Row>
    );

  const EditForm =
    editDiv == -1 ? null : (
      <Row className="form">
        <Col xs={6} sm={6} md={6} xl={6} className="fieldItem">
          <Form.Group className="mb-1" controlId="formBasicEmail">
            <Form.Text className="text-muted">وزن </Form.Text>

            <NumberFormat
              style={{ width: '100%' }}
              value={weight}
              thousandSeparator={true}
              placeholder="وزن"
              onValueChange={e => setweight(e.value)}
            />
          </Form.Group>
        </Col>
        <Col xs={6} sm={6} md={6} xl={6} className="fieldItem">
          {'موجودی در دسترس : ' +
            (Number(employeeSales.supply) +
              Number(employeeSales.data[editDiv].weight))}
        </Col>
        <Col xs={12} sm={12} md={12} xl={12} className="fieldItem">
          <Form.Group className="mb-1" controlId="formBasicEmail">
            <Form.Text className="text-muted">قیمت</Form.Text>
            <NumberFormat
              defaultValue={Number(employeeSales.config.sale.value)}
              style={{ width: '100%', height: '40px', fontSize: '20px' }}
              placeholder="قیمت"
              thousandSeparator={true}
              onValueChange={e => setprice(e.value)}
            />
          </Form.Group>
        </Col>
        <Col xs={12} sm={12} md={12} xl={12} className="fieldItem">
          <Form.Group className="mb-1" controlId="formBasicEmail">
            <Form.Text column sm="2" className="text-muted">
              نام و نام خانوادگی
            </Form.Text>

            <Form.Control
              size="sm"
              value={name}
              type="text"
              placeholder="نام و نام خانوادگی"
              onChange={e => {
                setname(e.target.value);
              }}
            />
          </Form.Group>
        </Col>
        <Col xs={12} sm={12} md={12} xl={12} className="fieldItem">
          <Form.Group className="mb-1" controlId="formBasicEmail">
            <Form.Text className="text-muted">شماره تماس</Form.Text>

            <Form.Control
              size="sm"
              value={phone}
              type="number"
              placeholder="شماره تماس"
              onChange={e => {
                setphone(e.target.value);
              }}
            />
          </Form.Group>
        </Col>
        <Col xs={12} sm={12} md={12} xl={12} className="fieldItem">
          <Form.Group className="mb-1" controlId="formBasicEmail">
            <Form.Text className="text-muted">توضیحات</Form.Text>

            <Form.Control
              size="sm"
              value={address}
              type="text"
              placeholder="توضیحات و آدرس"
              onChange={e => {
                setaddress(e.target.value);
              }}
            />
          </Form.Group>
        </Col>

        <Col xs={6} sm={6} md={6} xl={6} className="fieldItem">
          <Button
            variant="warning"
            style={{ width: '100%' }}
            disabled={
              weight <= 0 ||
              weight > employeeSales.supply + employeeSales.data[editDiv].weight
            }
            size="sm"
            onClick={() => {
              dispatch(
                updateData({
                  act: 'update',
                  data: {
                    id: employeeSales.data[editDiv].id,
                    weight,
                    price: price == 0 ? employeeSales.config.sale.value : price,
                    total: weight * price,
                    buyer_name: name,
                    buyer_lname: ' ',
                    buyer_phone: phone,
                    buyer_address: address,
                  },
                }),
              );
              setweight('');
              setname('');
              setphone('');
              setaddress('');
              setprice(0);
              setEditDiv(-1);
            }}
          >
            {weight > employeeSales.supply + employeeSales.data[editDiv].weight
              ? 'مقدارموجودی کافی نیست'
              : 'ثبت'}
          </Button>
        </Col>
        <Col xs={6} sm={6} md={6} xl={6} className="fieldItem">
          <Button
            variant="warning"
            style={{ width: '100%' }}
            size="sm"
            onClick={() => {
              setEditDiv(-1);
              setweight('');
              setname('');
              setphone('');
              setaddress('');
              setprice('');
            }}
          >
            انصراف
          </Button>
        </Col>
      </Row>
    );

  const DeleteForm =
    deleteDiv == -1 ? null : (
      <Row className="form">
        <Col xs={12} sm={12} md={12} xl={12}>
          <Typography variant="h5" component="h5" align="center">
            آیتم حذف شود
          </Typography>
        </Col>
        <Col xs={6} sm={6} md={6} xl={6} className="fieldItem">
          <Button
            variant="warning"
            style={{ width: '100%' }}
            size="sm"
            onClick={() => {
              dispatch(
                updateData({
                  act: 'delete',
                  data: {
                    id: employeeSales.data[deleteDiv].id,
                  },
                }),
              );
              setDeleteDiv(-1);
            }}
          >
            حذف
          </Button>
        </Col>
        <Col xs={6} sm={6} md={6} xl={6} className="fieldItem">
          <Button
            variant="warning"
            style={{ width: '100%' }}
            size="sm"
            onClick={() => {
              setDeleteDiv(-1);
            }}
          >
            انصراف
          </Button>
        </Col>
      </Row>
    );
  const showList = (
    <Row style={{ marginBottom: '100px' }}>
      {employeeSales.data.length == 0 ? (
        <Col xs={12} sm={12} md={12} xl={12} style={{ textAlign: 'center' }}>
          در این تاریخ فروشی ثبت نشده
        </Col>
      ) : (
        employeeSales.data.map((item, index) => (
          <Col
            xs={12}
            sm={12}
            md={12}
            xl={12}
            className="itemList"
            style={
              props.screen.width > 768
                ? editDiv == index
                  ? { height: '517px' }
                  : deleteDiv == index
                  ? { height: '185px' }
                  : { height: '80px' }
                : editDiv == index
                ? { height: '610px' }
                : deleteDiv == index
                ? { height: '275px' }
                : { height: '170px' }
            }
          >
            <Row onClick={() => setshowInfoItemId(item.id)}>
              <Col xs={6} sm={6} md={3} xl={2}>
                نام خریدار: {item.buyer_name}
              </Col>

              <Col xs={6} sm={6} md={3} xl={2}>
                قیمت هر کیلو:{' '}
                <NumberFormat
                  value={item.price}
                  displayType={'text'}
                  thousandSeparator={true}
                  renderText={value => <span>{value} تومان</span>}
                />
              </Col>
              <Col xs={6} sm={6} md={2} xl={1}>
                وزن: {item.weight} کیلو
              </Col>
              <Col xs={6} sm={6} md={3} xl={2}>
                قیمت کل:{' '}
                <NumberFormat
                  value={item.total}
                  displayType={'text'}
                  thousandSeparator={true}
                  renderText={value => <span>{value} تومان</span>}
                />
              </Col>

              <Col xs={12} sm={12} md={3} xl={2}>
                آدرس :{item.buyer_address}
              </Col>
              <Col xs={8} sm={8} md={3} xl={2}>
                تلفن :{item.buyer_phone}
              </Col>
              {employeeSales.del.status == 1 ? (
                <Col xs={4} sm={4} md={2} xl={1}>
                  <EditIcon
                    className="mx-2"
                    sx={{ color: '#414dca' }}
                    style={{
                      cursor: 'pointer',
                      fontSize: '1.5rem',
                      textAlign: 'center',
                    }}
                    onClick={() => {
                      setweight(item.weight);
                      setname(item.buyer_name);
                      setphone(item.buyer_phone);
                      setaddress(item.buyer_address);
                      setprice(item.price);
                      setDeleteDiv(-1);
                      setEditDiv(index);
                    }}
                  />

                  <DeleteIcon
                    className="mx-2"
                    sx={{ color: '#ca7241' }}
                    style={{ cursor: 'pointer', fontSize: '1.5rem' }}
                    onClick={() => {
                      setEditDiv(-1);
                      setDeleteDiv(index);
                    }}
                  />
                </Col>
              ) : null}
            </Row>
            {editDiv == index ? (
              <Row className="editDiv">
                <Col xs={12} sm={12} md={12} xl={12}>
                  {EditForm}
                </Col>
              </Row>
            ) : null}
            {deleteDiv == index ? (
              <Row className="editDiv">
                <Col xs={12} sm={12} md={12} xl={12}>
                  {DeleteForm}
                </Col>
              </Row>
            ) : null}
          </Col>
        ))
      )}
    </Row>
  );

  return (
    <div
      onKeyDown={e => {
        if (e.key === 'Enter') {
          const fields =
            Array.from(e.currentTarget.querySelectorAll('input')) || [];
          const position = fields.indexOf(
            e.target, // as HTMLInputElement (for TypeScript)
          );
          fields[position + 1] && fields[position + 1].focus();
        }
      }}
    >
      <Helmet>
        <title>فروش</title>
      </Helmet>
      {employeeSales.load == 1 ? <Loading /> : null}
      {selectDate}
      {addNewForm}
      {showList}
    </div>
  );
}

EmployeeSales.propTypes = {
  dispatch: PropTypes.func.isRequired,
  employeeSales: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  employeeSales: makeSelectEmployeeSales(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(EmployeeSales);
