/*
 *
 * EmployeeStatus constants
 *
 */

export const DEFAULT_ACTION = 'app/EmployeeStatus/DEFAULT_ACTION';
