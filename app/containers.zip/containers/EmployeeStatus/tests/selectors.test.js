// import { selectEmployeeStatusDomain } from '../selectors';

describe('selectEmployeeStatusDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
