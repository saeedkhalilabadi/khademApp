/**
 * Test sagas
 */

/* eslint-disable redux-saga/yield-effects */
// import { take, call, put, select } from 'redux-saga/effects';
// import employeeStatusSaga from '../saga';

// const generator = employeeStatusSaga();

describe('employeeStatusSaga Saga', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
