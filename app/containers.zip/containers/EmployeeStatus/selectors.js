import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the employeeStatus state domain
 */

const selectEmployeeStatusDomain = state =>
  state.employeeStatus || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by EmployeeStatus
 */

const makeSelectEmployeeStatus = () =>
  createSelector(
    selectEmployeeStatusDomain,
    substate => substate,
  );

export default makeSelectEmployeeStatus;
export { selectEmployeeStatusDomain };
