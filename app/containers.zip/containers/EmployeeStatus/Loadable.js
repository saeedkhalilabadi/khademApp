/**
 *
 * Asynchronously loads the component for EmployeeStatus
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
