/*
 *
 * EmployeeList reducer
 *
 */
import produce from 'immer';
import {
  GET_DATA,
  GET_DATA_ERROR,
  GET_DATA_SUCCESS,
  CONFIRM_LIST,
  CONFIRM_LIST_ERROR,
  CONFIRM_LIST_SUCCESS,
} from './constants';

export const initialState = {
  data: [],
  item: null,
  load: 0,
  sumSale: 0,
  sumDis: 0,
  sumBags: 0,
};

/* eslint-disable default-case, no-param-reassign */
const employeeListReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case GET_DATA:
        draft.load = 1;
        break;
      case GET_DATA_SUCCESS:
        draft.load = 0;
        draft.data = action.data.data;
        draft.sumBags = action.data.data.bags_sum_weight / 1000;
        draft.sumDis = action.data.data.folwerKg;
        draft.sumSale = action.data.data.saleTotal / 1000;

        break;
      case GET_DATA_ERROR:
        draft.load = 0;
        break;
      case CONFIRM_LIST:
        break;
      case CONFIRM_LIST_SUCCESS:
        break;
      case CONFIRM_LIST_ERROR:
        break;
    }
  });

export default employeeListReducer;
