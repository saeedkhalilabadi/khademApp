/*
 *
 * EmployeeList constants
 *
 */

export const GET_DATA = 'app/EmployeeList/GET_DATA';
export const GET_DATA_SUCCESS = 'app/EmployeeList/GET_DATA_SUCCESS';
export const GET_DATA_ERROR = 'app/EmployeeList/GET_DATA_ERROR';

export const CONFIRM_LIST = 'app/EmployeeList/CONFIRM_LIST';
export const CONFIRM_LIST_SUCCESS = 'app/EmployeeList/CONFIRM_LIST_SUCCESS';
export const CONFIRM_LIST_ERROR = 'app/EmployeeList/CONFIRM_LIST_ERROR';
