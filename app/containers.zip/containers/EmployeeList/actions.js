/*
 *
 * EmployeeList actions
 *
 */

import {
  GET_DATA,
  GET_DATA_ERROR,
  GET_DATA_SUCCESS,
  CONFIRM_LIST,
  CONFIRM_LIST_ERROR,
  CONFIRM_LIST_SUCCESS,
} from './constants';

export function getData(data) {
  return {
    type: GET_DATA,
    data,
  };
}
export function getDataSuccess(data) {
  return {
    type: GET_DATA_SUCCESS,
    data,
  };
}
export function getDataError(data) {
  return {
    type: GET_DATA_ERROR,
    data,
  };
}
export function confirmList(data) {
  return {
    type: CONFIRM_LIST,
    data,
  };
}
export function confirmListSuccess(data) {
  return {
    type: CONFIRM_LIST_SUCCESS,
    data,
  };
}
export function confirmListError(data) {
  return {
    type: CONFIRM_LIST_ERROR,
    data,
  };
}
