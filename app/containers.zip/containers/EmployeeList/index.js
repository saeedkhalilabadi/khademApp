/**
 *
 * EmployeeList
 *
 */

import React, { memo, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { Col, Row, Form, Button } from 'react-bootstrap';

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectEmployeeList from './selectors';
import reducer from './reducer';
import saga from './saga';

import { getData, confirmList } from './actions';
import './index.css';
import '../../src/allStyles.css';

export function EmployeeList({ dispatch, employeeList, props }) {
  useInjectReducer({ key: 'employeeList', reducer });
  useInjectSaga({ key: 'employeeList', saga });
  const [getdata, setgetdata] = useState(true);

  //console.log(props.substate.location.state.id, 'props');
  console.log(employeeList);
  if (getdata)
    setTimeout(() => {
      setgetdata(false);
      dispatch(getData(props.substate.location.state.id));
    }, 100);
  const myw = {
    kasif:'کثیف',
    tamiz:'تمیز',
    dir:'دیر',
    zod:'زود',
    sabtnashodeh:'ثبت نشده'
  }
  const titleList = (
    <Row className="title">
      <Col xs={12} sm={12} md={12} xl={12}>
        {employeeList.data.date_in_str &&
          employeeList.data.date_in_str.slice(0, 4) +
            '/' +
            employeeList.data.date_in_str.slice(5, 7) +
            '/' +
            employeeList.data.date_in_str.slice(8, 10)}
      </Col>
      <Col xs={12} sm={12} md={12} xl={12}>
        <Row>
          <Col xs={12} sm={12} md={12} xl={12}>
            فروش : {employeeList.sumSale + 'کیلو'}
          </Col>
          <Col xs={12} sm={12} md={12} xl={12}>
            توزیع :{employeeList.sumDis/1000 + 'کیلو'}
          </Col>
          <Col xs={12} sm={12} md={12} xl={12}>
            موجودی کل : {employeeList.sumBags + 'کیلو'}
          </Col>
        </Row>
      </Col>
      <Col xs={12} sm={12} md={12} xl={12}>
        <Button
          variant="primary "
          size="sm"
          style={{ width: '100%' }}
          onClick={() =>
            dispatch(confirmList({ id: employeeList.data.id, status: 2 }))
          }
          disabled={
            Math.abs(
              (employeeList.sumDis/1000) + employeeList.sumSale - employeeList.sumBags,
            ) > 1 || employeeList.data.status == 2
          }
        >
          {employeeList.data.status == 2
            ? 'تایید شده'
            : Math.abs(
                (employeeList.sumDis/1000) +
                  employeeList.sumSale -
                  employeeList.sumBags,
              ) > 1
            ? 'لیست تکمیل نشده'
            : 'تایید لیست'}
        </Button>
      </Col>
    </Row>
  );

  const showList =
    employeeList.data.length == 0 ? null : (
      <Row className="form">
        {employeeList.data.dis.map(item => (
          <Col xs={12} sm={12} md={12} xl={12}>
            <Row className="employeeListItems">
              <Col xs={12} sm={12} md={12} xl={12}>
                {item.sub.gender + ' ' + item.sub.name + ' ' + item.sub.lname}
              </Col>
              <Col xs={6} sm={6} md={6} xl={6}>
                {'گل: ' + (item.flowerKg_kg ? item.flowerKg/1000 : 0) + 'کیلو'}
              </Col>

              <Col xs={6} sm={6} md={6} xl={6}>
                {'سرگل: ' + (item.headG ? item.headG : 0) + 'گرم'}
              </Col>
              <Col xs={6} sm={6} md={6} xl={6}>
                {'عیار: ' + Math.round(item.average ? item.average : 0) + 'g/kg'}
              </Col>

              <Col xs={6} sm={6} md={6} xl={6}>
                {'امتیاز: ' + (item.star==null?0:item.star)}
              </Col>

              <Col xs={6} sm={6} md={6} xl={6}>
                وضعیت:
                {item.headG ? 'بسته' : 'باز'}
              </Col>
              <Col xs={6} sm={6} md={6} xl={6}>
                کیفیت انجام:
                {item.quality_status==0 ? myw.kasif : (item.quality_status==1?myw.tamiz:myw.sabtnashodeh)}
              </Col>
              <Col xs={6} sm={6} md={6} xl={6}>
                زمان انجام:
                {item.delay_status==1 ? myw.dir :(item.delay_status==0?myw.zod:myw.sabtnashodeh) }
              </Col>
            </Row>
          </Col>
        ))}
      </Row>
    );

  return (
    <div>
      <Helmet>
        <title>نمایش لیست</title>
      </Helmet>
      {titleList}
      {showList}
    </div>
  );
}

EmployeeList.propTypes = {
  dispatch: PropTypes.func.isRequired,
  employeeList: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  employeeList: makeSelectEmployeeList(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(EmployeeList);
