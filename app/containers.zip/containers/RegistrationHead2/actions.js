/*
 *
 * RegistrationHead2 actions
 *
 */

import {
  GET_DATA,
  GET_DATA_ERROR,
  GET_DATA_SUCCESS,
  PUT_DATA,
  PUT_DATA_ERROR,
  PUT_DATA_SUCCESS,
} from './constants';

export function getData(data) {
  return {
    type: GET_DATA,
    data,
  };
}
export function getDataSuccess(data) {
  return {
    type: GET_DATA_SUCCESS,
    data,
  };
}
export function getDataError(data) {
  return {
    type: GET_DATA_ERROR,
    data,
  };
}
export function putData(data) {
  return {
    type: PUT_DATA,
    data,
  };
}
export function putDataSuccess(data) {
  return {
    type: PUT_DATA_SUCCESS,
    data,
  };
}
export function putDataError(data) {
  return {
    type: PUT_DATA_ERROR,
    data,
  };
}
