/*
 * RegistrationHead2 Messages
 *
 * This contains all the text for the RegistrationHead2 container.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.containers.RegistrationHead2';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the RegistrationHead2 container!',
  },
});
