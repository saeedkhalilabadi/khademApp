import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the registrationHead2 state domain
 */

const selectRegistrationHead2Domain = state =>
  state.registrationHead2 || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by RegistrationHead2
 */

const makeSelectRegistrationHead2 = () =>
  createSelector(
    selectRegistrationHead2Domain,
    substate => substate,
  );

export default makeSelectRegistrationHead2;
export { selectRegistrationHead2Domain };
