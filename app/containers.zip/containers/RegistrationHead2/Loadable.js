/**
 *
 * Asynchronously loads the component for RegistrationHead2
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
