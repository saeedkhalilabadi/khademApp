/*
 *
 * RegistrationHead2 reducer
 *
 */
import React, { memo, useState } from 'react';
import produce from 'immer';
import MyAlert from '../../components/MyAlert/Loadable';
import {
  GET_DATA,
  GET_DATA_ERROR,
  GET_DATA_SUCCESS,
  PUT_DATA,
  PUT_DATA_ERROR,
  PUT_DATA_SUCCESS,
} from './constants';

export const initialState = {
  data: [],
  load: 0,
  alertSucccess:null
};

/* eslint-disable default-case, no-param-reassign */
const registrationHead2Reducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case GET_DATA:
        draft.load = 1;
        draft.alertSucccess=null;
        break;
      case GET_DATA_SUCCESS:
        draft.load = 0;
        draft.data = action.data.data;
        break;
      case GET_DATA_ERROR:
        draft.load = 0;
        break;
      case PUT_DATA:
        draft.load = 1;
        break;
      case PUT_DATA_SUCCESS:
        draft.load = 0;
        draft.alertSucccess=(<MyAlert severity="success" message="اطلاعات با موفقیت ثبت شد" />);
        draft.data.map((item, index) =>
          action.data.data.id == item.id
            ? (draft.data[index] = action.data.data)
            : null,
        );
        // draft.data = action.data.data.id;
        break;
      case PUT_DATA_ERROR:
        draft.load = 0;
        break;
    }
  });

export default registrationHead2Reducer;
