import { takeLatest, call, put, select } from 'redux-saga/effects';
import axios from '../axios/axios-user';
import { GET_DATA, PUT_DATA } from './constants';
import {
  getDataSuccess,
  getDataError,
  putDataError,
  putDataSuccess,
} from './actions';

function* getdata(params) {
  let data;
  let e = null;
  console.log(params.data);
  yield axios
    .post('api/distribution/getdata', params.data, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      console.log(response.data, 'data');
      data = response.data;
      e = true;
    })
    .catch(error => {
      console.log(error.response);
      data = error;
      e = false;
    });
  if (e) yield put(getDataSuccess(data));
  else yield put(getDataError(data));
}
function* putdata(params) {
  let data;
  let e = null;
  console.log(params.data);
  yield axios
    .put('api/distribution/' + params.data.id, params.data, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      console.log(response.data, 'data');
      data = response.data;
      e = true;
    })
    .catch(error => {
      console.log(error.response);
      data = error;
      e = false;
    });
  if (e) yield put(putDataSuccess(data));
  else yield put(putDataError(data));
}

// Individual exports for testing
export default function* registrationHead2Saga() {
  yield takeLatest(GET_DATA, getdata);
  yield takeLatest(PUT_DATA, putdata);

  // See example in containers/HomePage/saga.js
}
