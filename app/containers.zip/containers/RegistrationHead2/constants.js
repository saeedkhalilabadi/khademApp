/*
 *
 * RegistrationHead2 constants
 *
 */

export const GET_DATA = 'app/RegistrationHead2/GET_DATA';
export const GET_DATA_SUCCESS = 'app/RegistrationHead2/GET_DATA_SUCCESS';
export const GET_DATA_ERROR = 'app/RegistrationHead2/GET_DATA_ERROR';

export const PUT_DATA = 'app/RegistrationHead2/PUT_DATA';
export const PUT_DATA_SUCCESS = 'app/RegistrationHead2/PUT_DATA_SUCCESS';
export const PUT_DATA_ERROR = 'app/RegistrationHead2/PUT_DATA_ERROR';
