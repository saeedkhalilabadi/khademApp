/**
 *
 * RegistrationHead2
 *
 */

import React, { memo, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { Link } from 'react-router-dom';
import { Row, Col, Form, Button, InputGroup } from 'react-bootstrap';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import NumberFormat from 'react-number-format';
import FormLabel from '@mui/material/FormLabel';
import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectRegistrationHead2 from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import { getData, putData } from './actions';
import './index.css';
import '../../src/allStyles.css';
export function RegistrationHead2({ registrationHead2, dispatch, props }) {
  useInjectReducer({ key: 'registrationHead2', reducer });
  useInjectSaga({ key: 'registrationHead2', saga });
  const [getdata, setgetdata] = useState(true);
  const [registerItem, setregisterItem] = useState(0);
  const [indexItem, setindexItem] = useState(null);

  const [headG, setheadG] = useState('');
  const [root, setroot] = useState(true);
  const [reward, setreward] = useState(false);
  const [quality_status, setqualitystatus] = useState(false);
  const [delay_status, setdelaystatus] = useState(false);

  //console.log(props.substate.location.state);
  console.log(root, 'root');

  console.log(registrationHead2);

  function validateAvrage(value) {
    if (value >= 50 && value <= 65) return '(نرمال)';
    else if (value >= 45 && value < 50) return '(ضعیف)';
    else if (value >= 35 && value < 45) return '(خیلی ضعیف)';
    else if (value < 35 && value > 0) return '(اشتباه)';
    else if (value > 65) return '(اشتباه)';
    else if (value == 0) return '(ثبت نشده)';
    else return '(ثبت نشده)';
  }

  if (getdata)
    setTimeout(() => {
      setgetdata(false);
      dispatch(
        getData({
          subscribe_id: props.substate.location.state.id,
          status: 'inDo',
        }),
      );
    }, 100);

  const title = (
    <Col xs={12} sm={12} md={12} xl={12} className="title">
      {' ثبت سرگل ' + props.substate.location.state.name}
    </Col>
  );

  const showList = (
    <Row>
      {registrationHead2.data.length == 0 ? (
        <Col xs={12} sm={12} md={12} xl={12} className="form">
          اطلاعاتی یافت نشد
        </Col>
      ) : (
        registrationHead2.data.map((item, index) => (
          <Col xs={12} sm={12} md={12} xl={12} key={item.id}>
            <Row
              className="registrationHeadItem"
              onClick={() => {
                if (item.id != registerItem) {
                  setindexItem(index);
                  setregisterItem(item.id);
                  setheadG(item.headG);
                  item.root == null ? setroot('1') : setroot(item.root);
                }
              }}
            >
              <Col xs={12} sm={12} md={12} xl={12}>
                {item.date_in_str.slice(0, 4) +
                  '/' +
                  item.date_in_str.slice(5, 7) +
                  '/' +
                  item.date_in_str.slice(8, 10)}
              </Col>
              <Col xs={4} sm={4} md={4} xl={4}>
                <p className="feildName">گل : </p>
                {item.flowerKg_kg}
              </Col>

              <Col xs={8} sm={8} md={8} xl={8}>
                <p className="feildName">
                  قیمت{' '}
                  {'(' + (item.root == '1' ? 'با ریشه' : 'بدون ریشه') + ')'} :{' '}
                </p>
                {item.price}
              </Col>
              <Col xs={4} sm={4} md={4} xl={4}>
                <p className="feildName">سرگل : </p>
                {item.headG}
              </Col>
              <Col xs={8} sm={8} md={8} xl={8}>
                <p className="feildName">
                  {'عیار' + validateAvrage(Math.round(item.average)) + ':'}{' '}
                </p>
                {Math.round(item.average)}
              </Col>
              {registerItem == item.id && (
                <Col xs={12} sm={12} md={12} xl={12}>
                  <Row>
                    <Col xs={4} sm={4} md={4} xl={4} className="fieldItem">
                      <Form.Label>
                        <p className="feildName">{'سرگل(گرم)'} </p>
                      </Form.Label>
                    </Col>
                    <Col xs={8} sm={8} md={8} xl={8} className="fieldItem">
                      <InputGroup hasValidation>
                        <Form.Control
                          style={{ width: '100%' }}
                          isValid={
                            headG / item.flowerKg_kg >= 35 &&
                            headG / item.flowerKg_kg <= 65
                          }
                          isInvalid={
                            headG / item.flowerKg_kg < 35 ||
                            headG / item.flowerKg_kg > 65
                          }
                          size="sm"
                          defaultValue={item.headG ? null : item.headG}
                          type="number"
                          placeholder="وزن "
                          onChange={e => setheadG(e.target.value)}
                        />
                        <Form.Control.Feedback type="invalid">
                          {headG == 0
                            ? 'وزن وارد نشده'
                            : 'مقدار وارد شده غیر قابل پذیرش است'}
                        </Form.Control.Feedback>
                        <Form.Control.Feedback type="valid">
                          {validateAvrage(headG / item.flowerKg_kg)}
                        </Form.Control.Feedback>
                      </InputGroup>
                    </Col>

                    <Col xs={12} sm={6} md={6} xl={6} className="fieldItem">
                      <FormGroup>
                        <FormControlLabel
                          control={
                            <Checkbox
                              defaultChecked={item.root == '1'}
                              onChange={e =>
                                e.target.checked == true
                                  ? setroot(1)
                                  : setroot(0)
                              }
                            />
                          }
                          label="ریشه تحویل شد"
                        />
                      </FormGroup>
                    </Col>
                    <Col xs={12} sm={6} md={6} xl={6} className="fieldItem">
                      <FormGroup>
                        <FormControlLabel
                          control={
                            <Checkbox
                              defaultChecked={false}
                              onChange={e =>
                                e.target.checked == true
                                  ? setreward(1)
                                  : setreward(0)
                              }
                            />
                          }
                          label="اعمال پاداش"
                        />
                      </FormGroup>
                    </Col>
                    <Col xs={12} sm={12} md={6} xl={6} className="fieldItem">
                      <FormGroup
                        style={{ display: 'block', textAlign: 'right' }}
                      >
                        کیفیت انجام:
                        <FormControlLabel
                          style={{
                            flexDirection: 'row',
                            direction: 'ltr',
                            marginRight: '30px',
                          }}
                          control={
                            <RadioGroup
                              row
                              aria-label="gender"
                              defaultValue="unset"
                              name="radio-buttons-group"
                              onChange={e => setqualitystatus(e.target.value)}
                            >
                              <FormControlLabel
                                value="0"
                                control={<Radio />}
                                label="کثیف"
                              />
                              <FormControlLabel
                                value="unset"
                                control={<Radio />}
                                label="متوسط"
                              />
                              <FormControlLabel
                                value="1"
                                control={<Radio />}
                                label="تمیز"
                              />
                            </RadioGroup>
                          }
                          label=""
                          labelPlacement="start"
                        />
                      </FormGroup>
                    </Col>
                    <Col xs={12} sm={12} md={6} xl={6} className="fieldItem">
                      <FormGroup
                        style={{ display: 'block', textAlign: 'right' }}
                      >
                        زمان انجام :{' '}
                        <FormControlLabel
                          style={{
                            flexDirection: 'row',
                            direction: 'ltr',
                            marginRight: '30px',
                          }}
                          control={
                            <RadioGroup
                              row
                              aria-label="gender"
                              defaultValue="unset"
                              name="radio-buttons-group"
                              onChange={e => setdelaystatus(e.target.value)}
                            >
                              <FormControlLabel
                                value="0"
                                control={<Radio />}
                                label="زود"
                              />
                              <FormControlLabel
                                value="unset"
                                control={<Radio />}
                                label="متوسط"
                              />

                              <FormControlLabel
                                value="1"
                                control={<Radio />}
                                label="دیر"
                              />
                            </RadioGroup>
                          }
                          label=""
                          labelPlacement="start"
                        />
                      </FormGroup>
                    </Col>
                    <Col xs={12} sm={12} md={12} xl={12} className="fieldItem">
                      <Button
                        disabled={
                          headG <= 0 ||
                          (headG / item.flowerKg_kg < 35 ||
                            headG / item.flowerKg_kg > 65)
                        }
                        onClick={() => {
                          setregisterItem(0);
                          dispatch(
                            putData({
                              id: item.id,
                              root,
                              headG,
                              reward,
                              delay_status,
                              quality_status,
                            }),
                          );
                        }}
                        variant="warning"
                        size="sm"
                        style={{ width: '100%' }}
                      >
                        ثبت
                      </Button>
                    </Col>
                  </Row>
                </Col>
              )}
            </Row>
          </Col>
        ))
      )}
    </Row>
  );

  const successModal =
    indexItem == null ? null : (
      <div className="modalBack">
        <Row className="form">
          <Col className="successTitle" xs={12} sm={12} md={12} xl={12}>
            عملیات موفق
            <CheckCircleOutlineIcon />
          </Col>
          <Col className="modalBody" xs={12} sm={12} md={12} xl={12}>
            <Row>
              <Col className="fieldItem" xs={4} sm={4} md={6} xl={6}>
                <p className="feildName">گل : </p>
                {registrationHead2.data[indexItem].flowerKg_kg}
              </Col>

              <Col className="fieldItem" xs={8} sm={8} md={6} xl={6}>
                <NumberFormat
                  value={registrationHead2.data[indexItem].price}
                  displayType={'text'}
                  thousandSeparator={true}
                  renderText={value => (
                    <div>
                      {' '}
                      <p className="feildName">
                        قیمت{' '}
                        {'(' +
                          (registrationHead2.data[indexItem].root == '1'
                            ? 'با ریشه'
                            : 'بدون ریشه') +
                          ')'}{' '}
                        :{' '}
                      </p>
                      {value}
                    </div>
                  )}
                />
              </Col>

              <Col className="fieldItem" xs={4} sm={4} md={6} xl={6}>
                <p className="feildName">سرگل : </p>
                {registrationHead2.data[indexItem].headG}
              </Col>
              <Col className="fieldItem" xs={8} sm={8} md={6} xl={6}>
                <p className="feildName">
                  {'عیار' +
                    validateAvrage(
                      Math.round(registrationHead2.data[indexItem].average),
                    ) +
                    ':'}{' '}
                </p>
                {Math.round(registrationHead2.data[indexItem].average)}
              </Col>
              <Col className="fieldItem" xs={6} sm={6} md={6} xl={6}>
                <p className="feildName">پاداش : </p>
                {registrationHead2.data[indexItem].reward == '0'
                  ? 'ندارد'
                  : 'دارد'}
              </Col>
              <Col className="fieldItem" xs={12} sm={12} md={12} xl={12}>
                <NumberFormat
                  value={
                    registrationHead2.data[indexItem].flowerKg_kg *
                    registrationHead2.data[indexItem].price
                  }
                  displayType={'text'}
                  thousandSeparator={true}
                  renderText={value => (
                    <div>
                      {' '}
                      <p className="feildName">{'حق الزحمه:'} </p>
                      {value}
                    </div>
                  )}
                />
              </Col>
            </Row>
          </Col>
          <Col xs={6} sm={6} md={6} xl={6}>
            <Link
              className="textIcons"
              to={{
                pathname: '/RegistrationHead',
              }}
            >
              <Button variant="warning" style={{ width: '150px' }}>
                برگشت
              </Button>
            </Link>
          </Col>
          <Col xs={6} sm={6} md={6} xl={6}>
            <Button
              style={{ width: '150px' }}
              variant="warning"
              onClick={() => {
                setregisterItem(0);
                setindexItem(null);
                dispatch(
                  getData({
                    subscribe_id: props.substate.location.state.id,
                    status: 'inDo',
                  }),
                );
              }}
            >
              ماندن در صفحه
            </Button>
          </Col>
        </Row>
      </div>
    );
  return (
    <div>
      <Helmet>
        <title>ثبت سرگل</title>
        <meta name="description" content="Description of RegistrationHead2" />
      </Helmet>
      {title}
      {showList}

      {registrationHead2.alertSucccess && registrationHead2.alertSucccess}
      {registrationHead2.alertSucccess && successModal}
    </div>
  );
}

RegistrationHead2.propTypes = {
  dispatch: PropTypes.func.isRequired,
  registrationHead2: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  registrationHead2: makeSelectRegistrationHead2(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(RegistrationHead2);
