// import { selectRegistrationHead2Domain } from '../selectors';

describe('selectRegistrationHead2Domain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
