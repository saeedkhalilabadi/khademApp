/*
 *
 * Login reducer
 *
 */
import produce from 'immer';
import {
  FETCH_USER_ACTION,
  FETCH_USER_SUCCESS_ACTION,
  FETCH_USER_FAIL_ACTION,
  changedusername,
  changedpassword,
  set_ALERT,
  set_LOCATION,
  SET_SHOW_ITEM,
  SET_CODE,
  GET_CAPTCHA,
  GET_CAPTCHA_ERROR,
  GET_CAPTCHA_SUCCESS,
} from './constants';

export const initialState = {
  load: 0,
  showItem: 0,
  long: 0,
  latu: 0,
  alert: {
    massage: '',
    status: '0',
  },
  userpassword: null,
  code: null,
  captcha: null,
  username: null,
  userId: null,
  user: null,
  error: null,
};

/* eslint-disable default-case, no-param-reassign */
const loginReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case GET_CAPTCHA:
        break;
      case GET_CAPTCHA_SUCCESS:
        draft.captcha = action.data.data;
        break;
      case GET_CAPTCHA_ERROR:
        break;
      case SET_CODE:
        draft.code = action.data;
        break;

      case SET_SHOW_ITEM:
        draft.showItem = action.value;

        break;

      case FETCH_USER_ACTION:
        draft.load = 0;
        break;

      case FETCH_USER_SUCCESS_ACTION:
        draft.userId = null;
        draft.error = null;
        draft.user = action.user;
        draft.load = 0;

        break;

      case FETCH_USER_FAIL_ACTION:
        draft.userId = null;
        draft.error = action.error;
        draft.user = null;
        draft.alert.massage = 'کلمه عبور یا نام کاربری اشتباه است!!!!!!';
        draft.alert.status = 'error';
        draft.load = 0;

        break;
      case changedpassword:
        draft.userpassword = action.value;
        draft.error = null;
        draft.user = null;
        draft.userId = null;
        break;
      case changedusername:
        draft.username = action.value;
        draft.error = null;
        draft.user = null;
        draft.userId = null;
        break;
      case set_ALERT:
        draft.alert.status = '0';
        break;
      case set_LOCATION:
        draft.latu = action.location.latu;
        draft.long = action.location.long;
    }
  });

export default loginReducer;
