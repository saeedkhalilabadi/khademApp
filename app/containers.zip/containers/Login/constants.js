/*
 *
 * Login constants
 *
 */

export const FETCH_USER_ACTION = 'app/Login/FETCH_USER_ACTION';
export const FETCH_USER_SUCCESS_ACTION = 'app/Login/FETCH_USER_SUCCESS_ACTION';
export const FETCH_USER_FAIL_ACTION = 'app/Login/FETCH_USER_FAIL_ACTION';
export const changedusername = 'app/Login/changedusername';
export const changedpassword = 'app/Login/changedpassword';
export const set_ALERT = 'app/Login/set_ALERT';
export const set_LOCATION = 'app/Login/set_LOCATION';
export const SET_SHOW_ITEM = 'app/Login/SET_SHOW_ITEM';
export const SET_CODE = 'app/Login/SET_CODE';

export const GET_CAPTCHA = 'app/Login/GET_CAPTCHA';
export const GET_CAPTCHA_SUCCESS = 'app/Login/GET_CAPTCHA_SUCCESS';
export const GET_CAPTCHA_ERROR = 'app/Login/GET_CAPTCHA_ERROR';
