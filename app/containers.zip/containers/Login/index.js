/**
 *
 * Login
 *
 */

import React, { memo, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { createStructuredSelector } from 'reselect';
import Loading from 'components/Loading/Loadable';
import { compose } from 'redux';
import axios from 'containers/axios/base';
import { Link, useHistory } from 'react-router-dom';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import { Button, Form, Col, Row, Navbar, Nav } from 'react-bootstrap';
import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import HomeSharpIcon from '@mui/icons-material/HomeSharp';
import TextField from '@mui/material/TextField';
import makeSelectLogin from './selectors';
import { FcSynchronize } from 'react-icons/fc';
import {
  setShowItem,
  setAlert,
  setLocation,
  fetchUserAction,
  changedPassword,
  changedUsername,
  getCaptcha,
  setCode,
} from './actions';
import reducer from './reducer';
import saga from './saga';
import { makeStyles } from '@mui/styles';
import clsx from 'clsx';
import './index.css';

const key = 'login';

const useStyles = makeStyles({
  root: {
    display: 'flex',
    flexWrap: 'wrap',
  },

  margin: {
    margin: 'auto',
  },
  withoutLabel: {
    marginTop: '0px',
  },
  textField: {
    width: '25ch',
  },
  button: {
    margin: '20px',
  },
});

function getWindowDimensions() {
  const { innerWidth: width, innerHeight: height } = window;
  return {
    width,
    height,
  };
}

export function Login({ dispatch, data }) {
  useInjectReducer({ key, reducer });
  useInjectSaga({ key, saga });
  // console.log(data);
  const classes = useStyles();
  const [windowDimensions, setWindowDimensions] = useState(
    getWindowDimensions(),
  );

  useEffect(() => {
    function handleResize() {
      setWindowDimensions(getWindowDimensions());
    }

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const [open, setOpen] = useState(true);
  const [item, setitem] = useState(0);

  const [mobile, setmobile] = useState('');
  const [melicode, setmelicode] = useState('');
  const [verifycode, setverifycode] = useState('');
  const [newpass, setnewpass] = useState('');
  const [Rnewpass, setRnewpass] = useState('');
  const [number, setnumber] = useState('');

  // console.log(navigator.geolocation.getCurrentPosition, 'hello1');
  //navigator.geolocation.getCurrentPosition(function(position) {
  // console.log('Latitude is :', position);
  // });
  // if (data.long == 0) {
  // navigator.geolocation.getCurrentPosition(function(position) {
  // console.log('خطا بر حسب متر :', position.coords.accuracy);
  //console.log('میوقعیت :', position.coords);

  // if (position.coords.accuracy < 100) {
  //   dispatch(
  //     setLocation({
  //       latu: position.coords.latitude,
  //       long: position.coords.longitude,
  //      }),
  //      );
  //    }
  //   });
  // }

  if (!data.captcha) {
    dispatch(getCaptcha());
  }
  function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }

  if (data.alert.status == '0');
  else setTimeout(() => dispatch(setAlert(0)), 6000);

  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen(false);
  };

  const form = (
    <div>
      <div className="backgrand">
        <img
          src={require('../../images/logo.png')}
          style={{ width: '250px', marginTop: '0px' }}
        />

        <Col className="login-page">
          <Form.Control
            style={{ direction: 'rtl', borderRadius: '25px' }}
            type="text"
            placeholder="نام کاربری خود را وارد نمایید"
            onChange={e => dispatch(changedUsername(e.target.value))}
          />{' '}
          <br />
          <Form.Control
            style={{ direction: 'rtl', borderRadius: '25px' }}
            type="password"
            placeholder="کلمه عبور خود را وارد کنید"
            onChange={e => dispatch(changedPassword(e.target.value))}
          />
          <Row style={{ marginTop: '20px' }}>
            <Col>
              <Button variant="light" onClick={() => dispatch(getCaptcha())}>
                <FcSynchronize style={{ fontSize: '30px' }} />
              </Button>
            </Col>

            <Col>
              <img src={data.captcha == null ? null : data.captcha.image} />
            </Col>
          </Row>
          <br />
          <Form.Control
            style={{ direction: 'rtl', borderRadius: '25px' }}
            type="text"
            placeholder="کد را وارد کنید"
            onChange={e => dispatch(setCode(e.target.value))}
          />
          <Row className="login_botton">
            <Col sm="5" className="btn">
              <Button
                onClick={() => {
                  dispatch(fetchUserAction(data));
                }}
                variant="outline-warning"
              >
                ورود{' '}
              </Button>
            </Col>
            <Col sm="5" className="btn">
              <Button variant="outline-warning" onClick={() => setitem(1)}>
                فراموشی رمز عبور{' '}
              </Button>
            </Col>
          </Row>
        </Col>
      </div>
    </div>
  );

  const resetform = (
    <Row>
      <Col
        sm={12}
        style={{
          direction: 'ltr',
          color: 'yellow',
          fontSize: '20px',
          fontWeight: 'bold',
          margin: 'auto',
          textAlign: 'center',
          marginTop: '80px',
        }}
      >
        : بازیابی اطلاعات کاربری
      </Col>

      <Col sm={12} style={{ textAlign: 'center', marginTop: '20px' }}>
        <Form.Control
          style={{
            direction: 'rtl',
            borderRadius: '25px',
            maxWidth: '400px',
            margin: 'auto',
          }}
          type="number"
          placeholder="شماره همراه خود را وارد نمایید"
          onChange={e => setmobile(e.target.value)}
        />
      </Col>
      <Col sm={12} style={{ marginTop: '20px' }}>
        <Form.Control
          style={{
            direction: 'rtl',
            borderRadius: '25px',
            maxWidth: '400px',
            margin: 'auto',
          }}
          type="number"
          placeholder="کد ملی خود را وارد کنید"
          onChange={e => setmelicode(e.target.value)}
        />
      </Col>
      <Col sm={12} style={{ textAlign: 'center', marginTop: '20px' }}>
        <Button
          disabled={mobile.length < 11 || melicode.length < 10}
          variant="warning"
          style={{ margin: 'auto', minWidth: '200px' }}
          onClick={() => setitem(2)}
        >
          بازیابی
        </Button>
      </Col>
    </Row>
  );
  const GetCode = (
    <Row>
      <Col
        sm={12}
        style={{
          direction: 'ltr',
          color: 'yellow',
          fontSize: '20px',
          fontWeight: 'bold',
          margin: 'auto',
          textAlign: 'center',
          marginTop: '80px',
        }}
      >
        :کد ارسال شده به موبایل خود را وارد کنید
      </Col>

      <Col sm={12} style={{ textAlign: 'center', marginTop: '20px' }}>
        <Form.Control
          style={{
            direction: 'rtl',
            borderRadius: '25px',
            maxWidth: '400px',
            margin: 'auto',
          }}
          onChange={e => setverifycode(e.target.value)}
          type="number"
          placeholder="کد را وارد کنید"
        />
      </Col>

      <Col sm={12} style={{ textAlign: 'center', marginTop: '20px' }}>
        <Button
          disabled={verifycode.length < 5}
          variant="warning"
          style={{ margin: 'auto', minWidth: '200px' }}
          onClick={() => setitem(3)}
        >
          ارسال
        </Button>
      </Col>
    </Row>
  );
  const GetNewPassword = (
    <Row>
      <Col
        sm={12}
        style={{
          direction: 'ltr',
          color: 'yellow',
          fontSize: '20px',
          fontWeight: 'bold',
          margin: 'auto',
          textAlign: 'center',
          marginTop: '80px',
        }}
      >
        : کلمه عبور جدید را وارد کنید
      </Col>

      <Col sm={12} style={{ textAlign: 'center', marginTop: '20px' }}>
        <Form.Control
          style={{
            direction: 'rtl',
            borderRadius: '25px',
            maxWidth: '400px',
            margin: 'auto',
          }}
          type="password"
          placeholder="کلمه عبور جدید را وارد کنید"
          onChange={e => setnewpass(e.target.value)}
        />
      </Col>
      <Col sm={12} style={{ textAlign: 'center', marginTop: '20px' }}>
        <Form.Control
          style={{
            direction: 'rtl',
            borderRadius: '25px',
            maxWidth: '400px',
            margin: 'auto',
          }}
          type="password"
          placeholder="تکرار کلمه عبور جدید را وارد کنید"
          onChange={e => setRnewpass(e.target.value)}
        />
      </Col>

      <Col sm={12} style={{ textAlign: 'center', marginTop: '20px' }}>
        <Button
          variant="warning"
          style={{ margin: 'auto', minWidth: '200px' }}
          disabled={newpass !== Rnewpass || newpass.length < 5}
        >
          ذخیره
        </Button>
      </Col>
    </Row>
  );
  return (
    <div>
      <Helmet>
        <title>ورود</title>
      </Helmet>

      {data.load == 1 ? <Loading /> : null}
      <Snackbar
        open={data.alert.status != '0'}
        autoHideDuration={6000}
        onClose={handleClose}
      >
        <Alert onClose={handleClose} severity={data.alert.status}>
          {data.alert.massage}{' '}
        </Alert>
      </Snackbar>
      <Navbar className="navbar">
        <a href="https://applift.ir">
          <HomeSharpIcon style={{ fontSize: '30px' }} />
        </a>
        <Nav.Link href="#features" />
        <img
          src={require('../../images/logo.png')}
          style={{
            position: 'fixed',
            width: '60px',
            left: '10px',
            top: '-3px',
          }}
        />
      </Navbar>

      {item == 0 ? form : <div />}
      {item == 1 ? resetform : <div />}
      {item == 2 ? GetCode : <div />}
      {item == 3 ? GetNewPassword : <div />}
    </div>
  );
}
Login.propTypes = {
  dispatch: PropTypes.func.isRequired,
  data: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  data: makeSelectLogin(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(Login);
