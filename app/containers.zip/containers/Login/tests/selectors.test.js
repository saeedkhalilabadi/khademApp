// import { selectLoginDomain } from '../selectors';

describe('selectLoginDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
