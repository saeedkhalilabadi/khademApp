/*
 *
 * Login actions
 *
 */

import {
  FETCH_USER_ACTION,
  FETCH_USER_SUCCESS_ACTION,
  FETCH_USER_FAIL_ACTION,
  changedusername,
  changedpassword,
  set_ALERT,
  set_LOCATION,
  SET_SHOW_ITEM,
  SET_CODE,
  GET_CAPTCHA,
  GET_CAPTCHA_ERROR,
  GET_CAPTCHA_SUCCESS,
} from './constants';

export function getCaptcha() {
  return {
    type: GET_CAPTCHA,
  };
}
export function getCaptchaSuccess(data) {
  return {
    type: GET_CAPTCHA_SUCCESS,
    data,
  };
}
export function getCaptchaError(data) {
  return {
    type: GET_CAPTCHA_ERROR,
    data,
  };
}

export function setCode(data) {
  return {
    type: SET_CODE,
    data,
  };
}
export function changedPassword(value) {
  return {
    type: changedpassword,
    value,
  };
}
export function changedUsername(value) {
  return {
    type: changedusername,
    value,
  };
}
export function fetchUserAction(data) {
  return {
    type: FETCH_USER_ACTION,
    data,
  };
}

export function fetchUserSuccessAction(user) {
  return {
    type: FETCH_USER_SUCCESS_ACTION,
    user,
  };
}

export function fetchUserFailAction(error) {
  return {
    type: FETCH_USER_FAIL_ACTION,
    error,
  };
}
export function setAlert(i) {
  return {
    type: set_ALERT,
    i,
  };
}
export function setLocation(location) {
  return {
    type: set_LOCATION,
    location,
  };
}
export function setShowItem(value, data) {
  return {
    type: SET_SHOW_ITEM,
    data,
    value,
  };
}
