import { take, call, put, select, takeLatest } from 'redux-saga/effects';
import axios from '../axios/base';
import { FETCH_USER_ACTION, GET_CAPTCHA } from './constants';
import {
  fetchUserFailAction,
  getCaptchaError,
  getCaptchaSuccess,
} from './actions';
import { GetUserDataSuccess1 } from '../Routes/actions';

export function* getUserDataFromServer(data) {
  let e = 0;
  let userdata = 0;
  const d = {
    username: data.data.username,
    password: data.data.userpassword,
    token: data.data.captcha.token,
    security: data.data.code,
    long: data.data.long,
    latu: data.data.latu,
  };
  //console.log(d);
  yield axios
    .post('/api/logindev', d)
    .then(response => {
      console.log(response.data.data, 'response');
      const userData = {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        Authorization: 'Bearer ' + response.data.data.token,
      };
      localStorage.setItem('userData', JSON.stringify(userData));
      userdata = response.data.data.userdata;
      // console.log(response.data.data.userData, 'res');
      e = 1;
    })
    .catch(error => {
      userdata = error;
      console.log(error.response);
    });
  if (e == 1) yield put(GetUserDataSuccess1(userdata));
  else yield put(fetchUserFailAction(userdata));
}
export function* getcaptcha() {
  let e = 0;
  let data = 0;
  yield axios
    .get('/api/captcha')
    .then(response => {
     // console.log(response);
      data = response;
      e = 1;
    })
    .catch(error => {
      data = error;
     // console.log(error.response);
    });
  if (e == 1) yield put(getCaptchaSuccess(data));
  else yield put(getCaptchaError(data));
}

// yield put(fetchUserFailAction('some errors happend!'));

// Individual exports for testing
export default function* login() {
  // yield takeLatest(GetUserData, getToken);
  yield takeLatest(FETCH_USER_ACTION, getUserDataFromServer);
  yield takeLatest(GET_CAPTCHA, getcaptcha);
}
