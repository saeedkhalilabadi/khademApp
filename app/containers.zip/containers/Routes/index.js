/**
 *
 * Routes
 *
 */

import React, { ReactDOM, memo, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import { Switch, Route, Redirect } from 'react-router-dom';
import Login from 'containers/Login/Loadable';
import Employee from 'containers/Employee/Loadable';
import Employees from 'containers/Employees/Loadable';
import EmployeeDistribution from 'containers/EmployeeDistribution/Loadable';
import EmployeeBagRegister from 'containers/EmployeeBagRegister/Loadable';
import AdminBagRegister from 'containers/AdminBagRegister/Loadable';
import SelectSubDectrbution from 'containers/SelectSubDectrbution/Loadable';
import AddEmployee from 'containers/AddEmployee/Loadable';
import EmployeeSales from 'containers/EmployeeSales/Loadable';
import EmployeeEdit from 'containers/EmployeeEdit/Loadable';
import Dashbord from 'containers/Dashbord/Loadable';
import EmployeeDashbord from 'containers/EmployeeDashbord/Loadable';
import RegistrationHead from 'containers/RegistrationHead/Loadable';
import RegistrationHead2 from 'containers/RegistrationHead2/Loadable';
import EmployeeFinancialReport from 'containers/EmployeeFinancialReport/Loadable';
import NewSubscription from 'containers/NewSubscription/Loadable';
import SubEdit from 'containers/SubEdit/Loadable';
import Subscraptions from 'containers/Subscraptions/Loadable';
import EmployeeLists from 'containers/EmployeeLists/Loadable';
import EmployeeList from 'containers/EmployeeList/Loadable';
import AdminSetting from 'containers/AdminSetting/Loadable';
import PaymentRegistr from 'containers/PaymentRegistr/Loadable';
import PaymentRegistr2 from 'containers/PaymentRegistr2/Loadable';
import SubCheckout from 'containers/SubCheckout/Loadable';
import BrancheDistributionReport from 'containers/BrancheDistributionReport/Loadable';
import BranchAnalyticalReportShow from 'containers/BranchAnalyticalReportShow/Loadable';
import BranchAnalyticalReport from 'containers/BranchAnalyticalReport/Loadable';
import WetHeadRegister from 'containers/WetHeadRegister/Loadable';
import ShowAndSubmitList from 'containers/ShowAndSubmitList/Loadable';
import AdminScoreSetting from 'containers/AdminScoreSetting/Loadable';
import SelectOpenedLists from '../SelectOpenedLists';
import BrancheMenu from 'containers/BrancheMenu/loadable';
import Verify from 'containers/Verify/Loadable';
import AdminMenu from 'containers/AdminMenu/Loadable';
import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import ShowSubscraption from '../ShowSubscraption/Loadable';
import makeSelectRoutes from './selectors';
import reducer from './reducer';
import saga from './saga';
import { GetUserData } from './actions';
import './index.css';

function getWindowDimensions() {
  const { innerWidth: width, innerHeight: height } = window;
  return {
    width,
    height,
  };
}

export function Routes({ dispatch, data1 }) {
  useInjectReducer({ key: 'routes', reducer });
  useInjectSaga({ key: 'routes', saga });
  const [user, setuser] = useState(false);

  const [windowDimensions, setWindowDimensions] = useState(
    getWindowDimensions(),
  );

  useEffect(() => {
    function handleResize() {
      setWindowDimensions(getWindowDimensions());
    }

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // console.log(windowDimensions, 'screen');

  setTimeout(() => {
    if (!user) {
      dispatch(GetUserData());
      setuser(true);
    }
  }, 100);

  /* let userData =
    !data1.userData == -1
      ? null
      : {
          name: data1.userData.name + ' ' + data1.userData.lname,
          pic: data1.userData.pic,
        };

        */
  const publicRoutes = (
    <Switch>
      <Route
        exact
        path="/login"
        render={substate => (
          <div>
            <Login props={(substate, data1)} className="login" />
          </div>
        )}
      />
      <Route
        exact
        path="/Verify"
        render={substate => (
          <div>
            <Verify props={(substate, data1)} className="login" />
          </div>
        )}
      />

      <Redirect to="/Verify" />
    </Switch>
  );

  const managmer = (
    <Switch>
      <Route
        exact
        path="/Dashbord"
        render={substate => (
          <div>
            <AdminMenu props={{ subject: 'Dashbord', data1 }} />
            <Dashbord
              props={{ screen: windowDimensions, subject: 'Dashbord' }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/BrancheDistributionReport"
        render={substate => (
          <div>
            <AdminMenu
              props={{ subject: 'BrancheDistributionReport', data1 }}
            />
            <BrancheDistributionReport
              props={{
                substate,
                screen: windowDimensions,
                subject: 'BrancheDistributionReport',
              }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/BranchAnalyticalReport"
        render={substate => (
          <div>
            <AdminMenu
              props={{ subject: 'BranchAnalyticalReport', data1 }}
            />
            <BranchAnalyticalReport
              props={{
                substate,
                screen: windowDimensions,
                subject: 'BranchAnalyticalReport',
              }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/BranchAnalyticalReportShow"
        render={substate => (
          <div>
            <AdminMenu
              props={{ subject: 'BranchAnalyticalReportShow', data1 }}
            />
            <BranchAnalyticalReportShow
              props={{
                substate,
                screen: windowDimensions,
                subject: 'BranchAnalyticalReportShow',
              }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/AdminScoreSetting"
        render={substate => (
          <div>
            <AdminMenu props={{ subject: 'AdminScoreSetting', data1 }} />
            <AdminScoreSetting
              props={{
                substate,
                screen: windowDimensions,
                subject: 'AdminScoreSetting',
              }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/WetHeadRegister"
        render={substate => (
          <div>
            <AdminMenu props={{ subject: 'WetHeadRegister', data1 }} />
            <WetHeadRegister
              props={{
                substate,
                screen: windowDimensions,
                subject: 'WetHeadRegister',
              }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/PaymentRegistr"
        render={substate => (
          <div>
            <AdminMenu props={{ subject: 'PaymentRegistr', data1 }} />
            <PaymentRegistr
              props={{
                substate,
                screen: windowDimensions,
                subject: 'PaymentRegistr',
              }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/PaymentRegistr2"
        render={substate => (
          <div>
            <AdminMenu props={{ subject: 'PaymentRegistr2', data1 }} />
            <PaymentRegistr2
              props={{
                substate,
                screen: windowDimensions,
                subject: 'PaymentRegistr2',
              }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/SubCheckout"
        render={substate => (
          <div>
            <AdminMenu props={{ subject: 'SubCheckout', data1 }} />
            <SubCheckout
              props={{
                substate,
                screen: windowDimensions,
                subject: 'SubCheckout',
              }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/AdminSetting"
        render={substate => (
          <div>
            <AdminMenu props={{ subject: 'AdminSetting', data1 }} />
            <AdminSetting
              props={{
                substate,
                screen: windowDimensions,
                subject: 'AdminSetting',
              }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/BagRegister"
        render={substate => (
          <div>
            <AdminMenu props={{ subject: 'BagRegister', data1 }} />
            <AdminBagRegister
              props={{ screen: windowDimensions, subject: 'BagRegister' }}
            />
          </div>
        )}
      />

      <Route
        exact
        path="/addemployee"
        render={substate => (
          <div>
            <AdminMenu props={{ subject: 'addemployee', data1 }} />
            <AddEmployee
              props={{ screen: windowDimensions, subject: 'addemployee' }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/employees"
        render={substate => (
          <div>
            <AdminMenu props={{ subject: 'employees', data1 }} />
            <Employees
              props={{ screen: windowDimensions, subject: 'employees' }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/employee"
        render={substate => (
          <div>
            <AdminMenu props={{ subject: 'employee', data1 }} />
            <Employee
              props={{
                substate,
                screen: windowDimensions,
                subject: 'employee',
              }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/employeeEdit"
        render={substate => (
          <div>
            <AdminMenu props={{ subject: 'employee', data1 }} />
            <EmployeeEdit
              props={{
                substate,
                screen: windowDimensions,
                subject: 'employee',
              }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/employeeList"
        render={substate => (
          <div>
            <AdminMenu props={{ subject: 'employee', data1 }} />
            <EmployeeList
              props={{
                substate,
                screen: windowDimensions,
                subject: 'employee',
              }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/Sub"
        render={substate => (
          <div>
            <BrancheMenu props={{ subject: 'Subs', data1 }} />
            <ShowSubscraption
              props={{
                substate,
                screen: windowDimensions,
                subject: 'sub',
              }}
            />
          </div>
        )}
      />

      <Redirect to="/Dashbord" />
    </Switch>
  );

  const employee = (
    <Switch>
      <Route
        exact
        path="/Dashbord"
        render={substate => (
          <div>
            <BrancheMenu props={{ subject: 'Dashbord', data1 }} />
            <EmployeeDashbord
              props={{ screen: windowDimensions, subject: 'Dashbord' }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/PaymentRegistr"
        render={substate => (
          <div>
            <BrancheMenu props={{ subject: 'PaymentRegistr', data1 }} />
            <PaymentRegistr
              props={{
                substate,
                screen: windowDimensions,
                subject: 'PaymentRegistr',
              }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/PaymentRegistr2"
        render={substate => (
          <div>
            <BrancheMenu props={{ subject: 'PaymentRegistr2', data1 }} />
            <PaymentRegistr2
              props={{
                substate,
                screen: windowDimensions,
                subject: 'PaymentRegistr2',
              }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/SubCheckout"
        render={substate => (
          <div>
            <BrancheMenu props={{ subject: 'SubCheckout', data1 }} />
            <SubCheckout
              props={{
                substate,
                screen: windowDimensions,
                subject: 'SubCheckout',
              }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/NewSub"
        render={substate => (
          <div>
            <BrancheMenu props={{ subject: 'NewSub', data1 }} />
            <NewSubscription
              props={{ screen: windowDimensions, subject: 'NewSub' }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/SelectOpenedLists"
        render={substate => (
          <div>
            <BrancheMenu props={{ subject: 'selectSubDes', data1 }} />
            <SelectOpenedLists
              props={{ screen: windowDimensions, subject: 'NewSub' }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/SelectSubDectrbution"
        render={substate => (
          <div>
            <BrancheMenu props={{ subject: 'selectSubDes', data1 }} />
            <SelectSubDectrbution
              props={{ screen: windowDimensions, subject: 'NewSub', substate }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/Subs"
        render={substate => (
          <div>
            <BrancheMenu props={{ subject: 'Subs', data1 }} />
            <Subscraptions
              props={{ screen: windowDimensions, subject: 'Subs' }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/Sub"
        render={substate => (
          <div>
            <BrancheMenu props={{ subject: 'Subs', data1 }} />
            <ShowSubscraption
              props={{
                substate,
                screen: windowDimensions,
                subject: 'sub',
              }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/SubEdit"
        render={substate => (
          <div>
            <BrancheMenu props={{ subject: 'Subs', data1 }} />
            <SubEdit
              props={{
                substate,
                screen: windowDimensions,
                subject: 'sub',
              }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/EmployeeFinancialReport"
        render={substate => (
          <div>
            <BrancheMenu props={{ subject: 'Subs', data1 }} />
            <EmployeeFinancialReport
              props={{
                substate,
                screen: windowDimensions,
                subject: 'EmployeeFinancialReport',
              }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/EmployeeLists"
        render={substate => (
          <div>
            <BrancheMenu props={{ subject: 'EmployeeLists', data1 }} />
            <EmployeeLists
              props={{
                substate,
                screen: windowDimensions,
                subject: 'EmployeeLists',
              }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/EmployeeList"
        render={substate => (
          <div>
            <BrancheMenu props={{ subject: 'EmployeeList', data1 }} />
            <EmployeeList
              props={{
                substate,
                screen: windowDimensions,
                subject: 'EmployeeList',
              }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/RegistrationHead"
        render={substate => (
          <div>
            <BrancheMenu props={{ subject: 'RegistrationHead', data1 }} />
            <RegistrationHead
              props={{
                substate,
                screen: windowDimensions,
                subject: 'RegistrationHead',
              }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/RegistrationHead2"
        render={substate => (
          <div>
            <BrancheMenu props={{ subject: 'RegistrationHead2', data1 }} />
            <RegistrationHead2
              props={{
                substate,
                screen: windowDimensions,
                subject: 'RegistrationHead2',
              }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/Sales"
        render={substate => (
          <div>
            <BrancheMenu props={{ subject: 'Sales', data1 }} />
            <EmployeeSales
              props={{
                substate,
                screen: windowDimensions,
                subject: 'EmployeeSales',
              }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/BagRegister"
        render={substate => (
          <div>
            <BrancheMenu props={{ subject: 'BagRegister', data1 }} />
            <EmployeeBagRegister
              props={{ screen: windowDimensions, subject: 'BagRegister' }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/ShowAndSubmitList"
        render={substate => (
          <div>
            <BrancheMenu props={{ subject: 'Distribution', data1 }} />
            <ShowAndSubmitList
              props={{
                substate,
                screen: windowDimensions,
                subject: 'ShowAndSubmitList',
              }}
            />
          </div>
        )}
      />
      <Route
        exact
        path="/Distribution"
        render={substate => (
          <div>
            <BrancheMenu props={{ subject: 'Distribution', data1 }} />
            <EmployeeDistribution
              props={{
                substate,
                screen: windowDimensions,
                subject: 'Distribution',
              }}
            />
          </div>
        )}
      />
      <Redirect to="/Dashbord" />
    </Switch>
  );

  let routes1 = 0;

  //console.log(data1, 'login user');

  switch (data1.userLogin) {
    case 'branche':
      routes1 = employee;
      break;

    case 'manager':
      routes1 = managmer;
      break;

    default:
      routes1 = publicRoutes;
      break;
  }

  return (
    <div
      className="bodyroute"
      style={{
        marginTop: '50px',
        marginRight: windowDimensions.width > 1000 ? '70px' : null,
      }}
    >
      {routes1}
    </div>
  );
}

Routes.propTypes = {
  dispatch: PropTypes.func.isRequired,
  data1: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  routes: makeSelectRoutes(),
  data1: makeSelectRoutes(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(Routes);
