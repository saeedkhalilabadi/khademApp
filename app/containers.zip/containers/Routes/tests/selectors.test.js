// import { selectRoutesDomain } from '../selectors';

describe('selectRoutesDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
