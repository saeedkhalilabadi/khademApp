// import { selectEmployeeArchiveDomain } from '../selectors';

describe('selectEmployeeArchiveDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
