/*
 *
 * EmployeeArchive actions
 *
 */

import { GET_DATA, GET_DATA_ERROR, GET_DATA_SUCCESS } from './constants';

export function getData(data) {
  return {
    type: GET_DATA,
    data,
  };
}
export function getDataSuccess(data) {
  return {
    type: GET_DATA_SUCCESS,
    data,
  };
}
export function getDataError(data) {
  return {
    type: GET_DATA_ERROR,
    data,
  };
}
