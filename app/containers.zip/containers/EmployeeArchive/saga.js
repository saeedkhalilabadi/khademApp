import { takeLatest, call, put, select } from 'redux-saga/effects';
import { GET_DATA } from './constants';
import { getDataSuccess, getDataError } from './actions';
import axios from 'containers/axios/axios-user';

export function* getdata(params) {
  let data;
  let e = null;
  yield axios
    .post('api/deliveres/manager/getdata',params.data, {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      
      data = response.data;
      e = true;
    })
    .catch(error => {
      console.log(error, 'دریافت اطلاعات کارمندان با مشکل مواجه شد');
      data = error.response;
      e = false;
    });
  if (e) yield put(getDataSuccess(data));
  else yield put(getDataError(data));
}

// Individual exports for testing
export default function* employeeArchiveSaga() {
  yield takeLatest(GET_DATA, getdata);
  // See example in containers/HomePage/saga.js
}
