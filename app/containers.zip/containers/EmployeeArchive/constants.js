/*
 *
 * EmployeeArchive constants
 *
 */

export const GET_DATA = 'app/EmployeeArchive/GET_DATA';
export const GET_DATA_SUCCESS = 'app/EmployeeArchive/GET_DATA_SUCCESS';
export const GET_DATA_ERROR = 'app/EmployeeArchive/GET_DATA_ERROR';
