/**
 *
 * EmployeeArchive
 *
 */

import React, { memo,useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { Col, Row, Button, Form } from 'react-bootstrap';

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectEmployeeArchive from './selectors';
import reducer from './reducer';
import saga from './saga';
import NumberFormat from 'react-number-format';
import messages from './messages';
import { getData} from './actions'
export function EmployeeArchive({ employeeArchive, dispatch, props }) {
  useInjectReducer({ key: 'employeeArchive', reducer });
  useInjectSaga({ key: 'employeeArchive', saga });

  const [getdata, setgetdata] = useState(true);
  if (getdata)
  setTimeout(() => {
    setgetdata(false);
    dispatch(getData({
      'branche_id':props.id,
      'status':[2,3]
}));
  }, 200);
  console.log(employeeArchive.data,'ffffff');
  const list = (
    <Row>
      {employeeArchive.data.length == 0 ?
        (<p>اطلاعاتی پیدا نشد</p>) : (
          <>

            {employeeArchive.data && employeeArchive.data.map(payment => (
              <Col xs={12} sm={12} md={12} xl={12} className="payItems" key={payment.id}>
                <Row>
                  <Col xs={6} sm={6} md={3} xl={3}>
                    تاریخ: {payment.date_in_str.slice(0, 4) + '/' + payment.date_in_str.slice(5, 7) + '/' + payment.date_in_str.slice(8, 10)}
                  </Col>
                  <Col xs={6} sm={6} md={2} xl={2}>
                وزن گل تحویل شده: {payment.bags_sum_weight} کیلوگرم
               </Col>
               <Col xs={6} sm={6} md={2} xl={2}>
                وزن گل توزیع شده: {payment.folwerKg} کیلوگرم
               </Col>
               <Col xs={6} sm={6} md={2} xl={2}>
                وزن سرگل دریافتی: {payment.headG} گرم
               </Col>
               <Col xs={6} sm={6} md={3} xl={3}>
                حق الزحمه: <NumberFormat
            value={Number(payment.folwerKg) * Number(employeeArchive.wage)}
            displayType={'text'}
            thousandSeparator={true}
          
            renderText={(value, props) => <span {...props}>{value} تومان</span>}
          />
               </Col> 
               <Col xs={6} sm={6} md={2} xl={2}>
                میانگین سرگل خیس: {payment.head_flower} گرم
               </Col>

               <Col xs={6} sm={6} md={2} xl={2}>
                میانگین سرگل خشک: {payment.wet_head_flower} گرم
               </Col>
                </Row>
              </Col>
            ))}
          </>
        )}
    </Row>
  );
  return (
    <div>
      <Helmet>
        <title>EmployeeArchive</title>
        <meta name="description" content="Description of EmployeeArchive" />
      </Helmet>
      {list}
    </div>
  );
}

EmployeeArchive.propTypes = {
  dispatch: PropTypes.func.isRequired,
  
};

const mapStateToProps = createStructuredSelector({
  employeeArchive: makeSelectEmployeeArchive(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(EmployeeArchive);
