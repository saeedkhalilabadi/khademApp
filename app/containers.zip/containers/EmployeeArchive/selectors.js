import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the employeeArchive state domain
 */

const selectEmployeeArchiveDomain = state =>
  state.employeeArchive || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by EmployeeArchive
 */

const makeSelectEmployeeArchive = () =>
  createSelector(
    selectEmployeeArchiveDomain,
    substate => substate,
  );

export default makeSelectEmployeeArchive;
export { selectEmployeeArchiveDomain };
