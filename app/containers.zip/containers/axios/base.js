import axios from 'axios';

const host = 'https://saffron.jobtimes.ir/api';
const local = 'http://localhost:8000/';
const amini='http://192.168.1.102:8000/';

const instance = axios.create({
  baseURL: host,
  timeout: 20000,
  headers: {
    'content-Type': 'application/json',
    Accept: 'application/json',
  },
});

export default instance;
