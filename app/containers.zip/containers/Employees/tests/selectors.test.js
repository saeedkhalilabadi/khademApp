// import { selectEmployeesDomain } from '../selectors';

describe('selectEmployeesDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
