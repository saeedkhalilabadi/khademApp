/*
 *
 * Employees reducer
 *
 */
import produce from 'immer';
import {
  set_SHOW_ITEM,
  EMPLOYEES_GET_DATA,
  EMPLOYEES_GET_DATA_SUCCESS,
  EMPLOYEES_GET_DATA_ERROR,
  SEARCH,
} from './constants';

export const initialState = {
  load: 0,
  item: 0,
  index: 0,
  data: [],
  employees: [],
  employee: 0,
};

/* eslint-disable default-case, no-param-reassign */
const employeesReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case SEARCH:
        draft.employees = draft.data.filter(
          item =>
            item.name
              .toLowerCase()
              .match(new RegExp(action.data.toLowerCase())) ||
            item.lname
              .toLowerCase()
              .match(new RegExp(action.data.toLowerCase())) ||
            String(item.id)
              .toLowerCase()
              .match(new RegExp(action.data.toLowerCase())) ||
            item.branche_name
              .toLowerCase()
              .match(new RegExp(action.data.toLowerCase())),
        );
        break;

      case EMPLOYEES_GET_DATA:
        draft.load = 1;
        break;
      case EMPLOYEES_GET_DATA_SUCCESS:
        draft.employees = action.data.data;
        draft.data = action.data.data;
        draft.load = 0;

        break;
      case EMPLOYEES_GET_DATA_ERROR:
        draft.load = 0;

        break;
      case set_SHOW_ITEM:
        draft.item = action.item;
        draft.index = action.index;
        draft.employee = action.value;
        break;
    }
  });

export default employeesReducer;
