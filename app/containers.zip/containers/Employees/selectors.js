import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the employees state domain
 */

const selectEmployeesDomain = state => state.employees || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by Employees
 */

const makeSelectEmployees = () =>
  createSelector(
    selectEmployeesDomain,
    substate => substate,
  );

export default makeSelectEmployees;
export { selectEmployeesDomain };
