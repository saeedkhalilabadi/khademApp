import { take, call, put, takeLatest, select } from 'redux-saga/effects';
import axios from '../axios/axios-user';
import { EMPLOYEES_GET_DATA } from './constants';
import {
  employees_Get_Data_Success,
  employees_Get_Data_Error,
} from './actions';

// Individual exports for testing

function* employeesGetData() {
  let data;
  let e = null;

  yield axios
    .get('api/branches', {
      headers: JSON.parse(localStorage.getItem('userData')),
    })
    .then(response => {
      //  console.log(response.data, 'employees');
      data = response.data;
      e = true;
    })
    .catch(error => {
      console.log(error.response, 'دریافت اطلاعات کارمندان با مشکل مواجه شد');
      data = error;
      e = false;
    });
  if (e) yield put(employees_Get_Data_Success(data));
  else yield put(employees_Get_Data_Error(data));
}

export default function* employeesSaga() {
  yield takeLatest(EMPLOYEES_GET_DATA, employeesGetData);

  // See example in containers/HomePage/saga.js
}
