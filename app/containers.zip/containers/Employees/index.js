/**
 *
 * Employees
 *
 */

import React, { memo, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { Link } from 'react-router-dom';
import { Container, Button, Row, Col, Form } from 'react-bootstrap';
import { Table } from 'reactstrap';
import { makeStyles } from '@mui/styles';
import Employee from 'containers/Employee/Loadable';
import AddEmployee from 'containers/AddEmployee/Loadable';
import Loading from 'components/Loading/Loadable';
import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';

import { employees_Get_Data, setShowItem, search } from './actions';
import makeSelectEmployees from './selectors';
import './index.css';
import reducer from './reducer';
import saga from './saga';

const useStyles = makeStyles({
  root: {
    width: '95%',
    margin: 'auto',
    alignItems: 'right',
    direction: 'rtl',
  },
  inline: {
    display: 'inline',
    color: 'yeloo',
    direction: 'rtl',
    float: 'right',
    textAlign: 'right',
  },
  shape: {
    width: '100%',
    height: 40,
  },
});

export function Employees({ dispatch, employees }) {
  useInjectReducer({ key: 'employees', reducer });
  useInjectSaga({ key: 'employees', saga });
  console.log(employees, 'em');
  const classes = useStyles();
  const [employee, setemployee] = useState(null);

  const [getdata, setgetdata] = useState(true);
  if (getdata)
    setTimeout(() => {
      setgetdata(false);
      dispatch(employees_Get_Data());
    }, 200);

  const employeesShow = (
    <div className="employee">
      <Container className=" justify-content-center">
        <Container>
          <Col xs={12} sm={12} md={12} xl={12} className="newEmployeeBtn">
            <Link to="addemployee">
              <Button variant="outline-warning">ثبت شعبه جدید</Button>{' '}
            </Link>
          </Col>
          <Row className="justify-content-center ">
            <Col>
              <Form.Control
                placeholder="نام شعبه یا مسئول شعبه"
                onChange={e => dispatch(search(e.target.value))}
                style={{ maxWidth: '300px' }}
              />{' '}
            </Col>
          </Row>
        </Container>

        <Table responsive className="table" style={{ color: 'white' }}>
          <thead aligen="center">
            <Row className="rows">
              <Col xs={3} sm={3} md={3} xl={3}>
                نام
              </Col>
              <Col xs={3} sm={3} md={3} xl={3}>
                تعداد مشترک
              </Col>

              <Col xs={3} sm={3} md={3} xl={3}>
                تلفن{' '}
              </Col>
            </Row>
          </thead>
          <tbody>
            {employees.employees.map(i => (
              <Row className="rows" key={i.id}>
                <Col>{i.branche_name}</Col>

                <Col>{i.subs_count}</Col>

                <Col>{i.phone}</Col>

                <Col>
                  <Link
                    to={{
                      pathname: '/employee',
                      state: { id: i.id },
                    }}
                  >
                    جزئیات
                  </Link>
                </Col>
              </Row>
            ))}
          </tbody>
        </Table>
      </Container>
    </div>
  );

  return (
    <div data-aos="fade-right">
      <Helmet>
        <title>کارمندان</title>
        <meta name="description" content="Description of Employees" />
      </Helmet>

      {employees.load == 1 ? <Loading /> : null}
      {employeesShow}
    </div>
  );
}

Employees.propTypes = {
  dispatch: PropTypes.func.isRequired,
  employees: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  employees: makeSelectEmployees(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(Employees);
