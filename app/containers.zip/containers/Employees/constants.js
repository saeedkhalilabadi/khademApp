/*
 *
 * Employees constants
 *
 */

export const EMPLOYEES_GET_DATA = 'app/Employees/EMPLOYEES_GET_DATA';
export const EMPLOYEES_GET_DATA_SUCCESS =
  'app/Employees/EMPLOYEES_GET_DATA_SUCCESS';
export const EMPLOYEES_GET_DATA_ERROR =
  'app/Employees/EMPLOYEES_GET_DATA_ERROR';
export const set_SHOW_ITEM = 'app/Employees/set_SHOW_ITEM';
export const SEARCH = 'app/Employees/SEARCH';
