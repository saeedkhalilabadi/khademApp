/*
 *
 * Employees actions
 *
 */

import {
  EMPLOYEES_GET_DATA,
  EMPLOYEES_GET_DATA_SUCCESS,
  EMPLOYEES_GET_DATA_ERROR,
  set_SHOW_ITEM,
  SEARCH,
} from './constants';

export function search(data) {
  return {
    type: SEARCH,
    data,
  };
}

export function employees_Get_Data() {
  return {
    type: EMPLOYEES_GET_DATA,
  };
}
export function employees_Get_Data_Success(data) {
  return {
    type: EMPLOYEES_GET_DATA_SUCCESS,
    data,
  };
}
export function employees_Get_Data_Error(value) {
  return {
    type: EMPLOYEES_GET_DATA_ERROR,
    value,
  };
}
export function setShowItem(item, index, value) {
  return {
    type: set_SHOW_ITEM,
    index,
    item,
    value,
  };
}
